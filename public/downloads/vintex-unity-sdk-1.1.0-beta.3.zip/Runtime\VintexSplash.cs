using System;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.Video;

namespace Vintex
{

/// <summary>
/// Plays the Vintex intro scene and continues to the next enabled build scene.
/// </summary>
public sealed class VintexSplash : MonoBehaviour
{
	private const string HasShownKey = "Vintex.Splash.HasShown";
	private const string LastShownKey = "Vintex.Splash.LastShownUtc";
	private const string VersionKey = "Vintex.Splash.Version";

	[SerializeField] private int splashFrequency;
	[SerializeField] private float fallbackDuration = 7f;
	[SerializeField] private float returningPlayerSkipDelay = 2f;
	[SerializeField] private VideoPlayer videoPlayer;

	private float startedAt;
	private bool firstLaunch;
	private bool finishing;

	public void Configure(VideoPlayer player, int frequency)
	{
		videoPlayer = player;
		splashFrequency = Mathf.Clamp(frequency, 0, 2);
	}

	private void Start()
	{
		firstLaunch = PlayerPrefs.GetInt(HasShownKey, 0) == 0;
		if (!ShouldShowSplash())
		{
			ContinueToGame();
			return;
		}

		startedAt = Time.realtimeSinceStartup;
		if (videoPlayer != null && videoPlayer.clip != null)
		{
			videoPlayer.loopPointReached += OnVideoFinished;
			videoPlayer.errorReceived += OnVideoError;
			videoPlayer.Play();
		}
	}

	private void Update()
	{
		if (finishing)
		{
			return;
		}

		float elapsed = Time.realtimeSinceStartup - startedAt;
		if ((videoPlayer == null || videoPlayer.clip == null) && elapsed >= fallbackDuration)
		{
			ContinueToGame();
			return;
		}

		if (!firstLaunch && elapsed >= returningPlayerSkipDelay && WasSkipPressed())
		{
			ContinueToGame();
		}
	}

	private bool ShouldShowSplash()
	{
		if (firstLaunch || splashFrequency == 0)
		{
			return true;
		}

		if (splashFrequency == 1)
		{
			long ticks;
			return !long.TryParse(PlayerPrefs.GetString(LastShownKey, "0"), out ticks) ||
			       DateTime.UtcNow - new DateTime(ticks, DateTimeKind.Utc) >= TimeSpan.FromHours(24);
		}

		return !string.Equals(PlayerPrefs.GetString(VersionKey, string.Empty), Application.version, StringComparison.Ordinal);
	}

	private static bool WasSkipPressed()
	{
		try
		{
			return Input.anyKeyDown || Input.touchCount > 0;
		}
		catch (InvalidOperationException)
		{
			return false;
		}
	}

	private void OnVideoFinished(VideoPlayer source)
	{
		ContinueToGame();
	}

	private void OnVideoError(VideoPlayer source, string message)
	{
		Debug.LogWarning("[Vintex] Splash video could not play: " + message);
		ContinueToGame();
	}

	private void ContinueToGame()
	{
		if (finishing)
		{
			return;
		}

		finishing = true;
		PlayerPrefs.SetInt(HasShownKey, 1);
		PlayerPrefs.SetString(LastShownKey, DateTime.UtcNow.Ticks.ToString());
		PlayerPrefs.SetString(VersionKey, Application.version);
		PlayerPrefs.Save();

		int nextIndex = SceneManager.GetActiveScene().buildIndex + 1;
		if (nextIndex >= 0 && nextIndex < SceneManager.sceneCountInBuildSettings)
		{
			SceneManager.LoadScene(nextIndex);
		}
		else
		{
			Debug.LogError("[Vintex] No enabled game scene follows VintexSplash in Build Settings.");
		}
	}
}

}
