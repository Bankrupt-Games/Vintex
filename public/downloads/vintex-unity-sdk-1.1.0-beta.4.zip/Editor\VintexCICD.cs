using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace VintexEditorPlugin
{

public static class VintexCICD
{
	public const string ENV_DEV_GAME_TOKEN = "VINTEX_DEV_GAME_TOKEN";

	public const string ENV_BUILD_TYPE = "VINTEX_BUILD_TYPE";

	public const string ENV_API_URL = "VINTEX_API_URL";

	public const string ENV_OBB_ENABLED = "VINTEX_OBB_ENABLED";

	public const string ENV_GAME_SERVER_API_KEY = "VINTEX_GAME_SERVER_API_KEY";

	public const string ENV_SKIP_LIVE_WARNING = "VINTEX_SKIP_LIVE_WARNING";

	public const string ENV_SKIP_DEV_WARNING = "VINTEX_SKIP_DEV_WARNING";

	public const string ENV_SKIP_PREBUILD_AUTH = "VINTEX_SKIP_PREBUILD_AUTH";

	public const string ENV_SCRIPTING_DEFINES = "VINTEX_SCRIPTING_DEFINES";

	private static readonly string[] CIEnvironmentVariables = new string[12]
	{
		"CI", "CONTINUOUS_INTEGRATION", "BUILD_NUMBER", "GITHUB_ACTIONS", "GITLAB_CI", "TF_BUILD", "JENKINS_HOME", "TEAMCITY_VERSION", "CIRCLECI", "TRAVIS",
		"BUILDKITE", "BITBUCKET_BUILD_NUMBER"
	};

	public static bool IsBatchMode => Application.isBatchMode;

	public static bool IsCIEnvironment
	{
		get
		{
			if (Application.isBatchMode)
			{
				return true;
			}
			string[] cIEnvironmentVariables = CIEnvironmentVariables;
			for (int i = 0; i < cIEnvironmentVariables.Length; i++)
			{
				if (!string.IsNullOrEmpty(Environment.GetEnvironmentVariable(cIEnvironmentVariables[i])))
				{
					return true;
				}
			}
			return false;
		}
	}

	public static bool IsInteractive => !IsBatchMode;

	public static string DetectedCIProvider
	{
		get
		{
			if (!string.IsNullOrEmpty(Environment.GetEnvironmentVariable("GITHUB_ACTIONS")))
			{
				return "GitHub Actions";
			}
			if (!string.IsNullOrEmpty(Environment.GetEnvironmentVariable("GITLAB_CI")))
			{
				return "GitLab CI";
			}
			if (!string.IsNullOrEmpty(Environment.GetEnvironmentVariable("TF_BUILD")))
			{
				return "Azure DevOps";
			}
			if (!string.IsNullOrEmpty(Environment.GetEnvironmentVariable("JENKINS_HOME")))
			{
				return "Jenkins";
			}
			if (!string.IsNullOrEmpty(Environment.GetEnvironmentVariable("TEAMCITY_VERSION")))
			{
				return "TeamCity";
			}
			if (!string.IsNullOrEmpty(Environment.GetEnvironmentVariable("CIRCLECI")))
			{
				return "CircleCI";
			}
			if (!string.IsNullOrEmpty(Environment.GetEnvironmentVariable("TRAVIS")))
			{
				return "Travis CI";
			}
			if (!string.IsNullOrEmpty(Environment.GetEnvironmentVariable("BUILDKITE")))
			{
				return "Buildkite";
			}
			if (!string.IsNullOrEmpty(Environment.GetEnvironmentVariable("BITBUCKET_BUILD_NUMBER")))
			{
				return "Bitbucket Pipelines";
			}
			if (Application.isBatchMode)
			{
				return "Unknown (Batch Mode)";
			}
			return null;
		}
	}

	public static string GetEnv(string name, string defaultValue = "")
	{
		string environmentVariable = Environment.GetEnvironmentVariable(name);
		if (!string.IsNullOrEmpty(environmentVariable))
		{
			return environmentVariable;
		}
		return defaultValue;
	}

	public static bool GetEnvBool(string name, bool defaultValue = false)
	{
		string environmentVariable = Environment.GetEnvironmentVariable(name);
		if (string.IsNullOrEmpty(environmentVariable))
		{
			return defaultValue;
		}
		if (!(environmentVariable == "1") && !environmentVariable.Equals("true", StringComparison.OrdinalIgnoreCase))
		{
			return environmentVariable.Equals("yes", StringComparison.OrdinalIgnoreCase);
		}
		return true;
	}

	public static bool IsSkipFlagSet(string envVarName)
	{
		return !string.IsNullOrEmpty(Environment.GetEnvironmentVariable(envVarName));
	}

	public static bool ShowDialog(string title, string message, string ok, string cancel = null, bool defaultInCI = true)
	{
		if (IsBatchMode)
		{
			Debug.Log((object)("[Vintex] CI/CD Dialog (auto-" + (defaultInCI ? "confirmed" : "cancelled") + "): " + title));
			Debug.Log((object)("[Vintex] " + message.Replace("\n", "\n[Vintex] ")));
			return defaultInCI;
		}
		if (string.IsNullOrEmpty(cancel))
		{
			return EditorUtility.DisplayDialog(title, message, ok);
		}
		return EditorUtility.DisplayDialog(title, message, ok, cancel);
	}

	public static int ShowDialogComplex(string title, string message, string ok, string cancel, string alt, int defaultInCI = 0)
	{
		if (IsBatchMode)
		{
			Debug.Log((object)("[Vintex] CI/CD Dialog (auto-selecting '" + defaultInCI switch
			{
				1 => cancel, 
				0 => ok, 
				_ => alt, 
			} + "'): " + title));
			Debug.Log((object)("[Vintex] " + message.Replace("\n", "\n[Vintex] ")));
			return defaultInCI;
		}
		return EditorUtility.DisplayDialogComplex(title, message, ok, cancel, alt);
	}

	public static void LogCIEnvironment()
	{
		if (!IsCIEnvironment)
		{
			Debug.Log((object)"[Vintex] Running in interactive editor mode");
			return;
		}
		Debug.Log((object)"[Vintex] ════════════════════════════════════════════════════════════");
		Debug.Log((object)"[Vintex] CI/CD ENVIRONMENT DETECTED");
		Debug.Log((object)"[Vintex] ════════════════════════════════════════════════════════════");
		string detectedCIProvider = DetectedCIProvider;
		if (detectedCIProvider != null)
		{
			Debug.Log((object)("[Vintex] CI Provider: " + detectedCIProvider));
		}
		Debug.Log((object)$"[Vintex] Batch Mode: {IsBatchMode}");
		LogEnvVar("VINTEX_BUILD_TYPE", mask: false);
		LogEnvVar("VINTEX_DEV_GAME_TOKEN", mask: true);
		LogEnvVar("VINTEX_GAME_SERVER_API_KEY", mask: true);
		LogEnvVar("VINTEX_API_URL", mask: false);
		LogEnvVar("VINTEX_OBB_ENABLED", mask: false);
		LogEnvVar("VINTEX_SKIP_LIVE_WARNING", mask: false);
		LogEnvVar("VINTEX_SKIP_DEV_WARNING", mask: false);
		LogEnvVar("VINTEX_SKIP_PREBUILD_AUTH", mask: false);
		LogEnvVar("VINTEX_SCRIPTING_DEFINES", mask: false);
		Debug.Log((object)"[Vintex] ════════════════════════════════════════════════════════════");
	}

	private static void LogEnvVar(string name, bool mask)
	{
		string environmentVariable = Environment.GetEnvironmentVariable(name);
		if (string.IsNullOrEmpty(environmentVariable))
		{
			Debug.Log((object)("[Vintex] " + name + ": (not set)"));
		}
		else if (mask)
		{
			Debug.Log((object)("[Vintex] " + name + ": ****** (set)"));
		}
		else
		{
			Debug.Log((object)("[Vintex] " + name + ": " + environmentVariable));
		}
	}

	public static string[] ValidateCIConfiguration()
	{
		List<string> list = new List<string>();
		if (!IsCIEnvironment)
		{
			return list.ToArray();
		}
		if (string.IsNullOrEmpty(GetEnv("VINTEX_DEV_GAME_TOKEN")))
		{
			list.Add("VINTEX_DEV_GAME_TOKEN is not set - build verification will fail");
		}
		string env = GetEnv("VINTEX_BUILD_TYPE");
		if (!string.IsNullOrEmpty(env))
		{
			string[] obj = new string[2] { "QA", "Live" };
			bool flag = false;
			string[] array = obj;
			for (int i = 0; i < array.Length; i++)
			{
				if (array[i].Equals(env, StringComparison.OrdinalIgnoreCase))
				{
					flag = true;
					break;
				}
			}
			if (env.Equals("Dev", StringComparison.OrdinalIgnoreCase))
			{
				list.Add("VINTEX_BUILD_TYPE is set to 'Dev' which is not available - will fall back to QA");
			}
			else if (!flag)
			{
				list.Add("VINTEX_BUILD_TYPE has invalid value '" + env + "' - must be QA or Live. Will fall back to QA");
			}
		}
		if (env != null && env.Equals("Live", StringComparison.OrdinalIgnoreCase) && !IsSkipFlagSet("VINTEX_SKIP_LIVE_WARNING"))
		{
			list.Add("Building for Live environment but VINTEX_SKIP_LIVE_WARNING is not set");
		}
		return list.ToArray();
	}

	public static void LogInfoDialog(string title, string message)
	{
		if (IsBatchMode)
		{
			Debug.Log((object)("[Vintex] " + title));
			Debug.Log((object)("[Vintex] " + message.Replace("\n", "\n[Vintex] ")));
		}
		else
		{
			EditorUtility.DisplayDialog(title, message, "OK");
		}
	}

	public static void LogErrorDialog(string title, string message)
	{
		if (IsBatchMode)
		{
			Debug.LogError((object)("[Vintex] " + title));
			Debug.LogError((object)("[Vintex] " + message.Replace("\n", "\n[Vintex] ")));
		}
		else
		{
			EditorUtility.DisplayDialog(title, message, "OK");
		}
	}
}
}
