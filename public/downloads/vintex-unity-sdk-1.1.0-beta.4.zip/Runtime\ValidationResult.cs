using System;

namespace Vintex
{

/// <summary>
/// Result from Vintex backend validation.
/// Matches Unreal's response parsing.
/// </summary>
[Serializable]
public class ValidationResult
{
	/// <summary>
	/// Action code from the backend.
	/// 0 = Valid (allow)
	/// 1 = Kick
	/// 2 = Ban
	/// </summary>
	public int ActionCode;

	/// <summary>
	/// Human-readable reason for the validation result.
	/// </summary>
	public string Reason;

	/// <summary>
	/// Whether the client is using a VPN.
	/// </summary>
	public bool IsUsingVPN;

	/// <summary>
	/// Whether the validation was successful (ActionCode == 0).
	/// </summary>
	public bool IsValid => ActionCode == 0;

	public override string ToString()
	{
		return $"ValidationResult(IsValid={IsValid}, ActionCode={ActionCode}, Reason={Reason}, VPN={IsUsingVPN})";
	}
}
}
