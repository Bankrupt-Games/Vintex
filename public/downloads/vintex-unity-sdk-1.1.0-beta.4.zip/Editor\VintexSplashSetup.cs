using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.Video;
using Vintex;

namespace VintexEditorPlugin
{

public static class VintexSplashSetup
{
	private const string ScenePath = "Assets/VintexSDK/Scenes/VintexSplash.unity";
	private const string VideoPath = "Assets/VintexSDK/Resources/VintexSplash.mp4";

	[MenuItem("Vintex/Create Splash Scene")]
	public static void CreateSplashScene()
	{
		if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo())
		{
			return;
		}

		Directory.CreateDirectory("Assets/VintexSDK/Scenes");
		Directory.CreateDirectory("Assets/VintexSDK/Resources");
		AssetDatabase.Refresh();

		Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
		scene.name = "VintexSplash";

		GameObject cameraObject = new GameObject("Vintex Splash Camera");
		Camera splashCamera = cameraObject.AddComponent<Camera>();
		splashCamera.clearFlags = CameraClearFlags.SolidColor;
		splashCamera.backgroundColor = new Color(0.025f, 0.027f, 0.035f, 1f);
		splashCamera.stereoTargetEye = StereoTargetEyeMask.Both;
		cameraObject.tag = "MainCamera";

		AudioSource audioSource = cameraObject.AddComponent<AudioSource>();
		VideoPlayer player = cameraObject.AddComponent<VideoPlayer>();
		player.playOnAwake = false;
		player.isLooping = false;
		player.renderMode = VideoRenderMode.CameraNearPlane;
		player.targetCamera = splashCamera;
		player.aspectRatio = VideoAspectRatio.FitInside;
		player.audioOutputMode = VideoAudioOutputMode.AudioSource;

		VideoClip clip = AssetDatabase.LoadAssetAtPath<VideoClip>(VideoPath);
		if (clip != null)
		{
			player.source = VideoSource.VideoClip;
			player.clip = clip;
			player.EnableAudioTrack(0, true);
			player.SetTargetAudioSource(0, audioSource);
		}
		else
		{
			CreateBrandFallback(cameraObject.transform);
			Debug.LogWarning("[Vintex] VintexSplash.mp4 was not found. The generated scene will use the branded fallback until you add the video at " + VideoPath + ".");
		}

		GameObject controllerObject = new GameObject("Vintex Splash Controller");
		VintexSplash controller = controllerObject.AddComponent<VintexSplash>();
		controller.Configure(player, EditorPrefs.GetInt("VintexSplashFrequency", 0));

		GameObject managerPrefab = AssetDatabase.LoadAssetAtPath<GameObject>("Assets/VintexSDK/Prefabs/VintexManager.prefab");
		if (managerPrefab != null)
		{
			PrefabUtility.InstantiatePrefab(managerPrefab, scene);
		}

		EditorSceneManager.SaveScene(scene, ScenePath);
		AddSceneFirstInBuildSettings();
		AssetDatabase.SaveAssets();
		Selection.activeObject = AssetDatabase.LoadAssetAtPath<SceneAsset>(ScenePath);
		Debug.Log("[Vintex] Created splash scene at " + ScenePath);
	}

	private static void CreateBrandFallback(Transform cameraTransform)
	{
		GameObject titleObject = new GameObject("Vintex Brand Fallback");
		titleObject.transform.SetParent(cameraTransform, false);
		titleObject.transform.localPosition = new Vector3(0f, 0f, 4f);
		TextMesh title = titleObject.AddComponent<TextMesh>();
		title.text = "VINTEX\nBANKRUPT GAMES";
		title.anchor = TextAnchor.MiddleCenter;
		title.alignment = TextAlignment.Center;
		title.fontSize = 96;
		title.characterSize = 0.035f;
		title.color = new Color(0.35f, 0.72f, 0.95f, 1f);
	}

	private static void AddSceneFirstInBuildSettings()
	{
		EditorBuildSettingsScene[] remaining = EditorBuildSettings.scenes
			.Where(item => item.path != ScenePath)
			.ToArray();
		EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) }
			.Concat(remaining)
			.ToArray();
	}
}

}
