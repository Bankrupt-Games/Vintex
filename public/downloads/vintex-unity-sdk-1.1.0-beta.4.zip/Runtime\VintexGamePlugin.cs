using System;
using System.Collections;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using Object = UnityEngine.Object;

namespace Vintex
{

/// <summary>
/// Main Vintex plugin for Quest client-side verification.
/// Uses T_Core native library for background integrity checks.
///
/// Build Macros:
/// - VINTEX_ENABLED: Enable Vintex client code (Quest builds)
/// - VINTEX_SERVER / UNITY_SERVER: Enable server validation code
/// - VINTEX_LOGGING_ENABLED: Enable debug logging
///
/// T_Core automatically handles:
/// - Background thread execution
/// - Nonce request from server
/// - Meta OVR attestation with integrity token
/// - OBB file verification (optional)
/// - Automatic retry logic with configurable max retries
/// - Session nonce rotation via heartbeat
/// </summary>
public class VintexGamePlugin : MonoBehaviour
{
	/// <summary>
	/// T_Core attestation status
	/// NotStarted -&gt; Initializing -&gt; Running -&gt; Complete (success) or Failed (error)
	/// </summary>
	public enum TCoreStatus
	{
		NotStarted,
		Initializing,
		Running,
		Complete,
		Failed
	}

	/// <summary>
	/// Result of client-side validation against Vintex backend.
	/// Matches backend actionCode values: 0=Valid, 1=Kicked, 2=Banned
	/// </summary>
	public enum ClientValidationResult
	{
		Valid = 0,
		Kicked = 1,
		Banned = 2,
		Error = -1,
		NotReady = -2
	}

	public class TCoreError
	{
		public string message;

		public override string ToString()
		{
			return message;
		}
	}

	[Header("Vintex T_Core Configuration")]
	[Tooltip("Your Oculus application ID from Meta Quest developer dashboard")]
	[SerializeField]
	private string oculusAppId = "YOUR_APP_ID_HERE";

	[Tooltip("Enable Meta OVR attestation (integrity token verification)")]
	[SerializeField]
	private bool enableAttestation = true;

	[Tooltip("Enable OBB file verification (validates game files)")]
	[SerializeField]
	private bool enableOBB = true;

	[Tooltip("Max retry attempts for each operation (0 = no retries, recommended: 3-5)")]
	[SerializeField]
	private int maxRetries = 3;

	[Header("OVR Library Strategy")]
	[Tooltip("Enable if your game uses Meta OVR Platform SDK v55+ with Device Integrity support.\n\nTRUE: Vintex reuses your game's OVR library to avoid conflicts.\nFALSE: Vintex loads its own bundled OVR library (recommended if unsure).\n\nIf your game doesn't use OVR, or uses an older version without Device Integrity, leave this OFF.")]
	[SerializeField]
	private bool useGameOVR;

	[Header("Startup Behavior")]
	[Tooltip("If true, attestation starts automatically on Start(). If false, call Initialize() manually.")]
	[SerializeField]
	private bool autoStartOnAwake = true;

	[Header("Unity Polling")]
	[Tooltip("How often Unity polls T_Core status (T_Core runs in background thread). Unreal uses 0.5s.")]
	[SerializeField]
	private float statusPollInterval = 0.5f;

	private static VintexGamePlugin instance;

	private bool isInitialized;

	private Coroutine statusPollingCoroutine;

	private static bool attestationComplete = false;

	private static string lastSessionNonce = "";

	private static bool IsNativePlatform => (int)Application.platform == 11;

	/// <summary>
	/// Fired when Vintex verification completes successfully.
	/// </summary>
	public static event Action OnVintexReady;

	/// <summary>
	/// Fired when Vintex verification fails.
	/// Parameter: error message
	/// </summary>
	public static event Action<string> OnVintexFailed;

	/// <summary>
	/// Fired when session nonce is refreshed (after heartbeat).
	/// Parameter: new session nonce
	/// </summary>
	public static event Action<string> OnSessionNonceRefreshed;

	[DllImport("VintexCore")]
	private static extern int vintexCoreInitialize(string appId, int enableAttestation, int enableOBB, int useGameOVR, int maxRetries);

	[DllImport("VintexCore")]
	private static extern int vintexCoreGetStatus();

	[DllImport("VintexCore")]
	private static extern int vintexCoreIsComplete();

	[DllImport("VintexCore")]
	private static extern int vintexCoreIsFailed();

	[DllImport("VintexCore")]
	private static extern int vintexCoreGetErrorCount();

	[DllImport("VintexCore")]
	private static extern int vintexCoreGetError(int index, [MarshalAs(UnmanagedType.LPArray, SizeConst = 1024)] byte[] outBuffer, int bufferLen);

	[DllImport("VintexCore")]
	private static extern int vintexCoreGetSessionNonce([MarshalAs(UnmanagedType.LPArray)] byte[] outNonce, int maxLen);

	[DllImport("VintexCore")]
	private static extern int T_CV();

	[DllImport("VintexCore")]
	private static extern int T_CVR([MarshalAs(UnmanagedType.LPArray)] byte[] outReason, int maxLen);

	[DllImport("VintexCore")]
	private static extern void T_FC();

	private static ClientValidationResult MapNativeCVResult(int nativeResult)
	{
		return nativeResult switch
		{
			23 => ClientValidationResult.Valid, 
			32 => ClientValidationResult.Kicked, 
			1 => ClientValidationResult.Banned, 
			-1 => ClientValidationResult.Error, 
			-2 => ClientValidationResult.NotReady, 
			_ => ClientValidationResult.Error, 
		};
	}

	private void Awake()
	{
		if ((Object)(object)instance != (Object)null && (Object)(object)instance != (Object)(object)this)
		{
			Object.Destroy((Object)(object)((Component)this).gameObject);
			return;
		}
		instance = this;
		Object.DontDestroyOnLoad((Object)(object)((Component)this).gameObject);
		if (!IsNativePlatform)
		{
			VintexLog.Info("Plugin awake (non-Android platform - native calls disabled)");
		}
		else
		{
			VintexLog.Info("Plugin awake");
		}
	}

	private void Start()
	{
		if (!IsNativePlatform)
		{
			VintexLog.Info("Skipping T_Core on non-Android platform");
		}
		else if (autoStartOnAwake)
		{
			VintexLog.Info("Auto-starting T_Core initialization...");
			InitializeTCore();
		}
		else
		{
			VintexLog.Info("Auto-start disabled. Call Initialize() to begin.");
		}
	}

	private void OnDestroy()
	{
		VintexLog.Info("Shutting down...");
		if (statusPollingCoroutine != null)
		{
			((MonoBehaviour)this).StopCoroutine(statusPollingCoroutine);
			statusPollingCoroutine = null;
		}
	}

	private void InitializeTCore()
	{
		if (isInitialized)
		{
			VintexLog.Warning("InitializeTCore: Already initialized (local flag), ignoring");
			return;
		}
		int num = vintexCoreGetStatus();
		if (num != 0)
		{
			VintexLog.Warning("InitializeTCore: T_Core status is {0}, not NotStarted - aborting init", num);
			switch (num)
			{
			case 3:
				VintexLog.Info("InitializeTCore: Already complete - firing success event");
				attestationComplete = true;
				isInitialized = true;
				HandleAttestationComplete();
				return;
			case 4:
				VintexLog.Warning("InitializeTCore: Already failed - firing failure event");
				isInitialized = true;
				HandleAttestationFailed();
				return;
			}
			VintexLog.Info("InitializeTCore: Already running - starting poll only");
			isInitialized = true;
			if (statusPollingCoroutine == null)
			{
				statusPollingCoroutine = ((MonoBehaviour)this).StartCoroutine(PollStatusCoroutine());
			}
		}
		else
		{
			VintexLog.Info("Initializing T_Core:");
			VintexLog.Info("  - App ID: {0}", oculusAppId);
			VintexLog.Info("  - Internal Integrity: {0}", enableAttestation);
			VintexLog.Info("  - External Integrity: {0}", enableOBB);
			VintexLog.Info("  - Use Game OVR: {0}", useGameOVR);
			VintexLog.Info("  - Max Retries: {0}", maxRetries);
			if (vintexCoreInitialize(oculusAppId, enableAttestation ? 1 : 0, enableOBB ? 1 : 0, useGameOVR ? 1 : 0, maxRetries) == 0)
			{
				VintexLog.Error("Failed to initialize T_Core (already running or invalid params)");
				return;
			}
			VintexLog.Info("Verification started");
			isInitialized = true;
			statusPollingCoroutine = ((MonoBehaviour)this).StartCoroutine(PollStatusCoroutine());
		}
	}

	private IEnumerator PollStatusCoroutine()
	{
		VintexLog.Info("Status polling started");
		while (true)
		{
			TCoreStatus tCoreStatus = (TCoreStatus)vintexCoreGetStatus();
			VintexLog.Info("Status: {0}", tCoreStatus);
			if (vintexCoreIsComplete() == 1)
			{
				VintexLog.Info("Attestation COMPLETE!");
				attestationComplete = true;
				HandleAttestationComplete();
				yield break;
			}
			if (vintexCoreIsFailed() == 1)
			{
				break;
			}
			yield return (object)new WaitForSeconds(statusPollInterval);
		}
		HandleAttestationFailed();
	}

	private void HandleAttestationComplete()
	{
		VintexLog.Info("Verification passed");
		VintexGamePlugin.OnVintexReady?.Invoke();
	}

	private void HandleAttestationFailed()
	{
		VintexLog.Error("Integrity check failed");
		TCoreError[] errors = GetErrors();
		string text = "";
		TCoreError[] array = errors;
		foreach (TCoreError tCoreError in array)
		{
			VintexLog.Error("{0}", tCoreError.ToString());
			if (!string.IsNullOrEmpty(text))
			{
				text += "; ";
			}
			text += tCoreError.message;
		}
		if (string.IsNullOrEmpty(text))
		{
			text = "Unknown error";
		}
		VintexGamePlugin.OnVintexFailed?.Invoke(text);
	}

	private TCoreError[] GetErrors()
	{
		int num = vintexCoreGetErrorCount();
		if (num == 0)
		{
			return new TCoreError[0];
		}
		TCoreError[] array = new TCoreError[num];
		byte[] array2 = new byte[1024];
		for (int i = 0; i < num; i++)
		{
			int num2 = vintexCoreGetError(i, array2, array2.Length);
			if (num2 > 0)
			{
				array[i] = new TCoreError
				{
					message = Encoding.UTF8.GetString(array2, 0, num2)
				};
			}
			else
			{
				array[i] = new TCoreError
				{
					message = "Unknown error"
				};
			}
		}
		return array;
	}

	/// <summary>
	/// Get all errors as a combined string message.
	/// Used for firing OnVintexFailed events.
	/// </summary>
	private string GetCombinedErrorMessage()
	{
		TCoreError[] errors = GetErrors();
		if (errors.Length == 0)
		{
			return "Integrity check failed";
		}
		string text = "";
		TCoreError[] array = errors;
		foreach (TCoreError tCoreError in array)
		{
			text = text + tCoreError.message + "; ";
		}
		return text.TrimEnd(' ', ';');
	}

	/// <summary>
	/// Get the current session nonce and trigger a heartbeat refresh.
	/// This forces an immediate heartbeat to rotate the nonce.
	/// </summary>
	private string GetSessionNonceInternal()
	{
		byte[] array = new byte[256];
		int num = vintexCoreGetSessionNonce(array, array.Length);
		if (num > 0)
		{
			string text = Encoding.UTF8.GetString(array, 0, num);
			if (!string.IsNullOrEmpty(lastSessionNonce) && text != lastSessionNonce)
			{
				VintexLog.Info("Session nonce refreshed");
				VintexGamePlugin.OnSessionNonceRefreshed?.Invoke(text);
			}
			lastSessionNonce = text;
			return text;
		}
		return "";
	}

	/// <summary>
	/// Explicitly start Vintex verification.
	/// Use this when autoStartOnAwake is disabled to control when verification begins.
	///
	/// Example:
	/// <code>
	/// // In your login flow after user authentication
	/// VintexGamePlugin.Initialize();
	///
	/// // Listen for completion
	/// VintexGamePlugin.OnVintexReady += () =&gt; { /* proceed */ };
	/// VintexGamePlugin.OnVintexFailed += (error) =&gt; { /* handle */ };
	/// </code>
	/// </summary>
	/// <returns>true if initialization was started or is already complete, false on error</returns>
	public static bool Initialize()
	{
		if (!IsNativePlatform)
		{
			VintexLog.Warning("Initialize: Not on Android platform, no-op");
			return false;
		}
		if ((Object)(object)instance == (Object)null)
		{
			VintexLog.Error("Initialize: No VintexGamePlugin instance found. Add to scene first.");
			return false;
		}
		int num = vintexCoreGetStatus();
		switch (num)
		{
		case 3:
			VintexLog.Info("Initialize: T_Core already completed - firing success event");
			attestationComplete = true;
			instance.isInitialized = true;
			VintexGamePlugin.OnVintexReady?.Invoke();
			return true;
		case 4:
		{
			VintexLog.Warning("Initialize: T_Core already failed - firing failure event");
			instance.isInitialized = true;
			string combinedErrorMessage = instance.GetCombinedErrorMessage();
			VintexGamePlugin.OnVintexFailed?.Invoke(combinedErrorMessage);
			return false;
		}
		case 1:
		case 2:
			VintexLog.Info("Initialize: T_Core already running (status={0}) - starting poll only", num);
			instance.isInitialized = true;
			if (instance.statusPollingCoroutine == null)
			{
				instance.statusPollingCoroutine = ((MonoBehaviour)instance).StartCoroutine(instance.PollStatusCoroutine());
			}
			return true;
		default:
			VintexLog.Info("Initialize: T_Core not started - initializing...");
			instance.InitializeTCore();
			return true;
		}
	}

	/// <summary>
	/// Initialize Vintex with custom configuration (overrides Inspector settings).
	///
	/// If T_Core is already running/complete/failed, this will respect that state:
	/// - Complete: fires OnVintexReady immediately
	/// - Failed: fires OnVintexFailed immediately
	/// - Running: starts polling without re-initialization
	/// - NotStarted: applies config and initializes
	/// </summary>
	/// <param name="appId">Oculus App ID (optional, uses Inspector value if null)</param>
	/// <param name="integrityCheck">Enable integrity check (optional)</param>
	/// <param name="obb">Enable OBB verification (optional)</param>
	/// <param name="retries">Deprecated - ignored</param>
	/// <returns>true if initialization was started or is already complete, false on error</returns>
	public static bool Initialize(string appId = null, bool? integrityCheck = null, bool? obb = null, int? retries = null)
	{
		if (!IsNativePlatform)
		{
			VintexLog.Warning("Initialize: Not on Android platform, no-op");
			return false;
		}
		if ((Object)(object)instance == (Object)null)
		{
			VintexLog.Error("Initialize: No VintexGamePlugin instance found");
			return false;
		}
		int num = vintexCoreGetStatus();
		switch (num)
		{
		case 3:
			VintexLog.Info("Initialize: T_Core already completed - firing success event (config ignored)");
			attestationComplete = true;
			instance.isInitialized = true;
			VintexGamePlugin.OnVintexReady?.Invoke();
			return true;
		case 4:
		{
			VintexLog.Warning("Initialize: T_Core already failed - firing failure event (config ignored)");
			instance.isInitialized = true;
			string combinedErrorMessage = instance.GetCombinedErrorMessage();
			VintexGamePlugin.OnVintexFailed?.Invoke(combinedErrorMessage);
			return false;
		}
		case 1:
		case 2:
			VintexLog.Info("Initialize: T_Core already running (status={0}) - starting poll only (config ignored)", num);
			instance.isInitialized = true;
			if (instance.statusPollingCoroutine == null)
			{
				instance.statusPollingCoroutine = ((MonoBehaviour)instance).StartCoroutine(instance.PollStatusCoroutine());
			}
			return true;
		default:
			if (!string.IsNullOrEmpty(appId))
			{
				instance.oculusAppId = appId;
			}
			if (integrityCheck.HasValue)
			{
				instance.enableAttestation = integrityCheck.Value;
			}
			if (obb.HasValue)
			{
				instance.enableOBB = obb.Value;
			}
			if (retries.HasValue)
			{
				instance.maxRetries = retries.Value;
			}
			VintexLog.Info("Initialize: Starting with config - AppId={0}, Attestation={1}, OBB={2}, Retries={3}", instance.oculusAppId, instance.enableAttestation, instance.enableOBB, instance.maxRetries);
			instance.InitializeTCore();
			return true;
		}
	}

	/// <summary>
	/// Get the current T_Core status.
	/// </summary>
	public static TCoreStatus GetStatus()
	{
		if (!IsNativePlatform)
		{
			return TCoreStatus.NotStarted;
		}
		return (TCoreStatus)vintexCoreGetStatus();
	}

	/// <summary>
	/// Check if Vintex verification is complete.
	/// </summary>
	public static bool IsReady()
	{
		if (!IsNativePlatform)
		{
			return false;
		}
		if (!attestationComplete)
		{
			return vintexCoreIsComplete() == 1;
		}
		return true;
	}

	/// <summary>
	/// Check if Vintex verification failed.
	/// </summary>
	public static bool IsFailed()
	{
		if (!IsNativePlatform)
		{
			return false;
		}
		return vintexCoreIsFailed() == 1;
	}

	/// <summary>
	/// Get all accumulated errors.
	/// </summary>
	public static TCoreError[] GetAllErrors()
	{
		if (!IsNativePlatform)
		{
			return new TCoreError[0];
		}
		if ((Object)(object)instance == (Object)null)
		{
			return new TCoreError[0];
		}
		return instance.GetErrors();
	}

	/// <summary>
	/// Get the current session nonce for server validation (synchronous).
	/// This is called by the server to validate the client's token.
	/// Triggers a heartbeat refresh to rotate the nonce.
	/// </summary>
	public static string GetSessionNonceStatic()
	{
		if (!IsNativePlatform)
		{
			return "";
		}
		if ((Object)(object)instance == (Object)null)
		{
			VintexLog.Warning("GetSessionNonceStatic: No instance available");
			return "";
		}
		return instance.GetSessionNonceInternal();
	}

	/// <summary>
	/// Get the current session nonce asynchronously (background thread).
	/// Equivalent to Unreal's RefreshSessionNonceAsync().
	///
	/// Use this for custom backend integration where you need to pass
	/// the token to your own validation server.
	///
	/// Example:
	/// <code>
	/// string token = await VintexGamePlugin.GetSessionNonceAsync();
	/// await MyBackendAPI.ValidateToken(token);
	/// </code>
	/// </summary>
	/// <returns>Session nonce string, or empty if unavailable</returns>
	public static async Task<string> GetSessionNonceAsync()
	{
		if (!IsNativePlatform)
		{
			return await Task.FromResult("");
		}
		if ((Object)(object)instance == (Object)null)
		{
			VintexLog.Warning("GetSessionNonceAsync: No instance available");
			return "";
		}
		return await Task.Run(delegate
		{
			try
			{
				byte[] array = new byte[8192];
				int num = vintexCoreGetSessionNonce(array, array.Length);
				if (num > 0)
				{
					return Encoding.UTF8.GetString(array, 0, num);
				}
				return "";
			}
			catch (Exception ex)
			{
				VintexLog.Error("GetSessionNonceAsync: Exception - {0}", ex.Message);
				return "";
			}
		});
	}

	/// <summary>
	/// Check if Vintex is available on this platform.
	/// Returns true on Quest/Android with VINTEX_ENABLED defined.
	/// </summary>
	public static bool IsVintexAvailable()
	{
		return IsNativePlatform;
	}

	/// <summary>
	/// Check if server validation code is enabled.
	/// Returns true when VINTEX_SERVER or UNITY_SERVER is defined.
	/// </summary>
	public static bool IsVintexServerEnabled()
	{
		return false;
	}

	/// <summary>
	/// Perform client-side validation asynchronously.
	/// Returns result for developer to handle (kick player, show message, etc.)
	///
	/// This triggers a session nonce refresh, then validates with the Vintex
	/// backend /cv endpoint. The developer is responsible for handling the result.
	///
	/// Example:
	/// <code>
	/// var result = await VintexGamePlugin.ValidateClientAsync();
	/// if (result == ClientValidationResult.Valid) {
	///     // Proceed with game
	/// } else {
	///     // Handle kick/ban/error
	/// }
	/// </code>
	/// </summary>
	/// <returns>ClientValidationResult enum</returns>
	public static async Task<ClientValidationResult> ValidateClientAsync()
	{
		if (!IsNativePlatform)
		{
			return await Task.FromResult(ClientValidationResult.Valid);
		}
		return await Task.Run(delegate
		{
			try
			{
				return MapNativeCVResult(T_CV());
			}
			catch (Exception ex)
			{
				VintexLog.Error("ValidateClientAsync: Exception - {0}", ex.Message);
				return ClientValidationResult.Error;
			}
		});
	}

	/// <summary>
	/// Perform client-side validation and let Vintex handle the result.
	/// If kicked/banned/error, immediately terminates the application.
	///
	/// Use this when you want Vintex to automatically handle validation
	/// failures by terminating the application.
	///
	/// Example:
	/// <code>
	/// await VintexGamePlugin.ValidateClientOrTerminateAsync(() =&gt; {
	///     Debug.Log("Client validated successfully!");
	/// });
	/// // Code here only runs if validation passed
	/// </code>
	/// </summary>
	/// <param name="onValid">Optional callback when validation passes</param>
	public static async Task ValidateClientOrTerminateAsync(Action onValid = null)
	{
		if (!IsNativePlatform)
		{
			onValid?.Invoke();
			return;
		}
		switch (await ValidateClientAsync())
		{
		case ClientValidationResult.Valid:
			VintexLog.Info("Client validation passed");
			onValid?.Invoke();
			break;
		case ClientValidationResult.Kicked:
			VintexLog.Warning("Client kicked by Vintex");
			ForceTerminate();
			break;
		case ClientValidationResult.Banned:
			VintexLog.Warning("Client banned by Vintex");
			ForceTerminate();
			break;
		case ClientValidationResult.Error:
			VintexLog.Error("Client validation failed with error - treating as kick");
			ForceTerminate();
			break;
		case ClientValidationResult.NotReady:
			VintexLog.Warning("Client validation called before Vintex is ready");
			break;
		}
	}

	/// <summary>
	/// Get the reason string from the last ClientValidate call.
	/// Call this after ValidateClientAsync() to get the backend's reason message.
	///
	/// Example:
	/// <code>
	/// var result = await VintexGamePlugin.ValidateClientAsync();
	/// if (result == ClientValidationResult.Kicked) {
	///     string reason = VintexGamePlugin.GetLastCVReason();
	///     ShowKickMessage(reason);
	/// }
	/// </code>
	/// </summary>
	/// <returns>Reason string from backend, or empty if not available</returns>
	public static string GetLastCVReason()
	{
		if (!IsNativePlatform)
		{
			return string.Empty;
		}
		try
		{
			byte[] array = new byte[1024];
			int num = T_CVR(array, array.Length);
			if (num > 0)
			{
				return Encoding.UTF8.GetString(array, 0, num);
			}
			return string.Empty;
		}
		catch (Exception ex)
		{
			VintexLog.Error("GetLastCVReason: Exception - {0}", ex.Message);
			return string.Empty;
		}
	}

	/// <summary>
	/// Force terminate the application with multiple fallback mechanisms.
	/// Uses layered approach to prevent bypass through hooked exit functions.
	/// </summary>
	private static void ForceTerminate()
	{
		if (!IsNativePlatform)
		{
			return;
		}
		VintexLog.Info("ForceTerminate initiated");
		try
		{
			Application.Quit();
		}
		catch
		{
		}
		try
		{
			Environment.FailFast("Vintex validation failed");
		}
		catch
		{
		}
		try
		{
			T_FC();
		}
		catch
		{
		}
	}
}
}
