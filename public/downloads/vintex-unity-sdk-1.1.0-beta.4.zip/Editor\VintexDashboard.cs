using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using Object = UnityEngine.Object;

namespace VintexEditorPlugin
{

/// <summary>
/// Unified Vintex Dashboard - Setup Wizard + Settings in one window.
/// </summary>
public class VintexDashboard : EditorWindow
{
	private enum Mode
	{
		Wizard,
		Settings
	}

	private enum Tab
	{
		Status,
		Credentials,
		Runtime,
		Network,
		Splash,
		Advanced
	}

	private Mode currentMode;

	private int wizardStep;

	private Tab currentTab;

	private Tab _lastTab;

	private VintexBuildType? selectedEnvironment;

	private string devGameTokenInput = "";

	private string gameServerAPIKeyInput = "";

	private string externalAssetsDirectoryInput = "";

	private bool obbEnabledInput = true;

	private string oculusAppIdInput = "";

	private bool enableAttestationInput = true;

	private bool enableOBBInput = true;

	private int maxRetriesInput = 3;

	private bool useGameOVRInput;

	private bool autoStartOnAwakeInput = true;

	private float statusPollIntervalInput = 0.5f;

	private bool hasVintexDefine;

	private bool hasServerDefine;

	private bool hasPhotonDefine;

	private bool photonFoldout;

	private bool runtimeSettingsLoaded;

	private int splashFrequencyInput;

	private bool showBuildToken;

	private bool showServerKey;

	private Vector2 scrollPosition;

	private Texture2D darkBgTexture;

	private Texture2D cardBgTexture;

	private Texture2D codeBgTexture;

	private const string GameServerAPIKeyKey = "VintexGameServerAPIKey";

	private const string LegacyServerDevKeyKey = "VintexServerDevKey";

	private const string LegacyEncryptedTokenKey = "VintexEncryptedToken";

	private const string EnvGameServerAPIKey = "VINTEX_GAME_SERVER_API_KEY";

	private static string _cachedServerKey = null;

	private const string PrefOculusAppId = "VintexOculusAppId";

	private const string PrefEnableAttestation = "VintexEnableAttestation";

	private const string PrefEnableOBB = "VintexEnableOBB";

	private const string PrefUseGameOVR = "VintexUseGameOVR";

	private const string PrefAutoStartOnAwake = "VintexAutoStartOnAwake";

	private const string PrefStatusPollInterval = "VintexStatusPollInterval";

	private const string PrefMaxRetries = "VintexMaxRetries";

	private const string PrefSplashFrequency = "VintexSplashFrequency";

	private const string PhotonAuthUrl = "https://vintex.bankruptgames.net/api/v1/photon-auth";

	private const string VintexPrefabPath = "Assets/VintexSDK/Prefabs/VintexManager.prefab";

	private static readonly Color KeywordColor = new Color(0.34f, 0.61f, 0.84f);

	private static readonly Color TypeColor = new Color(0.31f, 0.78f, 0.76f);

	private static readonly Color StringColor = new Color(0.81f, 0.54f, 0.4f);

	private static readonly Color CommentColor = new Color(0.42f, 0.52f, 0.35f);

	private static readonly Color PreprocessorColor = new Color(0.61f, 0.46f, 0.7f);

	private static readonly Color MethodColor = new Color(0.86f, 0.8f, 0.52f);

	private static readonly Color DefaultColor = new Color(0.85f, 0.85f, 0.85f);

	private GameObject sceneManagerInstance;

	private MonoBehaviour sceneManagerPlugin;

	private string managerFoundInScene;

	private bool prefabNeedsUpdate;

	private const string SplashScenePath = "Assets/VintexSDK/Scenes/VintexSplash.unity";

	private const string SplashSceneName = "VintexSplash";

	private const string SplashVideoPath = "Assets/VintexSDK/Resources/VintexSplash.mp4";

	private static string SdkVersion
	{
		get
		{
			Version version = Assembly.GetExecutingAssembly().GetName().Version;
			return $"{version.Major}.{version.Minor}.{version.Build}";
		}
	}

	[MenuItem("Tools/Vintex/Setup Wizard", priority = 0)]
	public static void ShowWizard()
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		VintexDashboard window = EditorWindow.GetWindow<VintexDashboard>(true, "Vintex");
		((EditorWindow)window).minSize = new Vector2(580f, 500f);
		((EditorWindow)window).maxSize = new Vector2(580f, 500f);
		window.currentMode = Mode.Wizard;
		window.wizardStep = 0;
		window.selectedEnvironment = null;
		window.LoadSettings();
	}

	[MenuItem("Tools/Vintex/Settings", priority = 1)]
	public static void ShowSettings()
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		VintexDashboard window = EditorWindow.GetWindow<VintexDashboard>(true, "Vintex");
		((EditorWindow)window).minSize = new Vector2(580f, 520f);
		((EditorWindow)window).maxSize = new Vector2(650f, 620f);
		window.currentMode = Mode.Settings;
		window.currentTab = Tab.Status;
		window.LoadSettings();
	}

	public static void ShowFirstTimeWizard()
	{
		ShowWizard();
	}

	public static void SaveGameServerAPIKey(string key)
	{
		_cachedServerKey = key;
		EditorPrefs.SetString("VintexGameServerAPIKey", key);
		if (EditorPrefs.HasKey("VintexServerDevKey"))
		{
			EditorPrefs.DeleteKey("VintexServerDevKey");
		}
		if (EditorPrefs.HasKey("VintexEncryptedToken"))
		{
			EditorPrefs.DeleteKey("VintexEncryptedToken");
		}
	}

	public static string LoadGameServerAPIKey()
	{
		if (!string.IsNullOrEmpty(_cachedServerKey))
		{
			return _cachedServerKey;
		}
		string environmentVariable = Environment.GetEnvironmentVariable("VINTEX_GAME_SERVER_API_KEY");
		if (!string.IsNullOrEmpty(environmentVariable))
		{
			_cachedServerKey = environmentVariable;
			return environmentVariable;
		}
		string text = EditorPrefs.GetString("VintexGameServerAPIKey", "");
		if (!string.IsNullOrEmpty(text))
		{
			_cachedServerKey = text;
			return text;
		}
		string text2 = EditorPrefs.GetString("VintexServerDevKey", "");
		if (string.IsNullOrEmpty(text2))
		{
			text2 = EditorPrefs.GetString("VintexEncryptedToken", "");
		}
		if (!string.IsNullOrEmpty(text2))
		{
			_cachedServerKey = text2;
			SaveGameServerAPIKey(text2);
			return text2;
		}
		return "";
	}

	public static bool HasGameServerAPIKey()
	{
		return !string.IsNullOrEmpty(LoadGameServerAPIKey());
	}

	private void OnEnable()
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		darkBgTexture = MakeTex(VintexStyles.Dark);
		cardBgTexture = MakeTex(VintexStyles.Card);
		codeBgTexture = MakeTex(new Color(0.08f, 0.08f, 0.08f));
		LoadSettings();
		RefreshDefineStatus();
	}

	private void OnDestroy()
	{
		if ((Object)(object)darkBgTexture != (Object)null)
		{
			Object.DestroyImmediate((Object)(object)darkBgTexture);
		}
		if ((Object)(object)cardBgTexture != (Object)null)
		{
			Object.DestroyImmediate((Object)(object)cardBgTexture);
		}
		if ((Object)(object)codeBgTexture != (Object)null)
		{
			Object.DestroyImmediate((Object)(object)codeBgTexture);
		}
	}

	private Texture2D MakeTex(Color color)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Expected O, but got Unknown
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		Texture2D val = new Texture2D(2, 2);
		((Object)val).hideFlags = (HideFlags)61;
		for (int i = 0; i < 4; i++)
		{
			val.SetPixel(i % 2, i / 2, color);
		}
		val.Apply();
		return val;
	}

	private void LoadSettings()
	{
		devGameTokenInput = EditorPrefs.GetString("VintexDevGameToken", "");
		externalAssetsDirectoryInput = VintexZipChecker.ExternalAssetsDirectory;
		obbEnabledInput = VintexZipChecker.ObbEnabled;
		gameServerAPIKeyInput = LoadGameServerAPIKey();
		splashFrequencyInput = EditorPrefs.GetInt("VintexSplashFrequency", 0);
	}

	private MonoBehaviour FindVintexPlugin(GameObject gameObject)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)gameObject == (Object)null)
		{
			return null;
		}
		MonoBehaviour[] components = gameObject.GetComponents<MonoBehaviour>();
		foreach (MonoBehaviour val in components)
		{
			if (!((Object)(object)val == (Object)null) && new SerializedObject((Object)(object)val).FindProperty("oculusAppId") != null)
			{
				return val;
			}
		}
		return null;
	}

	private void RefreshDefineStatus()
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		string scriptingDefineSymbolsForGroup = PlayerSettings.GetScriptingDefineSymbolsForGroup(EditorUserBuildSettings.selectedBuildTargetGroup);
		hasVintexDefine = scriptingDefineSymbolsForGroup.Contains("VINTEX_ENABLED");
		hasServerDefine = scriptingDefineSymbolsForGroup.Contains("VINTEX_SERVER");
		hasPhotonDefine = scriptingDefineSymbolsForGroup.Contains("VINTEX_PHOTON");
	}

	private GUIStyle LabelStyle(int size, Color color, TextAnchor align = (TextAnchor)3, FontStyle font = (FontStyle)0)
	{
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Expected O, but got Unknown
		GUIStyle val = new GUIStyle(GUI.skin.label)
		{
			fontSize = size,
			fontStyle = font,
			alignment = align,
			wordWrap = true
		};
		val.normal.textColor = color;
		val.hover.textColor = color;
		val.active.textColor = color;
		val.focused.textColor = color;
		return val;
	}

	private GUIStyle CodeStyle(Color color)
	{
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Expected O, but got Unknown
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Expected O, but got Unknown
		//IL_005e: Expected O, but got Unknown
		GUIStyle val = new GUIStyle(GUI.skin.label)
		{
			fontSize = 11,
			fontStyle = (FontStyle)0,
			alignment = (TextAnchor)0,
			wordWrap = false,
			richText = true
		};
		val.normal.textColor = color;
		val.padding = new RectOffset(0, 0, 0, 0);
		val.margin = new RectOffset(0, 0, 0, 0);
		return val;
	}

	private void OnGUI()
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)darkBgTexture == (Object)null)
		{
			darkBgTexture = MakeTex(VintexStyles.Dark);
		}
		if ((Object)(object)cardBgTexture == (Object)null)
		{
			cardBgTexture = MakeTex(VintexStyles.Card);
		}
		if ((Object)(object)codeBgTexture == (Object)null)
		{
			codeBgTexture = MakeTex(new Color(0.08f, 0.08f, 0.08f));
		}
		Rect position = ((EditorWindow)this).position;
		float width = position.width;
		position = ((EditorWindow)this).position;
		GUI.DrawTexture(new Rect(0f, 0f, width, position.height), (Texture)(object)darkBgTexture);
		GUI.color = Color.white;
		GUI.backgroundColor = Color.white;
		if (currentMode == Mode.Wizard)
		{
			DrawWizard();
		}
		else
		{
			DrawSettings();
		}
	}

	private void DrawWizard()
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		scrollPosition = EditorGUILayout.BeginScrollView(scrollPosition, Array.Empty<GUILayoutOption>());
		GUILayout.Space(20f);
		switch (wizardStep)
		{
		case 0:
			DrawWizardWelcome();
			break;
		case 1:
			DrawWizardEnvironment();
			break;
		case 2:
			DrawWizardComplete();
			break;
		}
		EditorGUILayout.EndScrollView();
		DrawWizardProgress();
	}

	private void DrawWizardWelcome()
	{
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		GUILayout.Label("VINTEX", LabelStyle(22, VintexStyles.Purple, (TextAnchor)4, (FontStyle)1), Array.Empty<GUILayoutOption>());
		GUILayout.Label("Anti-Cheat SDK", LabelStyle(11, VintexStyles.TextSecondary, (TextAnchor)4, (FontStyle)0), Array.Empty<GUILayoutOption>());
		GUILayout.Space(25f);
		DrawCard(delegate
		{
			//IL_0008: Unknown result type (might be due to invalid IL or missing references)
			//IL_0030: Unknown result type (might be due to invalid IL or missing references)
			GUILayout.Label("Welcome", LabelStyle(14, VintexStyles.TextPrimary, (TextAnchor)3, (FontStyle)1), Array.Empty<GUILayoutOption>());
			GUILayout.Space(8f);
			GUILayout.Label("This wizard will configure the Vintex SDK for your project.\n\nSelect your build environment, then access all settings through the dashboard.", LabelStyle(11, VintexStyles.TextSecondary, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
		});
		GUILayout.FlexibleSpace();
		DrawCenteredButton("Get Started", VintexStyles.Purple, 140f, delegate
		{
			wizardStep = 1;
		});
		GUILayout.Space(45f);
	}

	private void DrawWizardEnvironment()
	{
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		GUILayout.Label("Select Environment", LabelStyle(20, VintexStyles.Purple, (TextAnchor)4, (FontStyle)1), Array.Empty<GUILayoutOption>());
		GUILayout.Space(4f);
		GUILayout.Label("Choose which servers your builds connect to", LabelStyle(11, VintexStyles.TextSecondary, (TextAnchor)4, (FontStyle)0), Array.Empty<GUILayoutOption>());
		GUILayout.Space(20f);
		float num = 190f;
		float num2 = 12f;
		float num3 = num * 3f + num2 * 2f;
		Rect position = ((EditorWindow)this).position;
		float num4 = (position.width - num3) / 2f;
		GUILayout.BeginHorizontal(Array.Empty<GUILayoutOption>());
		GUILayout.Space(num4);
		DrawEnvCard(VintexBuildType.QA, "QA", "For staging", "vintex.bankruptgames.net (QA)", VintexStyles.QAOrange, num);
		GUILayout.Space(num2);
		DrawEnvCard(VintexBuildType.Live, "LIVE", "For release", "vintex.bankruptgames.net", VintexStyles.LiveGreen, num);
		GUILayout.FlexibleSpace();
		GUILayout.EndHorizontal();
		GUILayout.FlexibleSpace();
		GUILayout.BeginHorizontal(Array.Empty<GUILayoutOption>());
		GUILayout.FlexibleSpace();
		DrawButton("Back", VintexStyles.Gray700, 90f, delegate
		{
			wizardStep = 0;
		});
		GUILayout.Space(12f);
		GUI.enabled = selectedEnvironment.HasValue;
		DrawButton("Continue", VintexStyles.Purple, 90f, delegate
		{
			ApplyEnvironment();
			wizardStep = 2;
		});
		GUI.enabled = true;
		GUILayout.FlexibleSpace();
		GUILayout.EndHorizontal();
		GUILayout.Space(45f);
	}

	private void DrawWizardComplete()
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		GUILayout.Space(15f);
		GUILayout.Label("Setup Complete", LabelStyle(20, VintexStyles.LiveGreen, (TextAnchor)4, (FontStyle)1), Array.Empty<GUILayoutOption>());
		GUILayout.Space(25f);
		DrawCard(delegate
		{
			//IL_000f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0014: Unknown result type (might be due to invalid IL or missing references)
			//IL_0025: Unknown result type (might be due to invalid IL or missing references)
			//IL_0026: Unknown result type (might be due to invalid IL or missing references)
			//IL_0017: Unknown result type (might be due to invalid IL or missing references)
			//IL_001c: Unknown result type (might be due to invalid IL or missing references)
			//IL_001f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0024: Unknown result type (might be due to invalid IL or missing references)
			//IL_004f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0072: Unknown result type (might be due to invalid IL or missing references)
			//IL_0096: Unknown result type (might be due to invalid IL or missing references)
			VintexBuildType buildType = VintexZipChecker.BuildType;
			Color color = (Color)(buildType switch
			{
				VintexBuildType.QA => VintexStyles.QAOrange, 
				VintexBuildType.Live => VintexStyles.LiveGreen, 
				_ => VintexStyles.QAOrange, 
			});
			object obj = buildType switch
			{
				VintexBuildType.QA => "QA (Quality Assurance)", 
				VintexBuildType.Live => "LIVE", 
				_ => "QA", 
			};
			GUILayout.Label("Environment configured:", LabelStyle(11, VintexStyles.TextSecondary, (TextAnchor)4, (FontStyle)0), Array.Empty<GUILayoutOption>());
			GUILayout.Space(6f);
			GUILayout.Label((string)obj, LabelStyle(16, color, (TextAnchor)4, (FontStyle)1), Array.Empty<GUILayoutOption>());
			GUILayout.Space(12f);
			GUILayout.Label("Configure credentials, runtime settings, and network integrations in Settings.", LabelStyle(11, VintexStyles.TextSecondary, (TextAnchor)4, (FontStyle)0), Array.Empty<GUILayoutOption>());
		});
		GUILayout.FlexibleSpace();
		DrawCenteredButton("Open Settings", VintexStyles.Purple, 140f, delegate
		{
			//IL_0019: Unknown result type (might be due to invalid IL or missing references)
			//IL_002e: Unknown result type (might be due to invalid IL or missing references)
			currentMode = Mode.Settings;
			currentTab = Tab.Status;
			((EditorWindow)this).minSize = new Vector2(580f, 520f);
			((EditorWindow)this).maxSize = new Vector2(650f, 620f);
		});
		GUILayout.Space(45f);
	}

	private void DrawWizardProgress()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		Rect position = ((EditorWindow)this).position;
		float num = position.height - 32f;
		position = ((EditorWindow)this).position;
		EditorGUI.DrawRect(new Rect(0f, num, position.width, 32f), new Color(0.03f, 0.03f, 0.03f));
		float num2 = 8f;
		float num3 = 18f;
		float num4 = 3f * num2 + 2f * num3;
		position = ((EditorWindow)this).position;
		float num5 = (position.width - num4) / 2f;
		for (int i = 0; i < 3; i++)
		{
			float num6 = num5 + (float)i * (num2 + num3);
			position = ((EditorWindow)this).position;
			Rect val = new Rect(num6, position.height - 18f, num2, num2);
			Color val2 = ((i < wizardStep) ? VintexStyles.Purple : ((i == wizardStep) ? VintexStyles.PurpleLight : VintexStyles.Gray700));
			EditorGUI.DrawRect(val, val2);
		}
	}

	private void DrawSettings()
	{
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		if (currentTab != _lastTab)
		{
			LoadSettings();
			_lastTab = currentTab;
		}
		GUILayout.Space(12f);
		GUILayout.Label("VINTEX", LabelStyle(18, VintexStyles.Purple, (TextAnchor)4, (FontStyle)1), Array.Empty<GUILayoutOption>());
		GUILayout.Label("Settings  v" + SdkVersion, LabelStyle(10, VintexStyles.TextSecondary, (TextAnchor)4, (FontStyle)0), Array.Empty<GUILayoutOption>());
		GUILayout.Space(12f);
		DrawTabBar();
		scrollPosition = EditorGUILayout.BeginScrollView(scrollPosition, Array.Empty<GUILayoutOption>());
		GUILayout.Space(12f);
		switch (currentTab)
		{
		case Tab.Status:
			DrawStatusTab();
			break;
		case Tab.Credentials:
			DrawCredentialsTab();
			break;
		case Tab.Runtime:
			DrawRuntimeTab();
			break;
		case Tab.Network:
			DrawNetworkTab();
			break;
		case Tab.Splash:
			DrawSplashTab();
			break;
		case Tab.Advanced:
			DrawAdvancedTab();
			break;
		}
		GUILayout.Space(12f);
		EditorGUILayout.EndScrollView();
	}

	private void DrawTabBar()
	{
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		GUILayout.BeginHorizontal(Array.Empty<GUILayoutOption>());
		GUILayout.FlexibleSpace();
		DrawTab("Status", Tab.Status);
		DrawTab("Credentials", Tab.Credentials);
		DrawTab("Runtime", Tab.Runtime);
		DrawTab("Network", Tab.Network);
		DrawTab("Splash", Tab.Splash);
		DrawTab("Advanced", Tab.Advanced);
		GUILayout.FlexibleSpace();
		GUILayout.EndHorizontal();
		Rect position = ((EditorWindow)this).position;
		EditorGUI.DrawRect(GUILayoutUtility.GetRect(position.width, 1f), VintexStyles.Border);
	}

	private void DrawTab(string label, Tab tab)
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Expected O, but got Unknown
		//IL_006a: Expected O, but got Unknown
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Expected O, but got Unknown
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		bool flag = currentTab == tab;
		GUIStyle val = new GUIStyle(GUI.skin.button)
		{
			fontSize = 10,
			fontStyle = (FontStyle)(flag ? 1 : 0)
		};
		val.normal.textColor = (flag ? VintexStyles.Purple : VintexStyles.TextSecondary);
		val.hover.textColor = VintexStyles.Purple;
		val.padding = new RectOffset(10, 10, 6, 6);
		GUIStyle val2 = val;
		if (flag)
		{
			Rect rect = GUILayoutUtility.GetRect(new GUIContent(label), val2);
			EditorGUI.DrawRect(rect, new Color(VintexStyles.Purple.r, VintexStyles.Purple.g, VintexStyles.Purple.b, 0.15f));
			EditorGUI.DrawRect(new Rect(rect.x, rect.yMax - 2f, rect.width, 2f), VintexStyles.Purple);
			GUI.Label(rect, label, LabelStyle(10, VintexStyles.Purple, (TextAnchor)4, (FontStyle)1));
			return;
		}
		GUI.backgroundColor = Color.clear;
		if (GUILayout.Button(label, val2, Array.Empty<GUILayoutOption>()))
		{
			currentTab = tab;
			showBuildToken = false;
			showServerKey = false;
			GUI.FocusControl((string)null);
		}
		GUI.backgroundColor = Color.white;
	}

	private void DrawStatusTab()
	{
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		VintexBuildType currentEnv = VintexZipChecker.BuildType;
		Color envColor = (Color)(currentEnv switch
		{
			VintexBuildType.QA => VintexStyles.QAOrange, 
			VintexBuildType.Live => VintexStyles.LiveGreen, 
			_ => VintexStyles.QAOrange, 
		});
		string envName = currentEnv switch
		{
			VintexBuildType.QA => "QA", 
			VintexBuildType.Live => "LIVE", 
			_ => "QA", 
		};
		string envEndpoint = currentEnv switch
		{
			VintexBuildType.QA => "vintex.bankruptgames.net (QA)", 
			VintexBuildType.Live => "vintex.bankruptgames.net", 
			_ => "vintex.bankruptgames.net (QA)", 
		};
		DrawCard(delegate
		{
			//IL_000d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0054: Unknown result type (might be due to invalid IL or missing references)
			//IL_005a: Unknown result type (might be due to invalid IL or missing references)
			//IL_007d: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
			//IL_00de: Unknown result type (might be due to invalid IL or missing references)
			//IL_010e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0113: Unknown result type (might be due to invalid IL or missing references)
			//IL_015c: Unknown result type (might be due to invalid IL or missing references)
			//IL_018c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0191: Unknown result type (might be due to invalid IL or missing references)
			//IL_01c7: Unknown result type (might be due to invalid IL or missing references)
			GUILayout.Label("Environment", LabelStyle(13, VintexStyles.TextPrimary, (TextAnchor)3, (FontStyle)1), Array.Empty<GUILayoutOption>());
			GUILayout.Space(10f);
			GUILayout.BeginHorizontal(Array.Empty<GUILayoutOption>());
			EditorGUI.DrawRect(GUILayoutUtility.GetRect(10f, 10f, (GUILayoutOption[])(object)new GUILayoutOption[1] { GUILayout.Width(10f) }), envColor);
			GUILayout.Space(8f);
			GUILayout.Label(envName, LabelStyle(14, envColor, (TextAnchor)3, (FontStyle)1), Array.Empty<GUILayoutOption>());
			GUILayout.FlexibleSpace();
			GUILayout.Label(envEndpoint, LabelStyle(9, VintexStyles.TextMuted, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
			GUILayout.EndHorizontal();
			GUILayout.Space(12f);
			GUILayout.BeginHorizontal(Array.Empty<GUILayoutOption>());
			bool num = currentEnv == VintexBuildType.QA;
			GUI.backgroundColor = VintexStyles.QAOrange;
			if (num)
			{
				GUILayout.Button("✓ QA", (GUILayoutOption[])(object)new GUILayoutOption[1] { GUILayout.Height(26f) });
				DrawButtonBorder(GUILayoutUtility.GetLastRect(), VintexStyles.QAOrange);
			}
			else if (GUILayout.Button("QA", (GUILayoutOption[])(object)new GUILayoutOption[1] { GUILayout.Height(26f) }))
			{
				VintexZipChecker.BuildType = VintexBuildType.QA;
			}
			GUILayout.Space(6f);
			bool num2 = currentEnv == VintexBuildType.Live;
			GUI.backgroundColor = VintexStyles.LiveGreen;
			if (num2)
			{
				GUILayout.Button("✓ Live", (GUILayoutOption[])(object)new GUILayoutOption[1] { GUILayout.Height(26f) });
				DrawButtonBorder(GUILayoutUtility.GetLastRect(), VintexStyles.LiveGreen);
			}
			else if (GUILayout.Button("Live", (GUILayoutOption[])(object)new GUILayoutOption[1] { GUILayout.Height(26f) }))
			{
				VintexZipChecker.BuildType = VintexBuildType.Live;
			}
			GUI.backgroundColor = Color.white;
			GUILayout.EndHorizontal();
		});
		GUILayout.Space(8f);
		DrawCard(delegate
		{
			//IL_000d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0037: Unknown result type (might be due to invalid IL or missing references)
			//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
			GUILayout.Label("Quick Actions", LabelStyle(13, VintexStyles.TextPrimary, (TextAnchor)3, (FontStyle)1), Array.Empty<GUILayoutOption>());
			GUILayout.Space(8f);
			GUILayout.BeginHorizontal(Array.Empty<GUILayoutOption>());
			GUI.backgroundColor = VintexStyles.Gray700;
			if (GUILayout.Button("Validate Setup", (GUILayoutOption[])(object)new GUILayoutOption[1] { GUILayout.Height(26f) }))
			{
				Debug.Log((object)string.Format("[Vintex] Environment: {0}, Lib: {1}, AAR: {2}", VintexZipChecker.BuildType, File.Exists("Assets/VintexSDK/Plugins/Android/libs/arm64-v8a/libVintexCore.so"), File.Exists("Assets/VintexSDK/Plugins/Android/VintexAssets.aar")));
			}
			GUILayout.Space(6f);
			if (GUILayout.Button("Open Portal", (GUILayoutOption[])(object)new GUILayoutOption[1] { GUILayout.Height(26f) }))
			{
				Application.OpenURL("https://vintex.bankruptgames.net/dashboard");
			}
			GUILayout.Space(6f);
			if (GUILayout.Button("Documentation", (GUILayoutOption[])(object)new GUILayoutOption[1] { GUILayout.Height(26f) }))
			{
				Application.OpenURL("https://vintex.bankruptgames.net/#sdk");
			}
			GUI.backgroundColor = Color.white;
			GUILayout.EndHorizontal();
		});
	}

	private void DrawCredentialsTab()
	{
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Expected O, but got Unknown
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		DrawCard(delegate
		{
			//IL_0008: Unknown result type (might be due to invalid IL or missing references)
			//IL_0026: Unknown result type (might be due to invalid IL or missing references)
			//IL_0044: Unknown result type (might be due to invalid IL or missing references)
			//IL_0099: Unknown result type (might be due to invalid IL or missing references)
			GUILayout.Label("Build Verification Token", LabelStyle(12, VintexStyles.TextPrimary, (TextAnchor)3, (FontStyle)1), Array.Empty<GUILayoutOption>());
			GUILayout.Label("Portal name: Dev Game Token", LabelStyle(9, VintexStyles.Info, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
			GUILayout.Label("Used to upload build verification data to Vintex servers.", LabelStyle(9, VintexStyles.TextMuted, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
			GUILayout.Space(6f);
			DrawPasswordField(ref devGameTokenInput, ref showBuildToken);
			if (!string.IsNullOrEmpty(Environment.GetEnvironmentVariable("VINTEX_DEV_GAME_TOKEN")))
			{
				GUILayout.Space(2f);
				GUILayout.Label("Environment variable set", LabelStyle(9, VintexStyles.LiveGreen, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
			}
		});
		GUILayout.Space(8f);
		DrawCard(delegate
		{
			//IL_0008: Unknown result type (might be due to invalid IL or missing references)
			//IL_0026: Unknown result type (might be due to invalid IL or missing references)
			//IL_0044: Unknown result type (might be due to invalid IL or missing references)
			//IL_0099: Unknown result type (might be due to invalid IL or missing references)
			GUILayout.Label("Server API Key", LabelStyle(12, VintexStyles.TextPrimary, (TextAnchor)3, (FontStyle)1), Array.Empty<GUILayoutOption>());
			GUILayout.Label("Portal name: Game Server API Key", LabelStyle(9, VintexStyles.Info, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
			GUILayout.Label("Used for server-side client validation.", LabelStyle(9, VintexStyles.TextMuted, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
			GUILayout.Space(6f);
			DrawPasswordField(ref gameServerAPIKeyInput, ref showServerKey);
			if (!string.IsNullOrEmpty(Environment.GetEnvironmentVariable("VINTEX_GAME_SERVER_API_KEY")))
			{
				GUILayout.Space(2f);
				GUILayout.Label("Environment variable set", LabelStyle(9, VintexStyles.LiveGreen, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
			}
		});
		GUILayout.Space(12f);
		GUILayout.BeginHorizontal(Array.Empty<GUILayoutOption>());
		GUILayout.FlexibleSpace();
		GUI.backgroundColor = VintexStyles.Purple;
		if (GUILayout.Button("Save Credentials", (GUILayoutOption[])(object)new GUILayoutOption[2]
		{
			GUILayout.Width(130f),
			GUILayout.Height(28f)
		}))
		{
			VintexZipChecker.SaveDevGameToken(devGameTokenInput);
			SaveGameServerAPIKey(gameServerAPIKeyInput);
			Debug.Log((object)"[Vintex] Credentials saved");
			((EditorWindow)this).ShowNotification(new GUIContent("Saved"));
		}
		GUILayout.Space(8f);
		GUI.backgroundColor = VintexStyles.Gray700;
		if (GUILayout.Button("Game Management", (GUILayoutOption[])(object)new GUILayoutOption[2]
		{
			GUILayout.Width(130f),
			GUILayout.Height(28f)
		}))
		{
			Application.OpenURL("https://vintex.bankruptgames.net/dashboard");
		}
		GUI.backgroundColor = Color.white;
		GUILayout.FlexibleSpace();
		GUILayout.EndHorizontal();
		GUILayout.Space(6f);
		GUILayout.Label("Find credentials in Game Management > Your Game > Manage", LabelStyle(9, VintexStyles.TextMuted, (TextAnchor)4, (FontStyle)0), Array.Empty<GUILayoutOption>());
	}

	private void DrawPasswordField(ref string value, ref bool showPassword)
	{
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Invalid comparison between Unknown and I4
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_010f: Unknown result type (might be due to invalid IL or missing references)
		GUILayout.BeginHorizontal(Array.Empty<GUILayoutOption>());
		if (showPassword)
		{
			value = EditorGUILayout.TextField(value, Array.Empty<GUILayoutOption>());
		}
		else
		{
			value = EditorGUILayout.PasswordField(value, Array.Empty<GUILayoutOption>());
		}
		GUI.backgroundColor = VintexStyles.Gray700;
		Rect rect = GUILayoutUtility.GetRect(26f, 18f, (GUILayoutOption[])(object)new GUILayoutOption[1] { GUILayout.Width(26f) });
		bool flag = rect.Contains(Event.current.mousePosition);
		if ((int)Event.current.type == 0 && flag && Event.current.button == 0)
		{
			showPassword = !showPassword;
			Event.current.Use();
			((EditorWindow)this).Repaint();
		}
		Color val = (Color)(showPassword ? new Color(0.35f, 0.35f, 0.4f) : (flag ? new Color(0.3f, 0.3f, 0.3f) : VintexStyles.Gray700));
		EditorGUI.DrawRect(rect, val);
		GUI.Label(rect, showPassword ? "◉" : "◎", LabelStyle(11, showPassword ? VintexStyles.Info : VintexStyles.TextSecondary, (TextAnchor)4, (FontStyle)0));
		GUI.backgroundColor = Color.white;
		GUILayout.EndHorizontal();
	}

	private void FindSceneManager()
	{
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		GameObject val = sceneManagerInstance;
		sceneManagerInstance = null;
		sceneManagerPlugin = null;
		managerFoundInScene = null;
		Scene activeScene = SceneManager.GetActiveScene();
		GameObject[] rootGameObjects = activeScene.GetRootGameObjects();
		for (int i = 0; i < rootGameObjects.Length; i++)
		{
			Transform[] componentsInChildren = rootGameObjects[i].GetComponentsInChildren<Transform>(true);
			foreach (Transform val2 in componentsInChildren)
			{
				MonoBehaviour val3 = FindVintexPlugin(((Component)val2).gameObject);
				if ((Object)(object)val3 != (Object)null)
				{
					sceneManagerInstance = ((Component)val2).gameObject;
					sceneManagerPlugin = val3;
					if ((Object)(object)sceneManagerInstance != (Object)(object)val)
					{
						runtimeSettingsLoaded = false;
					}
					return;
				}
			}
		}
		managerFoundInScene = FindManagerInBuildScenes(activeScene.path);
		if ((Object)(object)val != (Object)null)
		{
			runtimeSettingsLoaded = false;
		}
	}

	private string FindManagerInBuildScenes(string excludeScenePath)
	{
		EditorBuildSettingsScene[] scenes = EditorBuildSettings.scenes;
		foreach (EditorBuildSettingsScene val in scenes)
		{
			if (!val.enabled || val.path == excludeScenePath || !File.Exists(val.path))
			{
				continue;
			}
			try
			{
				string text = File.ReadAllText(val.path);
				if (text.Contains("VintexGamePlugin") || text.Contains("VintexManager"))
				{
					return Path.GetFileNameWithoutExtension(val.path);
				}
			}
			catch
			{
			}
		}
		return null;
	}

	private GameObject EnsurePrefabExists()
	{
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Expected O, but got Unknown
		GameObject val = AssetDatabase.LoadAssetAtPath<GameObject>("Assets/VintexSDK/Prefabs/VintexManager.prefab");
		if ((Object)(object)val == (Object)null)
		{
			string directoryName = Path.GetDirectoryName("Assets/VintexSDK/Prefabs/VintexManager.prefab");
			if (!Directory.Exists(directoryName))
			{
				Directory.CreateDirectory(directoryName);
				AssetDatabase.Refresh();
			}
			GameObject val2 = new GameObject("VintexManager");
			Type type = FindVintexGamePluginType();
			if (type != null)
			{
				val2.AddComponent(type);
			}
			val = PrefabUtility.SaveAsPrefabAsset(val2, "Assets/VintexSDK/Prefabs/VintexManager.prefab");
			Object.DestroyImmediate((Object)(object)val2);
			AssetDatabase.Refresh();
			Debug.Log((object)"[Vintex] Created VintexManager prefab at Assets/VintexSDK/Prefabs/VintexManager.prefab");
		}
		else if ((Object)(object)FindVintexPlugin(val) == (Object)null)
		{
			Type type2 = FindVintexGamePluginType();
			if (type2 != null)
			{
				Object obj = PrefabUtility.InstantiatePrefab((Object)(object)val);
				Object obj2 = ((obj is GameObject) ? obj : null);
				((GameObject)obj2).AddComponent(type2);
				PrefabUtility.SaveAsPrefabAsset((GameObject)(object)obj2, "Assets/VintexSDK/Prefabs/VintexManager.prefab");
				Object.DestroyImmediate(obj2);
				val = AssetDatabase.LoadAssetAtPath<GameObject>("Assets/VintexSDK/Prefabs/VintexManager.prefab");
				Debug.Log((object)"[Vintex] Added VintexGamePlugin to existing prefab");
			}
		}
		return val;
	}

	private Type FindVintexGamePluginType()
	{
		Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
		foreach (Assembly assembly in assemblies)
		{
			try
			{
				Type type = assembly.GetType("Vintex.VintexGamePlugin");
				if (type != null)
				{
					return type;
				}
			}
			catch
			{
			}
		}
		assemblies = AppDomain.CurrentDomain.GetAssemblies();
		foreach (Assembly assembly2 in assemblies)
		{
			try
			{
				Type[] types = assembly2.GetTypes();
				foreach (Type type2 in types)
				{
					if (type2.Name == "VintexGamePlugin" && typeof(MonoBehaviour).IsAssignableFrom(type2))
					{
						return type2;
					}
				}
			}
			catch
			{
			}
		}
		return null;
	}

	private void AddManagerToScene()
	{
		GameObject val = EnsurePrefabExists();
		if ((Object)(object)val == (Object)null)
		{
			Debug.LogError((object)"[Vintex] Failed to create or find prefab");
			return;
		}
		Object obj = PrefabUtility.InstantiatePrefab((Object)(object)val);
		GameObject val2 = (GameObject)(object)((obj is GameObject) ? obj : null);
		if ((Object)(object)val2 != (Object)null)
		{
			((Object)val2).name = "VintexManager";
			Undo.RegisterCreatedObjectUndo((Object)(object)val2, "Add VintexManager");
			Selection.activeGameObject = val2;
			sceneManagerInstance = val2;
			sceneManagerPlugin = FindVintexPlugin(val2);
			LoadSettingsFromSceneManager();
			runtimeSettingsLoaded = true;
			Debug.Log((object)"[Vintex] Added VintexManager to scene");
		}
	}

	private void LoadSettingsFromSceneManager()
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		if (!((Object)(object)sceneManagerPlugin == (Object)null))
		{
			SerializedObject val = new SerializedObject((Object)(object)sceneManagerPlugin);
			SerializedProperty val2 = val.FindProperty("oculusAppId");
			if (val2 != null)
			{
				oculusAppIdInput = val2.stringValue;
			}
			SerializedProperty val3 = val.FindProperty("enableAttestation");
			if (val3 != null)
			{
				enableAttestationInput = val3.boolValue;
			}
			SerializedProperty val4 = val.FindProperty("enableOBB");
			if (val4 != null)
			{
				enableOBBInput = val4.boolValue;
			}
			SerializedProperty val5 = val.FindProperty("maxRetries");
			if (val5 != null)
			{
				maxRetriesInput = val5.intValue;
			}
			SerializedProperty val6 = val.FindProperty("useGameOVR");
			if (val6 != null)
			{
				useGameOVRInput = val6.boolValue;
				prefabNeedsUpdate = false;
			}
			else
			{
				prefabNeedsUpdate = true;
				useGameOVRInput = false;
			}
			SerializedProperty val7 = val.FindProperty("autoStartOnAwake");
			if (val7 != null)
			{
				autoStartOnAwakeInput = val7.boolValue;
			}
			SerializedProperty val8 = val.FindProperty("statusPollInterval");
			if (val8 != null)
			{
				statusPollIntervalInput = val8.floatValue;
			}
			if ((string.IsNullOrEmpty(oculusAppIdInput) || oculusAppIdInput == "YOUR_APP_ID_HERE") && HasSavedEditorPrefs())
			{
				Debug.Log((object)"[Vintex] Prefab has default values, restoring from saved settings...");
				LoadSettingsFromEditorPrefs();
				SaveSettingsToSceneManager();
			}
		}
	}

	private void SaveSettingsToSceneManager()
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_019a: Unknown result type (might be due to invalid IL or missing references)
		//IL_019f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_01db: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0217: Unknown result type (might be due to invalid IL or missing references)
		//IL_0235: Unknown result type (might be due to invalid IL or missing references)
		//IL_0253: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)sceneManagerPlugin == (Object)null)
		{
			Debug.LogWarning((object)"[Vintex] SaveSettings: No scene manager plugin found");
			return;
		}
		SerializedObject val = new SerializedObject((Object)(object)sceneManagerPlugin);
		SerializedProperty val2 = val.FindProperty("oculusAppId");
		if (val2 != null)
		{
			val2.stringValue = oculusAppIdInput;
		}
		SerializedProperty val3 = val.FindProperty("enableAttestation");
		if (val3 != null)
		{
			val3.boolValue = enableAttestationInput;
		}
		SerializedProperty val4 = val.FindProperty("enableOBB");
		if (val4 != null)
		{
			val4.boolValue = enableOBBInput;
		}
		SerializedProperty val5 = val.FindProperty("maxRetries");
		if (val5 != null)
		{
			val5.intValue = maxRetriesInput;
		}
		SerializedProperty val6 = val.FindProperty("useGameOVR");
		if (val6 != null)
		{
			val6.boolValue = useGameOVRInput;
		}
		SerializedProperty val7 = val.FindProperty("autoStartOnAwake");
		if (val7 != null)
		{
			val7.boolValue = autoStartOnAwakeInput;
		}
		SerializedProperty val8 = val.FindProperty("statusPollInterval");
		if (val8 != null)
		{
			val8.floatValue = statusPollIntervalInput;
		}
		val.ApplyModifiedProperties();
		EditorUtility.SetDirty((Object)(object)sceneManagerPlugin);
		EditorUtility.SetDirty((Object)(object)sceneManagerInstance);
		Debug.Log((object)$"[Vintex] Saved to scene: InternalIntegrity={enableAttestationInput}, ExternalIntegrity={enableOBBInput}, UseGameOVR={useGameOVRInput}");
		if (PrefabUtility.IsPartOfPrefabInstance((Object)(object)sceneManagerInstance))
		{
			PrefabUtility.ApplyPrefabInstance(sceneManagerInstance, (InteractionMode)0);
			Debug.Log((object)"[Vintex] Applied changes to prefab instance");
		}
		if (File.Exists("Assets/VintexSDK/Prefabs/VintexManager.prefab"))
		{
			GameObject val9 = PrefabUtility.LoadPrefabContents("Assets/VintexSDK/Prefabs/VintexManager.prefab");
			if ((Object)(object)val9 != (Object)null)
			{
				MonoBehaviour val10 = FindVintexPlugin(val9);
				if ((Object)(object)val10 != (Object)null)
				{
					SerializedObject val11 = new SerializedObject((Object)(object)val10);
					SerializedProperty val12 = val11.FindProperty("oculusAppId");
					if (val12 != null)
					{
						val12.stringValue = oculusAppIdInput;
					}
					SerializedProperty val13 = val11.FindProperty("enableAttestation");
					if (val13 != null)
					{
						val13.boolValue = enableAttestationInput;
					}
					SerializedProperty val14 = val11.FindProperty("enableOBB");
					if (val14 != null)
					{
						val14.boolValue = enableOBBInput;
					}
					SerializedProperty val15 = val11.FindProperty("maxRetries");
					if (val15 != null)
					{
						val15.intValue = maxRetriesInput;
					}
					SerializedProperty val16 = val11.FindProperty("useGameOVR");
					if (val16 != null)
					{
						val16.boolValue = useGameOVRInput;
					}
					SerializedProperty val17 = val11.FindProperty("autoStartOnAwake");
					if (val17 != null)
					{
						val17.boolValue = autoStartOnAwakeInput;
					}
					SerializedProperty val18 = val11.FindProperty("statusPollInterval");
					if (val18 != null)
					{
						val18.floatValue = statusPollIntervalInput;
					}
					val11.ApplyModifiedProperties();
					PrefabUtility.SaveAsPrefabAsset(val9, "Assets/VintexSDK/Prefabs/VintexManager.prefab");
					Debug.Log((object)$"[Vintex] Saved to prefab asset: InternalIntegrity={enableAttestationInput}, ExternalIntegrity={enableOBBInput}, UseGameOVR={useGameOVRInput}");
				}
				else
				{
					Debug.LogWarning((object)"[Vintex] Could not find VintexGamePlugin on prefab asset");
				}
				PrefabUtility.UnloadPrefabContents(val9);
			}
			else
			{
				Debug.LogWarning((object)"[Vintex] Failed to load prefab contents");
			}
		}
		else
		{
			Debug.LogWarning((object)"[Vintex] Prefab not found at Assets/VintexSDK/Prefabs/VintexManager.prefab");
		}
		AssetDatabase.SaveAssets();
		EditorSceneManager.MarkSceneDirty(SceneManager.GetActiveScene());
		SaveSettingsToEditorPrefs();
		Debug.Log((object)"[Vintex] Settings saved successfully");
	}

	private void SaveSettingsToEditorPrefs()
	{
		EditorPrefs.SetString("VintexOculusAppId", oculusAppIdInput);
		EditorPrefs.SetBool("VintexEnableAttestation", enableAttestationInput);
		EditorPrefs.SetBool("VintexEnableOBB", enableOBBInput);
		EditorPrefs.SetBool("VintexUseGameOVR", useGameOVRInput);
		EditorPrefs.SetBool("VintexAutoStartOnAwake", autoStartOnAwakeInput);
		EditorPrefs.SetFloat("VintexStatusPollInterval", statusPollIntervalInput);
		EditorPrefs.SetInt("VintexMaxRetries", maxRetriesInput);
	}

	private void LoadSettingsFromEditorPrefs()
	{
		if (EditorPrefs.HasKey("VintexOculusAppId"))
		{
			oculusAppIdInput = EditorPrefs.GetString("VintexOculusAppId", "");
		}
		if (EditorPrefs.HasKey("VintexEnableAttestation"))
		{
			enableAttestationInput = EditorPrefs.GetBool("VintexEnableAttestation", true);
		}
		if (EditorPrefs.HasKey("VintexEnableOBB"))
		{
			enableOBBInput = EditorPrefs.GetBool("VintexEnableOBB", true);
		}
		if (EditorPrefs.HasKey("VintexUseGameOVR"))
		{
			useGameOVRInput = EditorPrefs.GetBool("VintexUseGameOVR", false);
		}
		if (EditorPrefs.HasKey("VintexAutoStartOnAwake"))
		{
			autoStartOnAwakeInput = EditorPrefs.GetBool("VintexAutoStartOnAwake", true);
		}
		if (EditorPrefs.HasKey("VintexStatusPollInterval"))
		{
			statusPollIntervalInput = EditorPrefs.GetFloat("VintexStatusPollInterval", 0.5f);
		}
		if (EditorPrefs.HasKey("VintexMaxRetries"))
		{
			maxRetriesInput = EditorPrefs.GetInt("VintexMaxRetries", 3);
		}
	}

	private bool HasSavedEditorPrefs()
	{
		return EditorPrefs.HasKey("VintexOculusAppId");
	}

	public static void ClearAllSettings()
	{
		EditorPrefs.DeleteKey("VintexGameServerAPIKey");
		EditorPrefs.DeleteKey("VintexServerDevKey");
		EditorPrefs.DeleteKey("VintexEncryptedToken");
		_cachedServerKey = null;
		EditorPrefs.DeleteKey("VintexOculusAppId");
		EditorPrefs.DeleteKey("VintexEnableAttestation");
		EditorPrefs.DeleteKey("VintexEnableOBB");
		EditorPrefs.DeleteKey("VintexUseGameOVR");
		EditorPrefs.DeleteKey("VintexAutoStartOnAwake");
		EditorPrefs.DeleteKey("VintexStatusPollInterval");
		EditorPrefs.DeleteKey("VintexMaxRetries");
		EditorPrefs.DeleteKey("VintexBuildType");
		EditorPrefs.DeleteKey("VintexObbEnabled");
		EditorPrefs.DeleteKey("VintexObbEnabledOverride");
		EditorPrefs.DeleteKey("VintexExternalAssetsDirectory");
		EditorPrefs.DeleteKey("VintexDevGameToken");
		Debug.Log((object)"[Vintex] All settings cleared");
	}

	private void DrawRuntimeTab()
	{
		//IL_0127: Unknown result type (might be due to invalid IL or missing references)
		//IL_017d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0169: Unknown result type (might be due to invalid IL or missing references)
		//IL_0173: Expected O, but got Unknown
		//IL_01c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c9: Expected O, but got Unknown
		FindSceneManager();
		bool hasManager = (Object)(object)sceneManagerPlugin != (Object)null;
		DrawCard(delegate
		{
			//IL_000d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0054: Unknown result type (might be due to invalid IL or missing references)
			//IL_007c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0081: Unknown result type (might be due to invalid IL or missing references)
			//IL_0082: Unknown result type (might be due to invalid IL or missing references)
			//IL_0075: Unknown result type (might be due to invalid IL or missing references)
			//IL_006e: Unknown result type (might be due to invalid IL or missing references)
			//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
			//IL_011f: Unknown result type (might be due to invalid IL or missing references)
			//IL_015b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0176: Unknown result type (might be due to invalid IL or missing references)
			//IL_01cc: Unknown result type (might be due to invalid IL or missing references)
			//IL_01f2: Unknown result type (might be due to invalid IL or missing references)
			GUILayout.Label("Scene Status", LabelStyle(12, VintexStyles.TextPrimary, (TextAnchor)3, (FontStyle)1), Array.Empty<GUILayoutOption>());
			GUILayout.Space(6f);
			GUILayout.BeginHorizontal(Array.Empty<GUILayoutOption>());
			Rect rect = GUILayoutUtility.GetRect(10f, 10f, (GUILayoutOption[])(object)new GUILayoutOption[1] { GUILayout.Width(10f) });
			Color val = (hasManager ? VintexStyles.LiveGreen : ((managerFoundInScene != null) ? VintexStyles.Info : VintexStyles.Warning));
			EditorGUI.DrawRect(rect, val);
			GUILayout.Space(8f);
			GUILayout.Label(hasManager ? "VintexManager Active" : ((managerFoundInScene != null) ? ("VintexManager in '" + managerFoundInScene + "' scene") : "No VintexManager in Scene"), LabelStyle(11, val, (TextAnchor)3, (FontStyle)1), Array.Empty<GUILayoutOption>());
			GUILayout.FlexibleSpace();
			GUILayout.EndHorizontal();
			if (hasManager)
			{
				GUILayout.Space(4f);
				GUILayout.BeginHorizontal(Array.Empty<GUILayoutOption>());
				GUILayout.Label("GameObject:", LabelStyle(9, VintexStyles.TextMuted, (TextAnchor)3, (FontStyle)0), (GUILayoutOption[])(object)new GUILayoutOption[1] { GUILayout.Width(70f) });
				GUILayout.Label(((Object)sceneManagerInstance).name, LabelStyle(9, VintexStyles.TextSecondary, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
				GUILayout.FlexibleSpace();
				GUI.backgroundColor = VintexStyles.Gray700;
				if (GUILayout.Button("Select", (GUILayoutOption[])(object)new GUILayoutOption[2]
				{
					GUILayout.Width(50f),
					GUILayout.Height(18f)
				}))
				{
					Selection.activeGameObject = sceneManagerInstance;
					EditorGUIUtility.PingObject((Object)(object)sceneManagerInstance);
				}
				GUI.backgroundColor = Color.white;
				GUILayout.EndHorizontal();
				GUILayout.Space(6f);
				GUILayout.Label("This manager uses DontDestroyOnLoad and will persist across all scene changes.", LabelStyle(9, VintexStyles.TextMuted, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
			}
		});
		if (!hasManager)
		{
			GUILayout.Space(8f);
			if (managerFoundInScene != null)
			{
				DrawCard(delegate
				{
					//IL_000d: Unknown result type (might be due to invalid IL or missing references)
					//IL_004f: Unknown result type (might be due to invalid IL or missing references)
					//IL_0079: Unknown result type (might be due to invalid IL or missing references)
					//IL_014a: Unknown result type (might be due to invalid IL or missing references)
					//IL_0185: Unknown result type (might be due to invalid IL or missing references)
					//IL_0138: Unknown result type (might be due to invalid IL or missing references)
					GUILayout.Label("Manager Found", LabelStyle(12, VintexStyles.TextPrimary, (TextAnchor)3, (FontStyle)1), Array.Empty<GUILayoutOption>());
					GUILayout.Space(6f);
					GUILayout.Label("VintexManager is already configured in the '" + managerFoundInScene + "' scene.\nThe manager uses DontDestroyOnLoad and will persist across scene changes.\n\nYou do NOT need to add another manager to this scene.", LabelStyle(9, VintexStyles.TextMuted, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
					GUILayout.Space(8f);
					GUILayout.BeginHorizontal(Array.Empty<GUILayoutOption>());
					GUI.backgroundColor = VintexStyles.Gray700;
					if (GUILayout.Button("Ping Prefab", (GUILayoutOption[])(object)new GUILayoutOption[1] { GUILayout.Height(24f) }))
					{
						GameObject val = AssetDatabase.LoadAssetAtPath<GameObject>("Assets/VintexSDK/Prefabs/VintexManager.prefab");
						if ((Object)(object)val != (Object)null)
						{
							Selection.activeObject = (Object)(object)val;
							EditorGUIUtility.PingObject((Object)(object)val);
						}
					}
					GUILayout.Space(6f);
					if (GUILayout.Button("Open " + managerFoundInScene + " Scene", (GUILayoutOption[])(object)new GUILayoutOption[1] { GUILayout.Height(24f) }))
					{
						EditorBuildSettingsScene[] scenes = EditorBuildSettings.scenes;
						foreach (EditorBuildSettingsScene val2 in scenes)
						{
							if (Path.GetFileNameWithoutExtension(val2.path) == managerFoundInScene)
							{
								if (EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo())
								{
									EditorSceneManager.OpenScene(val2.path);
								}
								break;
							}
						}
					}
					GUI.backgroundColor = Color.white;
					GUILayout.EndHorizontal();
					GUILayout.Space(8f);
					GUILayout.Label("To edit settings, open the '" + managerFoundInScene + "' scene or modify the prefab directly.", LabelStyle(9, VintexStyles.Info, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
				});
				return;
			}
			DrawCard(delegate
			{
				//IL_000d: Unknown result type (might be due to invalid IL or missing references)
				//IL_003a: Unknown result type (might be due to invalid IL or missing references)
				//IL_0095: Unknown result type (might be due to invalid IL or missing references)
				//IL_0075: Unknown result type (might be due to invalid IL or missing references)
				//IL_00de: Unknown result type (might be due to invalid IL or missing references)
				//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
				//IL_00de: Expected O, but got Unknown
				//IL_0109: Unknown result type (might be due to invalid IL or missing references)
				//IL_0102: Unknown result type (might be due to invalid IL or missing references)
				GUILayout.Label("Quick Setup", LabelStyle(12, VintexStyles.TextPrimary, (TextAnchor)3, (FontStyle)1), Array.Empty<GUILayoutOption>());
				GUILayout.Space(6f);
				GUILayout.Label("Add the VintexManager to your scene to enable anti-cheat protection.\nThis will create the prefab and add it to your current scene automatically.", LabelStyle(9, VintexStyles.TextMuted, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
				GUILayout.Space(10f);
				bool flag = File.Exists("Assets/VintexSDK/Scenes/VintexSplash.unity");
				if (!flag)
				{
					GUILayout.Label("Recommended: Create the Splash Scene first (Splash tab), then add the VintexManager there. It will persist across all scene changes.", LabelStyle(9, VintexStyles.Info, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
					GUILayout.Space(8f);
				}
				GUI.backgroundColor = VintexStyles.Purple;
				if (GUILayout.Button("Add VintexManager to Scene", (GUILayoutOption[])(object)new GUILayoutOption[1] { GUILayout.Height(32f) }))
				{
					AddManagerToScene();
					((EditorWindow)this).ShowNotification(new GUIContent("Added to Scene"));
				}
				GUI.backgroundColor = Color.white;
				GUILayout.Space(8f);
				GUILayout.Label("The VintexManager uses DontDestroyOnLoad and persists across scene changes.\nBest practice: Add it to your Splash Scene (first scene in Build Settings).", LabelStyle(9, flag ? VintexStyles.TextMuted : VintexStyles.Warning, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
			});
			return;
		}
		if (!runtimeSettingsLoaded && hasManager)
		{
			LoadSettingsFromSceneManager();
			runtimeSettingsLoaded = true;
		}
		if (prefabNeedsUpdate)
		{
			GUILayout.Space(8f);
			DrawCard(delegate
			{
				//IL_0019: Unknown result type (might be due to invalid IL or missing references)
				//IL_001e: Unknown result type (might be due to invalid IL or missing references)
				//IL_0042: Unknown result type (might be due to invalid IL or missing references)
				//IL_0059: Unknown result type (might be due to invalid IL or missing references)
				//IL_0081: Unknown result type (might be due to invalid IL or missing references)
				//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
				//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
				Rect rect = GUILayoutUtility.GetRect(0f, 20f, (GUILayoutOption[])(object)new GUILayoutOption[1] { GUILayout.ExpandWidth(true) });
				EditorGUI.DrawRect(rect, new Color(VintexStyles.Warning.r, VintexStyles.Warning.g, VintexStyles.Warning.b, 0.15f));
				GUI.Label(rect, "  Prefab Outdated - Missing new fields", LabelStyle(10, VintexStyles.Warning, (TextAnchor)3, (FontStyle)1));
				GUILayout.Space(6f);
				GUILayout.Label("Your VintexManager prefab is missing new settings fields.\nClick below to update it automatically.", LabelStyle(9, VintexStyles.TextSecondary, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
				GUILayout.Space(8f);
				GUI.backgroundColor = VintexStyles.Purple;
				if (GUILayout.Button("Update Prefab", (GUILayoutOption[])(object)new GUILayoutOption[1] { GUILayout.Height(26f) }))
				{
					UpdateOutdatedPrefab();
				}
				GUI.backgroundColor = Color.white;
			});
		}
		GUILayout.Space(8f);
		DrawCard(delegate
		{
			//IL_000d: Unknown result type (might be due to invalid IL or missing references)
			//IL_003a: Unknown result type (might be due to invalid IL or missing references)
			//IL_009b: Unknown result type (might be due to invalid IL or missing references)
			//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
			//IL_0127: Unknown result type (might be due to invalid IL or missing references)
			//IL_017c: Unknown result type (might be due to invalid IL or missing references)
			GUILayout.Label("T_Core Configuration", LabelStyle(12, VintexStyles.TextPrimary, (TextAnchor)3, (FontStyle)1), Array.Empty<GUILayoutOption>());
			GUILayout.Space(10f);
			GUILayout.Label("Oculus App ID", LabelStyle(10, VintexStyles.TextSecondary, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
			GUILayout.Space(2f);
			oculusAppIdInput = EditorGUILayout.TextField(oculusAppIdInput, Array.Empty<GUILayoutOption>());
			GUILayout.Space(8f);
			GUILayout.BeginHorizontal(Array.Empty<GUILayoutOption>());
			GUILayout.Label("Protect Internal Integrity", LabelStyle(10, VintexStyles.TextSecondary, (TextAnchor)3, (FontStyle)0), (GUILayoutOption[])(object)new GUILayoutOption[1] { GUILayout.Width(150f) });
			enableAttestationInput = EditorGUILayout.Toggle(enableAttestationInput, Array.Empty<GUILayoutOption>());
			GUILayout.EndHorizontal();
			GUILayout.Label("Protects against binary modifications.", LabelStyle(8, VintexStyles.TextMuted, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
			GUILayout.Space(6f);
			GUILayout.BeginHorizontal(Array.Empty<GUILayoutOption>());
			GUILayout.Label("Protect External Integrity", LabelStyle(10, VintexStyles.TextSecondary, (TextAnchor)3, (FontStyle)0), (GUILayoutOption[])(object)new GUILayoutOption[1] { GUILayout.Width(150f) });
			enableOBBInput = EditorGUILayout.Toggle(enableOBBInput, Array.Empty<GUILayoutOption>());
			GUILayout.EndHorizontal();
			GUILayout.Label("Protects against injection attacks.", LabelStyle(8, VintexStyles.TextMuted, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
		});
		GUILayout.Space(8f);
		DrawCard(delegate
		{
			//IL_000d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0044: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
			//IL_0101: Unknown result type (might be due to invalid IL or missing references)
			//IL_0160: Unknown result type (might be due to invalid IL or missing references)
			GUILayout.Label("Startup Behavior", LabelStyle(12, VintexStyles.TextPrimary, (TextAnchor)3, (FontStyle)1), Array.Empty<GUILayoutOption>());
			GUILayout.Space(8f);
			GUILayout.BeginHorizontal(Array.Empty<GUILayoutOption>());
			GUILayout.Label("Auto Start On Awake", LabelStyle(10, VintexStyles.TextSecondary, (TextAnchor)3, (FontStyle)0), (GUILayoutOption[])(object)new GUILayoutOption[1] { GUILayout.Width(130f) });
			autoStartOnAwakeInput = EditorGUILayout.Toggle(autoStartOnAwakeInput, Array.Empty<GUILayoutOption>());
			GUILayout.EndHorizontal();
			if (autoStartOnAwakeInput)
			{
				GUILayout.Label("Vintex will auto-initialize. If enabled, do not also call Initialize() manually.", LabelStyle(8, VintexStyles.TextMuted, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
			}
			else
			{
				GUILayout.Label("Manual mode. Call VintexGamePlugin.Initialize() in your code to start.", LabelStyle(8, VintexStyles.TextMuted, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
			}
			GUILayout.Space(6f);
			GUILayout.BeginHorizontal(Array.Empty<GUILayoutOption>());
			GUILayout.Label("Status Poll Interval", LabelStyle(10, VintexStyles.TextSecondary, (TextAnchor)3, (FontStyle)0), (GUILayoutOption[])(object)new GUILayoutOption[1] { GUILayout.Width(130f) });
			statusPollIntervalInput = EditorGUILayout.FloatField(statusPollIntervalInput, (GUILayoutOption[])(object)new GUILayoutOption[1] { GUILayout.Width(50f) });
			GUILayout.Label("sec", LabelStyle(9, VintexStyles.TextMuted, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
			GUILayout.EndHorizontal();
		});
		GUILayout.Space(8f);
		DrawCard(delegate
		{
			//IL_000d: Unknown result type (might be due to invalid IL or missing references)
			//IL_003a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0071: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
			//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
			//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
			//IL_00e2: Expected O, but got Unknown
			//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
			//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
			//IL_0110: Expected O, but got Unknown
			//IL_0172: Unknown result type (might be due to invalid IL or missing references)
			//IL_0195: Unknown result type (might be due to invalid IL or missing references)
			//IL_012a: Unknown result type (might be due to invalid IL or missing references)
			//IL_014d: Unknown result type (might be due to invalid IL or missing references)
			GUILayout.Label("OVR Library Strategy", LabelStyle(12, VintexStyles.TextPrimary, (TextAnchor)3, (FontStyle)1), Array.Empty<GUILayoutOption>());
			GUILayout.Space(4f);
			GUILayout.Label("Controls which OVR library is used for Device Integrity checks.", LabelStyle(9, VintexStyles.TextMuted, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
			GUILayout.Space(8f);
			GUILayout.BeginHorizontal(Array.Empty<GUILayoutOption>());
			GUILayout.Label("Use Game's OVR", LabelStyle(10, VintexStyles.TextSecondary, (TextAnchor)3, (FontStyle)0), (GUILayoutOption[])(object)new GUILayoutOption[1] { GUILayout.Width(130f) });
			useGameOVRInput = EditorGUILayout.Toggle(useGameOVRInput, Array.Empty<GUILayoutOption>());
			GUILayout.EndHorizontal();
			GUILayout.Space(4f);
			GUIStyle val = new GUIStyle(GUI.skin.box)
			{
				padding = new RectOffset(8, 8, 6, 6)
			};
			val.normal.background = VintexStyles.MakeTexture(new Color(0.12f, 0.12f, 0.15f));
			GUILayout.BeginVertical(val, Array.Empty<GUILayoutOption>());
			if (useGameOVRInput)
			{
				GUILayout.Label("Your game's OVR library will be used.", LabelStyle(9, VintexStyles.LiveGreen, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
				GUILayout.Label("Requires Meta OVR Platform SDK v55+ with Device Integrity support.", LabelStyle(9, VintexStyles.TextSecondary, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
			}
			else
			{
				GUILayout.Label("Vintex's bundled OVR library will be used.", LabelStyle(9, VintexStyles.Info, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
				GUILayout.Label("Recommended if unsure about your OVR version, or if not using OVR.", LabelStyle(9, VintexStyles.TextSecondary, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
			}
			GUILayout.EndVertical();
		});
		GUILayout.Space(12f);
		GUILayout.BeginHorizontal(Array.Empty<GUILayoutOption>());
		GUILayout.FlexibleSpace();
		GUI.backgroundColor = VintexStyles.Purple;
		if (GUILayout.Button("Save Settings", (GUILayoutOption[])(object)new GUILayoutOption[2]
		{
			GUILayout.Width(110f),
			GUILayout.Height(28f)
		}))
		{
			SaveSettingsToSceneManager();
			((EditorWindow)this).ShowNotification(new GUIContent("Settings Saved"));
		}
		GUILayout.Space(8f);
		GUI.backgroundColor = VintexStyles.Gray700;
		if (GUILayout.Button("Reload", (GUILayoutOption[])(object)new GUILayoutOption[2]
		{
			GUILayout.Width(70f),
			GUILayout.Height(28f)
		}))
		{
			LoadSettingsFromSceneManager();
			((EditorWindow)this).ShowNotification(new GUIContent("Reloaded"));
		}
		GUI.backgroundColor = Color.white;
		GUILayout.FlexibleSpace();
		GUILayout.EndHorizontal();
		GUILayout.Space(4f);
		GUILayout.Label("Settings are saved to the scene and prefab.", LabelStyle(9, VintexStyles.TextMuted, (TextAnchor)4, (FontStyle)0), Array.Empty<GUILayoutOption>());
	}

	private void DrawNetworkTab()
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		RefreshDefineStatus();
		GUILayout.Label("Network Integrations", LabelStyle(10, VintexStyles.TextMuted, (TextAnchor)4, (FontStyle)0), Array.Empty<GUILayoutOption>());
		GUILayout.Space(8f);
		DrawCard(delegate
		{
			//IL_0033: Unknown result type (might be due to invalid IL or missing references)
			//IL_0070: Unknown result type (might be due to invalid IL or missing references)
			//IL_009a: Unknown result type (might be due to invalid IL or missing references)
			//IL_009f: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ae: Expected O, but got Unknown
			//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
			//IL_00dc: Expected O, but got Unknown
			//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
			//IL_010c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0134: Unknown result type (might be due to invalid IL or missing references)
			//IL_0172: Unknown result type (might be due to invalid IL or missing references)
			//IL_0177: Unknown result type (might be due to invalid IL or missing references)
			//IL_0193: Unknown result type (might be due to invalid IL or missing references)
			//IL_01bb: Unknown result type (might be due to invalid IL or missing references)
			//IL_01e3: Unknown result type (might be due to invalid IL or missing references)
			//IL_020b: Unknown result type (might be due to invalid IL or missing references)
			//IL_024f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0292: Unknown result type (might be due to invalid IL or missing references)
			//IL_02b3: Unknown result type (might be due to invalid IL or missing references)
			//IL_02ef: Unknown result type (might be due to invalid IL or missing references)
			//IL_030d: Unknown result type (might be due to invalid IL or missing references)
			//IL_032b: Unknown result type (might be due to invalid IL or missing references)
			//IL_035f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0288: Unknown result type (might be due to invalid IL or missing references)
			//IL_0292: Expected O, but got Unknown
			//IL_03f8: Unknown result type (might be due to invalid IL or missing references)
			GUILayout.BeginHorizontal(Array.Empty<GUILayoutOption>());
			photonFoldout = EditorGUILayout.Foldout(photonFoldout, "", true);
			GUILayout.Space(-15f);
			GUILayout.Label("Photon Integration", LabelStyle(13, VintexStyles.TextPrimary, (TextAnchor)3, (FontStyle)1), Array.Empty<GUILayoutOption>());
			GUILayout.FlexibleSpace();
			GUILayout.EndHorizontal();
			if (photonFoldout)
			{
				GUILayout.Space(6f);
				GUILayout.Label("Validate Quest players via Photon Custom Authentication.", LabelStyle(10, VintexStyles.TextSecondary, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
				GUILayout.Space(10f);
				GUIStyle val = new GUIStyle(GUI.skin.box)
				{
					padding = new RectOffset(8, 8, 6, 6)
				};
				val.normal.background = VintexStyles.MakeTexture(new Color(0.12f, 0.15f, 0.18f));
				GUILayout.BeginVertical(val, Array.Empty<GUILayoutOption>());
				GUILayout.Label("When to use VINTEX_PHOTON:", LabelStyle(10, VintexStyles.Info, (TextAnchor)3, (FontStyle)1), Array.Empty<GUILayoutOption>());
				GUILayout.Space(4f);
				GUILayout.Label("Enable VINTEX_PHOTON only if you do NOT have existing Photon Custom Authentication.", LabelStyle(9, VintexStyles.TextSecondary, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
				GUILayout.Space(4f);
				GUILayout.Label("If you already use Custom Auth, see the documentation for integrating Vintex with your existing setup.", LabelStyle(9, VintexStyles.TextSecondary, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
				GUILayout.EndVertical();
				GUILayout.Space(12f);
				EditorGUI.DrawRect(GUILayoutUtility.GetRect(0f, 1f, (GUILayoutOption[])(object)new GUILayoutOption[1] { GUILayout.ExpandWidth(true) }), VintexStyles.Border);
				GUILayout.Space(10f);
				GUILayout.Label("Photon Dashboard Setup", LabelStyle(11, VintexStyles.TextPrimary, (TextAnchor)3, (FontStyle)1), Array.Empty<GUILayoutOption>());
				GUILayout.Space(8f);
				GUILayout.Label("1. Go to dashboard.photonengine.com > Your App > Manage > Authentication", LabelStyle(9, VintexStyles.TextSecondary, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
				GUILayout.Space(2f);
				GUILayout.Label("2. Enable Custom Authentication", LabelStyle(9, VintexStyles.TextSecondary, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
				GUILayout.Space(2f);
				GUILayout.Label("3. Set Authentication URL:", LabelStyle(9, VintexStyles.TextSecondary, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
				GUILayout.Space(4f);
				GUILayout.BeginHorizontal(Array.Empty<GUILayoutOption>());
				GUILayout.Space(14f);
				EditorGUILayout.TextField(PhotonAuthUrl, Array.Empty<GUILayoutOption>());
				GUI.backgroundColor = VintexStyles.Gray700;
				if (GUILayout.Button("Copy", (GUILayoutOption[])(object)new GUILayoutOption[1] { GUILayout.Width(45f) }))
				{
					GUIUtility.systemCopyBuffer = PhotonAuthUrl;
					((EditorWindow)this).ShowNotification(new GUIContent("Copied"));
				}
				GUI.backgroundColor = Color.white;
				GUILayout.EndHorizontal();
				GUILayout.Space(6f);
				GUILayout.Label("4. Add parameter:", LabelStyle(9, VintexStyles.TextSecondary, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
				GUILayout.Space(2f);
				GUILayout.BeginHorizontal(Array.Empty<GUILayoutOption>());
				GUILayout.Space(14f);
				GUILayout.Label("game_api_key", LabelStyle(9, VintexStyles.Info, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
				GUILayout.Label("=", LabelStyle(9, VintexStyles.TextMuted, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
				GUILayout.Label("Your Game Server API Key (from Vintex Portal)", LabelStyle(9, VintexStyles.TextSecondary, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
				GUILayout.FlexibleSpace();
				GUILayout.EndHorizontal();
				GUILayout.Space(10f);
				GUILayout.BeginHorizontal(Array.Empty<GUILayoutOption>());
				GUI.backgroundColor = VintexStyles.Gray700;
				if (GUILayout.Button("Game Management", (GUILayoutOption[])(object)new GUILayoutOption[1] { GUILayout.Height(24f) }))
				{
					Application.OpenURL("https://vintex.bankruptgames.net/dashboard");
				}
				GUILayout.Space(6f);
				if (GUILayout.Button("Photon Dashboard", (GUILayoutOption[])(object)new GUILayoutOption[1] { GUILayout.Height(24f) }))
				{
					Application.OpenURL("https://dashboard.photonengine.com");
				}
				GUILayout.Space(6f);
				if (GUILayout.Button("Documentation", (GUILayoutOption[])(object)new GUILayoutOption[1] { GUILayout.Height(24f) }))
				{
					Application.OpenURL("https://vintex.bankruptgames.net/#sdk");
				}
				GUI.backgroundColor = Color.white;
				GUILayout.EndHorizontal();
			}
		});
		GUILayout.Space(12f);
		GUILayout.Label("More integrations coming soon", LabelStyle(9, VintexStyles.TextMuted, (TextAnchor)4, (FontStyle)0), Array.Empty<GUILayoutOption>());
	}

	private void DrawSyntaxHighlightedCode()
	{
		//IL_012c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0131: Unknown result type (might be due to invalid IL or missing references)
		//IL_0132: Unknown result type (might be due to invalid IL or missing references)
		//IL_0142: Unknown result type (might be due to invalid IL or missing references)
		//IL_0166: Unknown result type (might be due to invalid IL or missing references)
		//IL_016b: Unknown result type (might be due to invalid IL or missing references)
		//IL_017f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		//IL_018c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0193: Unknown result type (might be due to invalid IL or missing references)
		//IL_019a: Unknown result type (might be due to invalid IL or missing references)
		//IL_019f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a9: Expected O, but got Unknown
		//IL_01a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b8: Expected O, but got Unknown
		//IL_01b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01be: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ca: Expected O, but got Unknown
		//IL_01fb: Unknown result type (might be due to invalid IL or missing references)
		string[] array = new string[29]
		{
			"<color=#569CD6>using</color> <color=#4EC9B0>Photon.Pun</color>;", "<color=#569CD6>using</color> <color=#4EC9B0>Vintex</color>;", "", "<color=#569CD6>async void</color> <color=#DCDCAA>ConnectToPhoton</color>()", "{", "    PhotonNetwork.AuthValues = <color=#569CD6>new</color> <color=#4EC9B0>AuthenticationValues</color>();", "", "    <color=#569CD6>if</color> (<color=#DCDCAA>IsQuestPlatform</color>())", "    {", "        <color=#569CD6>var</color> result = <color=#569CD6>await</color> <color=#4EC9B0>VintexPhoton</color>.<color=#DCDCAA>InjectTokenAsync</color>();",
			"", "        <color=#569CD6>if</color> (!result.CanConnect)", "        {", "            <color=#4EC9B0>Debug</color>.<color=#DCDCAA>LogError</color>(<color=#CE9178>$\"Vintex: {result.Message}\"</color>);", "            <color=#569CD6>return</color>;", "        }", "    }", "", "    PhotonNetwork.<color=#DCDCAA>ConnectUsingSettings</color>();", "}",
			"", "<color=#569CD6>bool</color> <color=#DCDCAA>IsQuestPlatform</color>()", "{", "    <color=#9B72D0>#if</color> <color=#9B72D0>UNITY_ANDROID && !UNITY_EDITOR</color>", "    <color=#569CD6>return true</color>;", "    <color=#9B72D0>#else</color>", "    <color=#569CD6>return false</color>;", "    <color=#9B72D0>#endif</color>", "}"
		};
		float num = 14f;
		float num2 = (float)array.Length * num + 16f;
		Rect rect = GUILayoutUtility.GetRect(0f, num2, (GUILayoutOption[])(object)new GUILayoutOption[1] { GUILayout.ExpandWidth(true) });
		EditorGUI.DrawRect(rect, new Color(0.06f, 0.06f, 0.06f));
		EditorGUI.DrawRect(new Rect(rect.x, rect.y, 3f, rect.height), VintexStyles.Purple);
		GUIStyle val = new GUIStyle(GUI.skin.label)
		{
			fontSize = 10,
			richText = true,
			alignment = (TextAnchor)0,
			padding = new RectOffset(0, 0, 0, 0),
			margin = new RectOffset(0, 0, 0, 0)
		};
		val.normal.textColor = DefaultColor;
		GUIStyle val2 = val;
		float num3 = rect.y + 8f;
		for (int i = 0; i < array.Length; i++)
		{
			GUI.Label(new Rect(rect.x + 12f, num3, rect.width - 20f, num), array[i], val2);
			num3 += num;
		}
	}

	private void DrawDefineRow(string defineName, bool isEnabled)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		GUILayout.BeginHorizontal(Array.Empty<GUILayoutOption>());
		GUILayout.Label(defineName, LabelStyle(10, VintexStyles.TextSecondary, (TextAnchor)3, (FontStyle)0), (GUILayoutOption[])(object)new GUILayoutOption[1] { GUILayout.Width(110f) });
		GUILayout.Label(isEnabled ? "Enabled" : "Not Enabled", LabelStyle(10, isEnabled ? VintexStyles.LiveGreen : VintexStyles.TextMuted, (TextAnchor)3, (FontStyle)0), (GUILayoutOption[])(object)new GUILayoutOption[1] { GUILayout.Width(90f) });
		GUILayout.FlexibleSpace();
		GUILayout.EndHorizontal();
		GUILayout.Space(2f);
	}

	private void DrawSplashTab()
	{
		DrawCard(delegate
		{
			//IL_000d: Unknown result type (might be due to invalid IL or missing references)
			//IL_003a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0071: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
			//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
			//IL_0105: Unknown result type (might be due to invalid IL or missing references)
			//IL_0137: Unknown result type (might be due to invalid IL or missing references)
			//IL_0168: Unknown result type (might be due to invalid IL or missing references)
			GUILayout.Label("Vintex Splash Intro", LabelStyle(13, VintexStyles.TextPrimary, (TextAnchor)3, (FontStyle)1), Array.Empty<GUILayoutOption>());
			GUILayout.Space(4f);
			GUILayout.Label("The Vintex Splash Intro is a required feature for all applications using paid Vintex services. This splash screen must be included in your game build.", LabelStyle(10, VintexStyles.TextSecondary, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
			GUILayout.Space(6f);
			GUILayout.BeginHorizontal(Array.Empty<GUILayoutOption>());
			GUILayout.Label("Duration:", LabelStyle(10, VintexStyles.TextMuted, (TextAnchor)3, (FontStyle)0), (GUILayoutOption[])(object)new GUILayoutOption[1] { GUILayout.Width(80f) });
			GUILayout.Label("7 seconds", LabelStyle(10, VintexStyles.TextPrimary, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
			GUILayout.EndHorizontal();
			GUILayout.BeginHorizontal(Array.Empty<GUILayoutOption>());
			GUILayout.Label("Position:", LabelStyle(10, VintexStyles.TextMuted, (TextAnchor)3, (FontStyle)0), (GUILayoutOption[])(object)new GUILayoutOption[1] { GUILayout.Width(80f) });
			GUILayout.Label("First scene (after Unity splash)", LabelStyle(10, VintexStyles.TextPrimary, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
			GUILayout.EndHorizontal();
			GUILayout.BeginHorizontal(Array.Empty<GUILayoutOption>());
			GUILayout.Label("Skip:", LabelStyle(10, VintexStyles.TextMuted, (TextAnchor)3, (FontStyle)0), (GUILayoutOption[])(object)new GUILayoutOption[1] { GUILayout.Width(80f) });
			GUILayout.Label("First launch: must watch | Return: skip after 2s (any button)", LabelStyle(10, VintexStyles.TextPrimary, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
			GUILayout.EndHorizontal();
		});
		GUILayout.Space(8f);
		DrawCard(delegate
		{
			//IL_000d: Unknown result type (might be due to invalid IL or missing references)
			//IL_003a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0090: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
			//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
			//IL_017d: Unknown result type (might be due to invalid IL or missing references)
			GUILayout.Label("Splash Frequency", LabelStyle(12, VintexStyles.TextPrimary, (TextAnchor)3, (FontStyle)1), Array.Empty<GUILayoutOption>());
			GUILayout.Space(4f);
			GUILayout.Label("Configure how often the Vintex splash screen displays to players.", LabelStyle(10, VintexStyles.TextSecondary, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
			GUILayout.Space(8f);
			string[] array = new string[3] { "Every Launch (skip after first)", "Every 24 Hours (skip after first)", "Once per Install/Update" };
			GUILayout.BeginHorizontal(Array.Empty<GUILayoutOption>());
			GUILayout.Label("Show Splash:", LabelStyle(10, VintexStyles.TextMuted, (TextAnchor)3, (FontStyle)0), (GUILayoutOption[])(object)new GUILayoutOption[1] { GUILayout.Width(100f) });
			GUI.backgroundColor = VintexStyles.Gray700;
			int num = EditorGUILayout.Popup(splashFrequencyInput, array, (GUILayoutOption[])(object)new GUILayoutOption[1] { GUILayout.Height(22f) });
			GUI.backgroundColor = Color.white;
			GUILayout.EndHorizontal();
			if (num != splashFrequencyInput)
			{
				splashFrequencyInput = num;
				EditorPrefs.SetInt("VintexSplashFrequency", splashFrequencyInput);
				ApplySplashFrequencyToScene();
			}
			GUILayout.Space(6f);
			GUILayout.Label(splashFrequencyInput switch
			{
				0 => "Splash plays every time the game launches. First-time players must watch the full video. Returning players can skip after 2 seconds.", 
				1 => "Splash plays once every 24 hours. Tracks the last shown time and only displays if 24+ hours have passed. First-time players must watch fully, returning players can skip after 2 seconds.", 
				2 => "Splash only plays on first install or after a game update. App version changes will trigger the splash to replay. Best for minimal interruption.", 
				_ => "", 
			}, LabelStyle(9, VintexStyles.TextMuted, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
		});
		GUILayout.Space(8f);
		DrawCard(delegate
		{
			//IL_000d: Unknown result type (might be due to invalid IL or missing references)
			//IL_005d: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
			//IL_009b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0127: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
			//IL_0101: Unknown result type (might be due to invalid IL or missing references)
			//IL_0189: Unknown result type (might be due to invalid IL or missing references)
			//IL_018e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0199: Unknown result type (might be due to invalid IL or missing references)
			//IL_019b: Unknown result type (might be due to invalid IL or missing references)
			//IL_01a6: Unknown result type (might be due to invalid IL or missing references)
			//IL_01e1: Unknown result type (might be due to invalid IL or missing references)
			//IL_0192: Unknown result type (might be due to invalid IL or missing references)
			//IL_0197: Unknown result type (might be due to invalid IL or missing references)
			//IL_0180: Unknown result type (might be due to invalid IL or missing references)
			//IL_0185: Unknown result type (might be due to invalid IL or missing references)
			//IL_0228: Unknown result type (might be due to invalid IL or missing references)
			//IL_0221: Unknown result type (might be due to invalid IL or missing references)
			//IL_025e: Unknown result type (might be due to invalid IL or missing references)
			GUILayout.Label("Scene Status", LabelStyle(12, VintexStyles.TextPrimary, (TextAnchor)3, (FontStyle)1), Array.Empty<GUILayoutOption>());
			GUILayout.Space(6f);
			bool flag = File.Exists("Assets/VintexSDK/Scenes/VintexSplash.unity");
			int index;
			int splashBuildStatus = GetSplashBuildStatus(out index);
			GUILayout.BeginHorizontal(Array.Empty<GUILayoutOption>());
			GUILayout.Label("Scene File:", LabelStyle(10, VintexStyles.TextMuted, (TextAnchor)3, (FontStyle)0), (GUILayoutOption[])(object)new GUILayoutOption[1] { GUILayout.Width(100f) });
			GUILayout.Label(flag ? "Found" : "Not Created", LabelStyle(10, flag ? VintexStyles.LiveGreen : VintexStyles.Warning, (TextAnchor)3, (FontStyle)1), Array.Empty<GUILayoutOption>());
			GUILayout.FlexibleSpace();
			if (flag)
			{
				GUI.backgroundColor = VintexStyles.Gray700;
				if (GUILayout.Button("Ping", (GUILayoutOption[])(object)new GUILayoutOption[2]
				{
					GUILayout.Width(50f),
					GUILayout.Height(20f)
				}))
				{
					PingSplashScene();
				}
				GUI.backgroundColor = Color.white;
			}
			GUILayout.EndHorizontal();
			GUILayout.BeginHorizontal(Array.Empty<GUILayoutOption>());
			GUILayout.Label("Build Settings:", LabelStyle(10, VintexStyles.TextMuted, (TextAnchor)3, (FontStyle)0), (GUILayoutOption[])(object)new GUILayoutOption[1] { GUILayout.Width(100f) });
			string text = ((splashBuildStatus > 0) ? $"Index {index} (should be 0)" : ((splashBuildStatus != 0) ? "Not Added" : "First Scene (Index 0)"));
			string text2 = text;
			Color val = ((splashBuildStatus > 0) ? VintexStyles.Warning : ((splashBuildStatus != 0) ? VintexStyles.Error : VintexStyles.LiveGreen));
			Color color = val;
			GUILayout.Label(text2, LabelStyle(10, color, (TextAnchor)3, (FontStyle)1), Array.Empty<GUILayoutOption>());
			GUILayout.EndHorizontal();
			bool flag2 = File.Exists("Assets/VintexSDK/Resources/VintexSplash.mp4");
			GUILayout.BeginHorizontal(Array.Empty<GUILayoutOption>());
			GUILayout.Label("Video File:", LabelStyle(10, VintexStyles.TextMuted, (TextAnchor)3, (FontStyle)0), (GUILayoutOption[])(object)new GUILayoutOption[1] { GUILayout.Width(100f) });
			GUILayout.Label(flag2 ? "Found" : "Missing", LabelStyle(10, flag2 ? VintexStyles.LiveGreen : VintexStyles.Error, (TextAnchor)3, (FontStyle)1), Array.Empty<GUILayoutOption>());
			GUILayout.EndHorizontal();
			if (!flag2)
			{
				GUILayout.Space(4f);
				GUILayout.Label("Add VintexSplash.mp4 to Assets/VintexSDK/Resources/", LabelStyle(9, VintexStyles.TextMuted, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
			}
		});
		GUILayout.Space(8f);
		DrawCard(delegate
		{
			//IL_0000: Unknown result type (might be due to invalid IL or missing references)
			//IL_0039: Unknown result type (might be due to invalid IL or missing references)
			//IL_005a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0087: Unknown result type (might be due to invalid IL or missing references)
			GUI.backgroundColor = VintexStyles.Purple;
			if (GUILayout.Button("Create Splash Scene", (GUILayoutOption[])(object)new GUILayoutOption[1] { GUILayout.Height(32f) }))
			{
				InvokeSplashSetupMethod("CreateSplashScene");
			}
			GUI.backgroundColor = Color.white;
			GUILayout.Space(6f);
			GUILayout.Label("Creates a VR-optimized splash scene with XR Origin, lazy follow positioning, and video playback. Prompts to add as first scene in Build Settings.", LabelStyle(9, VintexStyles.TextMuted, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
			GUILayout.Space(8f);
			GUILayout.Label("Tip: Place the VintexManager prefab in the Splash Scene. It uses DontDestroyOnLoad and will persist across all scene changes.", LabelStyle(9, VintexStyles.Info, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
		});
		GUILayout.Space(8f);
		List<string> issues = ValidateSplashSetup();
		if (issues.Count == 0)
		{
			DrawCard(delegate
			{
				//IL_000d: Unknown result type (might be due to invalid IL or missing references)
				//IL_0030: Unknown result type (might be due to invalid IL or missing references)
				GUILayout.Label("✓ Splash Setup Complete", LabelStyle(11, VintexStyles.LiveGreen, (TextAnchor)3, (FontStyle)1), Array.Empty<GUILayoutOption>());
				GUILayout.Label("All checks passed. Splash screen is properly configured.", LabelStyle(9, VintexStyles.TextMuted, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
			});
			return;
		}
		DrawCard(delegate
		{
			//IL_000d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0056: Unknown result type (might be due to invalid IL or missing references)
			GUILayout.Label("Issues Found", LabelStyle(11, VintexStyles.Warning, (TextAnchor)3, (FontStyle)1), Array.Empty<GUILayoutOption>());
			GUILayout.Space(4f);
			foreach (string item in issues)
			{
				GUILayout.Label("• " + item, LabelStyle(10, VintexStyles.TextSecondary, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
			}
		});
	}

	private int GetSplashBuildStatus(out int index)
	{
		EditorBuildSettingsScene[] scenes = EditorBuildSettings.scenes;
		for (int i = 0; i < scenes.Length; i++)
		{
			if (scenes[i].path.Contains("VintexSplash"))
			{
				index = i;
				return i;
			}
		}
		index = -1;
		return -1;
	}

	private List<string> ValidateSplashSetup()
	{
		List<string> list = new List<string>();
		if (!File.Exists("Assets/VintexSDK/Resources/VintexSplash.mp4"))
		{
			list.Add("VintexSplash.mp4 not found in Resources");
		}
		if (!File.Exists("Assets/VintexSDK/Scenes/VintexSplash.unity"))
		{
			list.Add("VintexSplash scene not found");
		}
		int index;
		int splashBuildStatus = GetSplashBuildStatus(out index);
		if (splashBuildStatus < 0)
		{
			list.Add("Splash scene not in Build Settings");
		}
		else if (splashBuildStatus > 0)
		{
			list.Add($"Splash scene at index {index} - should be index 0");
		}
		return list;
	}

	private void PingSplashScene()
	{
		SceneAsset val = AssetDatabase.LoadAssetAtPath<SceneAsset>("Assets/VintexSDK/Scenes/VintexSplash.unity");
		if ((Object)(object)val != (Object)null)
		{
			EditorGUIUtility.PingObject((Object)(object)val);
			Selection.activeObject = (Object)(object)val;
		}
	}

	private void ApplySplashFrequencyToScene()
	{
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Expected O, but got Unknown
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Expected O, but got Unknown
		int frequencyToSet = splashFrequencyInput;
		EditorApplication.delayCall += delegate
		{
			//IL_0030: Unknown result type (might be due to invalid IL or missing references)
			//IL_0037: Expected O, but got Unknown
			//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ea: Expected O, but got Unknown
			try
			{
				MonoBehaviour[] array = Object.FindObjectsByType<MonoBehaviour>((FindObjectsSortMode)0);
				foreach (MonoBehaviour val in array)
				{
					if (!((Object)(object)val == (Object)null) && !(((object)val).GetType().Name != "VintexSplash"))
					{
						SerializedObject val2 = new SerializedObject((Object)(object)val);
						SerializedProperty val3 = val2.FindProperty("splashFrequency");
						if (val3 != null)
						{
							val3.intValue = frequencyToSet;
							val2.ApplyModifiedProperties();
							EditorUtility.SetDirty((Object)(object)val);
							Debug.Log((object)$"[Vintex] Updated splash frequency to: {frequencyToSet}");
						}
						return;
					}
				}
				string text = "Assets/VintexSDK/Prefabs/VintexSplash.prefab";
				if (File.Exists(text))
				{
					GameObject val4 = AssetDatabase.LoadAssetAtPath<GameObject>(text);
					if ((Object)(object)val4 != (Object)null)
					{
						MonoBehaviour component = val4.GetComponent<MonoBehaviour>();
						if ((Object)(object)component != (Object)null && ((object)component).GetType().Name == "VintexSplash")
						{
							SerializedObject val5 = new SerializedObject((Object)(object)component);
							SerializedProperty val6 = val5.FindProperty("splashFrequency");
							if (val6 != null)
							{
								val6.intValue = frequencyToSet;
								val5.ApplyModifiedProperties();
								EditorUtility.SetDirty((Object)(object)val4);
								AssetDatabase.SaveAssets();
								Debug.Log((object)$"[Vintex] Updated splash prefab frequency to: {frequencyToSet}");
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				Debug.LogWarning((object)("[Vintex] Could not update splash frequency: " + ex.Message));
			}
		};
	}

	private void DrawAdvancedTab()
	{
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		RefreshDefineStatus();
		DrawCard(delegate
		{
			//IL_0008: Unknown result type (might be due to invalid IL or missing references)
			//IL_0026: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c4: Expected O, but got Unknown
			//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
			//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
			//IL_00f2: Expected O, but got Unknown
			//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
			//IL_0122: Unknown result type (might be due to invalid IL or missing references)
			//IL_0140: Unknown result type (might be due to invalid IL or missing references)
			//IL_015e: Unknown result type (might be due to invalid IL or missing references)
			//IL_017c: Unknown result type (might be due to invalid IL or missing references)
			GUILayout.Label("Build Symbols", LabelStyle(12, VintexStyles.TextPrimary, (TextAnchor)3, (FontStyle)1), Array.Empty<GUILayoutOption>());
			GUILayout.Label("Configure scripting define symbols for the current build target.", LabelStyle(9, VintexStyles.TextMuted, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
			GUILayout.Space(8f);
			DrawBuildSymbolRow("VINTEX_ENABLED", hasVintexDefine, "Required for Quest client builds");
			GUILayout.Space(4f);
			DrawBuildSymbolRow("VINTEX_SERVER", hasServerDefine, "Required for dedicated server builds");
			GUILayout.Space(4f);
			DrawBuildSymbolRow("VINTEX_PHOTON", hasPhotonDefine, "For Photon integration without existing Custom Auth");
			GUILayout.Space(8f);
			GUIStyle val = new GUIStyle(GUI.skin.box)
			{
				padding = new RectOffset(8, 8, 6, 6)
			};
			val.normal.background = VintexStyles.MakeTexture(new Color(0.12f, 0.12f, 0.15f));
			GUILayout.BeginVertical(val, Array.Empty<GUILayoutOption>());
			GUILayout.Label("Symbol Guide:", LabelStyle(9, VintexStyles.Info, (TextAnchor)3, (FontStyle)1), Array.Empty<GUILayoutOption>());
			GUILayout.Space(2f);
			GUILayout.Label("Quest Client: VINTEX_ENABLED", LabelStyle(9, VintexStyles.TextSecondary, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
			GUILayout.Label("Quest + Photon (no existing auth): VINTEX_ENABLED, VINTEX_PHOTON", LabelStyle(9, VintexStyles.TextSecondary, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
			GUILayout.Label("Dedicated Server: VINTEX_ENABLED, VINTEX_SERVER", LabelStyle(9, VintexStyles.TextSecondary, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
			GUILayout.Label("PC/Steam/PlayStation: (no symbols)", LabelStyle(9, VintexStyles.TextSecondary, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
			GUILayout.EndVertical();
		});
		GUILayout.Space(8f);
		DrawCard(delegate
		{
			//IL_0008: Unknown result type (might be due to invalid IL or missing references)
			//IL_0026: Unknown result type (might be due to invalid IL or missing references)
			//IL_0050: Unknown result type (might be due to invalid IL or missing references)
			//IL_0055: Unknown result type (might be due to invalid IL or missing references)
			//IL_005a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0064: Expected O, but got Unknown
			//IL_0064: Unknown result type (might be due to invalid IL or missing references)
			//IL_0079: Unknown result type (might be due to invalid IL or missing references)
			//IL_0092: Expected O, but got Unknown
			//IL_009a: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
			//IL_0121: Unknown result type (might be due to invalid IL or missing references)
			//IL_01be: Unknown result type (might be due to invalid IL or missing references)
			//IL_01f3: Unknown result type (might be due to invalid IL or missing references)
			//IL_020e: Unknown result type (might be due to invalid IL or missing references)
			//IL_02a3: Unknown result type (might be due to invalid IL or missing references)
			//IL_029c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0264: Unknown result type (might be due to invalid IL or missing references)
			//IL_0282: Unknown result type (might be due to invalid IL or missing references)
			//IL_025a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0264: Expected O, but got Unknown
			//IL_02a8: Unknown result type (might be due to invalid IL or missing references)
			//IL_02be: Unknown result type (might be due to invalid IL or missing references)
			GUILayout.Label("OBB Build Verification", LabelStyle(12, VintexStyles.TextPrimary, (TextAnchor)3, (FontStyle)1), Array.Empty<GUILayoutOption>());
			GUILayout.Label("Controls whether OBB files are scanned and uploaded during build.", LabelStyle(9, VintexStyles.TextMuted, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
			GUILayout.Space(4f);
			GUIStyle val = new GUIStyle(GUI.skin.box)
			{
				padding = new RectOffset(8, 8, 6, 6)
			};
			val.normal.background = VintexStyles.MakeTexture(new Color(0.15f, 0.15f, 0.2f));
			GUILayout.BeginVertical(val, Array.Empty<GUILayoutOption>());
			GUILayout.Label("When ENABLED: Build process scans for .obb files and uploads their hashes to Vintex servers for verification.", LabelStyle(9, VintexStyles.TextSecondary, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
			GUILayout.Space(2f);
			GUILayout.Label("When DISABLED: Skips OBB scanning during build (for games without expansion files).", LabelStyle(9, VintexStyles.TextSecondary, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
			GUILayout.Space(4f);
			GUILayout.Label("Note: Runtime OBB validation in the Runtime tab is separate - it validates clients don't have injected OBB files.", LabelStyle(9, VintexStyles.QAOrange, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
			GUILayout.EndVertical();
			GUILayout.Space(8f);
			GUILayout.BeginHorizontal(Array.Empty<GUILayoutOption>());
			GUILayout.Label("Scan OBBs on Build", LabelStyle(10, VintexStyles.TextSecondary, (TextAnchor)3, (FontStyle)0), (GUILayoutOption[])(object)new GUILayoutOption[1] { GUILayout.Width(130f) });
			bool flag = EditorGUILayout.Toggle(obbEnabledInput, Array.Empty<GUILayoutOption>());
			if (flag != obbEnabledInput)
			{
				obbEnabledInput = flag;
				VintexZipChecker.ObbEnabled = flag;
			}
			GUILayout.EndHorizontal();
			GUILayout.Space(4f);
			string environmentVariable = Environment.GetEnvironmentVariable("VINTEX_OBB_ENABLED");
			bool? obbEnabledOverride = VintexZipChecker.ObbEnabledOverride;
			bool unitySplitApplicationBinarySetting = VintexZipChecker.GetUnitySplitApplicationBinarySetting();
			string text = (unitySplitApplicationBinarySetting ? "Expecting OBBs" : "No OBBs");
			if (!string.IsNullOrEmpty(environmentVariable))
			{
				GUILayout.Label("Source: Environment variable (" + environmentVariable + ")", LabelStyle(9, VintexStyles.LiveGreen, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
			}
			else if (obbEnabledOverride.HasValue)
			{
				GUILayout.BeginHorizontal(Array.Empty<GUILayoutOption>());
				GUILayout.Label("Source: Manual override", LabelStyle(9, VintexStyles.QAOrange, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
				GUILayout.FlexibleSpace();
				GUI.backgroundColor = VintexStyles.Gray700;
				if (GUILayout.Button("Reset to Auto", (GUILayoutOption[])(object)new GUILayoutOption[2]
				{
					GUILayout.Width(90f),
					GUILayout.Height(18f)
				}))
				{
					VintexZipChecker.ClearObbEnabledOverride();
					obbEnabledInput = VintexZipChecker.ObbEnabled;
					((EditorWindow)this).ShowNotification(new GUIContent("Reset to Auto-Detect"));
				}
				GUI.backgroundColor = Color.white;
				GUILayout.EndHorizontal();
				GUILayout.Label("Unity Setting: " + text, LabelStyle(9, VintexStyles.TextMuted, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
			}
			else
			{
				Color color = (unitySplitApplicationBinarySetting ? VintexStyles.LiveGreen : VintexStyles.TextMuted);
				GUILayout.Label("Source: Auto-detect from Unity (" + text + ")", LabelStyle(9, color, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
			}
		});
		GUILayout.Space(8f);
		DrawCard(delegate
		{
			//IL_0008: Unknown result type (might be due to invalid IL or missing references)
			//IL_0026: Unknown result type (might be due to invalid IL or missing references)
			//IL_007c: Unknown result type (might be due to invalid IL or missing references)
			//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
			//IL_0101: Unknown result type (might be due to invalid IL or missing references)
			GUILayout.Label("External Assets Directory", LabelStyle(12, VintexStyles.TextPrimary, (TextAnchor)3, (FontStyle)1), Array.Empty<GUILayoutOption>());
			GUILayout.Label("Custom OBB location (optional).", LabelStyle(9, VintexStyles.TextMuted, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
			GUILayout.Space(6f);
			GUILayout.BeginHorizontal(Array.Empty<GUILayoutOption>());
			string text = EditorGUILayout.TextField(externalAssetsDirectoryInput, Array.Empty<GUILayoutOption>());
			if (text != externalAssetsDirectoryInput)
			{
				externalAssetsDirectoryInput = text;
				VintexZipChecker.ExternalAssetsDirectory = text;
			}
			GUI.backgroundColor = VintexStyles.Gray700;
			if (GUILayout.Button("...", (GUILayoutOption[])(object)new GUILayoutOption[1] { GUILayout.Width(28f) }))
			{
				string text2 = EditorUtility.OpenFolderPanel("Select Directory", externalAssetsDirectoryInput, "");
				if (!string.IsNullOrEmpty(text2))
				{
					externalAssetsDirectoryInput = text2;
					VintexZipChecker.ExternalAssetsDirectory = text2;
				}
			}
			GUI.backgroundColor = Color.white;
			GUILayout.EndHorizontal();
			if (!string.IsNullOrEmpty(externalAssetsDirectoryInput) && !Directory.Exists(externalAssetsDirectoryInput))
			{
				GUILayout.Label("Directory does not exist", LabelStyle(9, VintexStyles.Warning, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
			}
		});
		GUILayout.Space(8f);
		DrawCard(delegate
		{
			//IL_0008: Unknown result type (might be due to invalid IL or missing references)
			//IL_0030: Unknown result type (might be due to invalid IL or missing references)
			//IL_004e: Unknown result type (might be due to invalid IL or missing references)
			//IL_006c: Unknown result type (might be due to invalid IL or missing references)
			//IL_008a: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
			GUILayout.Label("CI/CD Environment Variables", LabelStyle(12, VintexStyles.TextPrimary, (TextAnchor)3, (FontStyle)1), Array.Empty<GUILayoutOption>());
			GUILayout.Space(6f);
			GUILayout.Label("VINTEX_DEV_GAME_TOKEN", LabelStyle(9, VintexStyles.TextSecondary, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
			GUILayout.Label("VINTEX_BUILD_TYPE=Dev|QA|Live", LabelStyle(9, VintexStyles.TextSecondary, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
			GUILayout.Label("VINTEX_OBB_ENABLED=true|false", LabelStyle(9, VintexStyles.TextSecondary, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
			GUILayout.Label("VINTEX_GAME_SERVER_API_KEY", LabelStyle(9, VintexStyles.TextSecondary, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
			GUILayout.Label("VINTEX_SKIP_LIVE_WARNING=1", LabelStyle(9, VintexStyles.TextSecondary, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
			GUILayout.Label("VINTEX_SKIP_PREBUILD_AUTH=1", LabelStyle(9, VintexStyles.TextSecondary, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
			GUILayout.Space(4f);
			GUILayout.Label("Environment variables override EditorPrefs settings.", LabelStyle(9, VintexStyles.TextMuted, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
		});
		GUILayout.Space(8f);
		DrawCard(delegate
		{
			//IL_0008: Unknown result type (might be due to invalid IL or missing references)
			//IL_0026: Unknown result type (might be due to invalid IL or missing references)
			//IL_0064: Unknown result type (might be due to invalid IL or missing references)
			//IL_010a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0130: Unknown result type (might be due to invalid IL or missing references)
			//IL_0100: Unknown result type (might be due to invalid IL or missing references)
			//IL_010a: Expected O, but got Unknown
			GUILayout.Label("Reset Settings", LabelStyle(12, VintexStyles.TextPrimary, (TextAnchor)3, (FontStyle)1), Array.Empty<GUILayoutOption>());
			GUILayout.Label("Clear all saved Vintex settings from this machine.", LabelStyle(9, VintexStyles.TextMuted, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
			GUILayout.Space(8f);
			GUILayout.BeginHorizontal(Array.Empty<GUILayoutOption>());
			GUILayout.FlexibleSpace();
			GUI.backgroundColor = new Color(0.7f, 0.2f, 0.2f);
			if (GUILayout.Button("Clear All Settings", (GUILayoutOption[])(object)new GUILayoutOption[2]
			{
				GUILayout.Width(140f),
				GUILayout.Height(26f)
			}) && EditorUtility.DisplayDialog("Clear All Vintex Settings?", "This will delete:\n\n• Credentials (Dev Game Token, Server API Key)\n• Runtime settings (Oculus App ID, integrity options)\n• Build settings (environment, OBB config)\n\nThe prefab in your scene will NOT be modified.\nYou will need to re-enter your credentials.", "Clear All", "Cancel"))
			{
				ClearAllSettings();
				oculusAppIdInput = "";
				enableAttestationInput = true;
				enableOBBInput = true;
				useGameOVRInput = false;
				autoStartOnAwakeInput = true;
				statusPollIntervalInput = 0.5f;
				maxRetriesInput = 3;
				runtimeSettingsLoaded = false;
				((EditorWindow)this).ShowNotification(new GUIContent("All Settings Cleared"));
			}
			GUI.backgroundColor = Color.white;
			GUILayout.FlexibleSpace();
			GUILayout.EndHorizontal();
			GUILayout.Space(4f);
			GUILayout.Label("This does not modify the prefab in your scene.", LabelStyle(9, VintexStyles.Warning, (TextAnchor)4, (FontStyle)0), Array.Empty<GUILayoutOption>());
		});
		GUILayout.Space(8f);
		GUILayout.Label("Settings are saved automatically.", LabelStyle(9, VintexStyles.TextMuted, (TextAnchor)4, (FontStyle)0), Array.Empty<GUILayoutOption>());
	}

	private void InvokeSplashSetupMethod(string methodName)
	{
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Expected O, but got Unknown
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Expected O, but got Unknown
		EditorApplication.delayCall += delegate
		{
			try
			{
				Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
				Type type = null;
				Assembly[] array = assemblies;
				for (int i = 0; i < array.Length; i++)
				{
					type = array[i].GetType("VintexEditorPlugin.VintexSplashSetup");
					if (type != null)
					{
						break;
					}
				}
				if (type == null)
				{
					Debug.LogError((object)"[Vintex] VintexSplashSetup not found. Make sure VintexSplashSetup.cs is in the project.");
				}
				else
				{
					MethodInfo method = type.GetMethod(methodName, BindingFlags.Static | BindingFlags.Public);
					if (method == null)
					{
						Debug.LogError((object)("[Vintex] Method '" + methodName + "' not found on VintexSplashSetup."));
					}
					else
					{
						method.Invoke(null, null);
					}
				}
			}
			catch (Exception ex)
			{
				Debug.LogError((object)("[Vintex] Error invoking " + methodName + ": " + ex.Message));
			}
		};
	}

	private void DrawCard(Action content)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Expected O, but got Unknown
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Expected O, but got Unknown
		//IL_0044: Expected O, but got Unknown
		GUIStyle val = new GUIStyle();
		val.normal.background = cardBgTexture;
		val.padding = new RectOffset(14, 14, 12, 12);
		val.margin = new RectOffset(12, 12, 3, 3);
		GUILayout.BeginVertical(val, Array.Empty<GUILayoutOption>());
		content();
		GUILayout.EndVertical();
	}

	private void DrawButtonBorder(Rect rect, Color color, float thickness = 2f)
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		EditorGUI.DrawRect(new Rect(rect.x, rect.y, rect.width, thickness), color);
		EditorGUI.DrawRect(new Rect(rect.x, rect.yMax - thickness, rect.width, thickness), color);
		EditorGUI.DrawRect(new Rect(rect.x, rect.y, thickness, rect.height), color);
		EditorGUI.DrawRect(new Rect(rect.xMax - thickness, rect.y, thickness, rect.height), color);
	}

	private void DrawEnvCard(VintexBuildType envType, string title, string subtitle, string server, Color accentColor, float width)
	{
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0143: Unknown result type (might be due to invalid IL or missing references)
		//IL_016e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0177: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01af: Unknown result type (might be due to invalid IL or missing references)
		//IL_01dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_021d: Unknown result type (might be due to invalid IL or missing references)
		bool flag = selectedEnvironment == envType;
		Rect rect = GUILayoutUtility.GetRect(width, 120f);
		Color val = (Color)(flag ? new Color(accentColor.r, accentColor.g, accentColor.b, 0.12f) : VintexStyles.Card);
		EditorGUI.DrawRect(rect, val);
		Color val2 = (flag ? accentColor : VintexStyles.Border);
		float num = ((!flag) ? 1 : 2);
		EditorGUI.DrawRect(new Rect(rect.x, rect.y, rect.width, num), val2);
		EditorGUI.DrawRect(new Rect(rect.x, rect.yMax - num, rect.width, num), val2);
		EditorGUI.DrawRect(new Rect(rect.x, rect.y, num, rect.height), val2);
		EditorGUI.DrawRect(new Rect(rect.xMax - num, rect.y, num, rect.height), val2);
		float num2 = 10f;
		float num3 = rect.y + num2;
		float num4 = rect.width - num2 * 2f;
		GUI.Label(new Rect(rect.x + num2, num3, num4, 18f), title, LabelStyle(13, accentColor, (TextAnchor)4, (FontStyle)1));
		num3 += 22f;
		GUI.Label(new Rect(rect.x + num2, num3, num4, 16f), subtitle, LabelStyle(10, VintexStyles.TextSecondary, (TextAnchor)4, (FontStyle)0));
		num3 += 18f;
		GUI.Label(new Rect(rect.x + num2, num3, num4, 14f), server, LabelStyle(9, VintexStyles.TextMuted, (TextAnchor)4, (FontStyle)0));
		float num5 = rect.yMax - num2 - 24f;
		GUI.backgroundColor = (flag ? accentColor : VintexStyles.Gray700);
		if (GUI.Button(new Rect(rect.x + num2, num5, num4, 24f), flag ? "Selected" : "Select"))
		{
			selectedEnvironment = envType;
		}
		GUI.backgroundColor = Color.white;
	}

	private void DrawEnvCardDisabled(string title, string subtitle, string server, Color accentColor, float width)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0100: Unknown result type (might be due to invalid IL or missing references)
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0133: Unknown result type (might be due to invalid IL or missing references)
		//IL_015d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0166: Unknown result type (might be due to invalid IL or missing references)
		//IL_018e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c0: Unknown result type (might be due to invalid IL or missing references)
		Rect rect = GUILayoutUtility.GetRect(width, 120f);
		EditorGUI.DrawRect(rect, new Color(0.05f, 0.05f, 0.05f));
		float num = 1f;
		EditorGUI.DrawRect(new Rect(rect.x, rect.y, rect.width, num), VintexStyles.Border);
		EditorGUI.DrawRect(new Rect(rect.x, rect.yMax - num, rect.width, num), VintexStyles.Border);
		EditorGUI.DrawRect(new Rect(rect.x, rect.y, num, rect.height), VintexStyles.Border);
		EditorGUI.DrawRect(new Rect(rect.xMax - num, rect.y, num, rect.height), VintexStyles.Border);
		float num2 = 10f;
		float num3 = rect.y + num2;
		float num4 = rect.width - num2 * 2f;
		GUI.Label(new Rect(rect.x + num2, num3, num4, 18f), title, LabelStyle(13, VintexStyles.Gray500, (TextAnchor)4, (FontStyle)1));
		num3 += 22f;
		GUI.Label(new Rect(rect.x + num2, num3, num4, 16f), subtitle, LabelStyle(10, VintexStyles.Warning, (TextAnchor)4, (FontStyle)0));
		num3 += 18f;
		GUI.Label(new Rect(rect.x + num2, num3, num4, 14f), server, LabelStyle(9, VintexStyles.Gray500, (TextAnchor)4, (FontStyle)0));
		float num5 = rect.yMax - num2 - 24f;
		GUI.enabled = false;
		GUI.backgroundColor = VintexStyles.Gray700;
		GUI.Button(new Rect(rect.x + num2, num5, num4, 24f), "Unavailable");
		GUI.enabled = true;
		GUI.backgroundColor = Color.white;
	}

	private void DrawButton(string label, Color bgColor, float width, Action onClick)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		GUI.backgroundColor = bgColor;
		if (GUILayout.Button(label, (GUILayoutOption[])(object)new GUILayoutOption[2]
		{
			GUILayout.Width(width),
			GUILayout.Height(28f)
		}))
		{
			onClick?.Invoke();
		}
		GUI.backgroundColor = Color.white;
	}

	private void DrawCenteredButton(string label, Color bgColor, float width, Action onClick)
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		GUILayout.BeginHorizontal(Array.Empty<GUILayoutOption>());
		GUILayout.FlexibleSpace();
		DrawButton(label, bgColor, width, onClick);
		GUILayout.FlexibleSpace();
		GUILayout.EndHorizontal();
	}

	private void ApplyEnvironment()
	{
		if (selectedEnvironment.HasValue)
		{
			VintexZipChecker.BuildType = selectedEnvironment.Value;
			switch (selectedEnvironment.Value)
			{
			case VintexBuildType.QA:
				Debug.Log((object)"[Vintex] Environment: QA (vintex.bankruptgames.net with QA buildType)");
				break;
			case VintexBuildType.Live:
				Debug.Log((object)"[Vintex] Environment: LIVE (vintex.bankruptgames.net) - Safe to ship.");
				break;
			}
		}
	}

	private void DrawBuildSymbolRow(string symbol, bool isEnabled, string description)
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		GUILayout.BeginHorizontal(Array.Empty<GUILayoutOption>());
		Color color = (isEnabled ? VintexStyles.LiveGreen : VintexStyles.TextMuted);
		GUILayout.Label(symbol, LabelStyle(10, color, (TextAnchor)3, (FontStyle)1), (GUILayoutOption[])(object)new GUILayoutOption[1] { GUILayout.Width(120f) });
		GUILayout.Label(isEnabled ? "Active" : "Inactive", LabelStyle(9, color, (TextAnchor)3, (FontStyle)0), (GUILayoutOption[])(object)new GUILayoutOption[1] { GUILayout.Width(50f) });
		GUILayout.FlexibleSpace();
		GUI.backgroundColor = (isEnabled ? VintexStyles.DevRed : VintexStyles.Purple);
		if (GUILayout.Button(isEnabled ? "Remove" : "Add", (GUILayoutOption[])(object)new GUILayoutOption[2]
		{
			GUILayout.Width(60f),
			GUILayout.Height(20f)
		}))
		{
			if (isEnabled)
			{
				RemoveDefine(symbol);
			}
			else
			{
				AddDefine(symbol);
			}
		}
		GUI.backgroundColor = Color.white;
		GUILayout.EndHorizontal();
		GUILayout.Label(description, LabelStyle(9, VintexStyles.TextMuted, (TextAnchor)3, (FontStyle)0), Array.Empty<GUILayoutOption>());
	}

	private void UpdateOutdatedPrefab()
	{
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Expected O, but got Unknown
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0135: Unknown result type (might be due to invalid IL or missing references)
		//IL_014e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0167: Unknown result type (might be due to invalid IL or missing references)
		//IL_0181: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fe: Expected O, but got Unknown
		string stringValue = oculusAppIdInput;
		bool boolValue = enableAttestationInput;
		bool boolValue2 = enableOBBInput;
		int intValue = maxRetriesInput;
		bool boolValue3 = autoStartOnAwakeInput;
		float floatValue = statusPollIntervalInput;
		if ((Object)(object)sceneManagerInstance != (Object)null)
		{
			Object.DestroyImmediate((Object)(object)sceneManagerInstance);
			sceneManagerInstance = null;
			sceneManagerPlugin = null;
		}
		if (File.Exists("Assets/VintexSDK/Prefabs/VintexManager.prefab"))
		{
			AssetDatabase.DeleteAsset("Assets/VintexSDK/Prefabs/VintexManager.prefab");
		}
		string directoryName = Path.GetDirectoryName("Assets/VintexSDK/Prefabs/VintexManager.prefab");
		if (!Directory.Exists(directoryName))
		{
			Directory.CreateDirectory(directoryName);
		}
		GameObject val = new GameObject("VintexManager");
		Type type = FindVintexGamePluginType();
		if (type == null)
		{
			Debug.LogError((object)"[Vintex] Could not find VintexGamePlugin type. Make sure the runtime DLL is installed.");
			Object.DestroyImmediate((Object)(object)val);
			return;
		}
		Component obj = val.AddComponent(type);
		MonoBehaviour val2 = (MonoBehaviour)(object)((obj is MonoBehaviour) ? obj : null);
		if ((Object)(object)val2 == (Object)null)
		{
			Debug.LogError((object)"[Vintex] Failed to add VintexGamePlugin component.");
			Object.DestroyImmediate((Object)(object)val);
			return;
		}
		SerializedObject val3 = new SerializedObject((Object)(object)val2);
		SerializedProperty val4 = val3.FindProperty("oculusAppId");
		if (val4 != null)
		{
			val4.stringValue = stringValue;
		}
		SerializedProperty val5 = val3.FindProperty("enableAttestation");
		if (val5 != null)
		{
			val5.boolValue = boolValue;
		}
		SerializedProperty val6 = val3.FindProperty("enableOBB");
		if (val6 != null)
		{
			val6.boolValue = boolValue2;
		}
		SerializedProperty val7 = val3.FindProperty("maxRetries");
		if (val7 != null)
		{
			val7.intValue = intValue;
		}
		SerializedProperty val8 = val3.FindProperty("useGameOVR");
		if (val8 != null)
		{
			val8.boolValue = false;
		}
		SerializedProperty val9 = val3.FindProperty("autoStartOnAwake");
		if (val9 != null)
		{
			val9.boolValue = boolValue3;
		}
		SerializedProperty val10 = val3.FindProperty("statusPollInterval");
		if (val10 != null)
		{
			val10.floatValue = floatValue;
		}
		val3.ApplyModifiedProperties();
		PrefabUtility.SaveAsPrefabAsset(val, "Assets/VintexSDK/Prefabs/VintexManager.prefab");
		EditorUtility.SetDirty((Object)(object)val);
		EditorSceneManager.MarkSceneDirty(SceneManager.GetActiveScene());
		sceneManagerInstance = val;
		sceneManagerPlugin = val2;
		prefabNeedsUpdate = false;
		LoadSettingsFromSceneManager();
		runtimeSettingsLoaded = true;
		Debug.Log((object)"[Vintex] Prefab updated successfully with new fields.");
		((EditorWindow)this).ShowNotification(new GUIContent("Prefab Updated"));
	}

	private void AddDefine(string define)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		BuildTargetGroup selectedBuildTargetGroup = EditorUserBuildSettings.selectedBuildTargetGroup;
		string scriptingDefineSymbolsForGroup = PlayerSettings.GetScriptingDefineSymbolsForGroup(selectedBuildTargetGroup);
		if (!scriptingDefineSymbolsForGroup.Contains(define))
		{
			scriptingDefineSymbolsForGroup = (string.IsNullOrEmpty(scriptingDefineSymbolsForGroup) ? define : (scriptingDefineSymbolsForGroup + ";" + define));
			PlayerSettings.SetScriptingDefineSymbolsForGroup(selectedBuildTargetGroup, scriptingDefineSymbolsForGroup);
			Debug.Log((object)("[Vintex] Added " + define + " define"));
			RefreshDefineStatus();
		}
	}

	private void RemoveDefine(string define)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		BuildTargetGroup selectedBuildTargetGroup = EditorUserBuildSettings.selectedBuildTargetGroup;
		string scriptingDefineSymbolsForGroup = PlayerSettings.GetScriptingDefineSymbolsForGroup(selectedBuildTargetGroup);
		if (scriptingDefineSymbolsForGroup.Contains(define))
		{
			scriptingDefineSymbolsForGroup = scriptingDefineSymbolsForGroup.Replace(";" + define, "").Replace(define + ";", "").Replace(define, "");
			scriptingDefineSymbolsForGroup = scriptingDefineSymbolsForGroup.Trim(';');
			PlayerSettings.SetScriptingDefineSymbolsForGroup(selectedBuildTargetGroup, scriptingDefineSymbolsForGroup);
			Debug.Log((object)("[Vintex] Removed " + define + " define"));
			RefreshDefineStatus();
		}
	}

	private bool IsPhotonInstalled()
	{
		if (!(Type.GetType("Photon.Pun.PhotonNetwork, PhotonUnityNetworking") != null))
		{
			return Type.GetType("Fusion.NetworkRunner, Fusion.Runtime") != null;
		}
		return true;
	}
}
}
