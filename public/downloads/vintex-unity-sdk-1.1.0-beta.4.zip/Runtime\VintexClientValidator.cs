using System;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.Networking;

namespace Vintex
{

/// <summary>
/// Server-side async validation for Quest clients.
/// Matches Unreal's UVintexClientValidator.
///
/// Usage:
/// 1. Create an instance of VintexClientValidator
/// 2. Subscribe to OnValidationSuccess and OnValidationFailure events
/// 3. Implement IVintexTokenProvider with your networking solution
/// 4. Configure the GameServerAPIKey via SetGameServerAPIKey() or VINTEX_GAME_SERVER_API_KEY environment variable
/// 5. Call ValidateClient() when a player joins
///
/// Get your GameServerAPIKey from:
/// Vintex Portal Dashboard &gt; Game Management &gt; Your Game
/// </summary>
public class VintexClientValidator
{
	/// <summary>
	/// Internal request structure for JSON serialization.
	/// </summary>
	[Serializable]
	private class SessionNonceRequest
	{
		public string sessionNonce;
	}

	private static bool _validationEnabled = true;

	private const string ValidationEndpoint = "https://vintex.bankruptgames.net/api/v1/validation/validate-user";

	private const string GameServerAPIKeyEnvVar = "VINTEX_GAME_SERVER_API_KEY";

	private const string LegacyEncryptedTokenEnvVar = "VINTEX_ENCRYPTED_TOKEN";

	private static string _cachedGameServerAPIKey = null;

	private static byte[] _cachedDecryptionKey = null;

	/// <summary>
	/// Fired when validation succeeds - player is allowed to play.
	/// Parameters: playerId, ValidationResult
	/// </summary>
	public event Action<string, ValidationResult> OnValidationSuccess;

	/// <summary>
	/// Fired when validation fails - player should be kicked with the provided reason.
	/// Parameters: playerId, reason
	/// </summary>
	public event Action<string, string> OnValidationFailure;

	/// <summary>
	/// Set the GameServerAPIKey at runtime (for server builds).
	/// Call this during server initialization with the key from Vintex Portal.
	/// The key is encrypted and will be decrypted automatically for API calls.
	///
	/// Get your GameServerAPIKey from:
	/// Vintex Portal Dashboard &gt; Game Management &gt; Your Game &gt; GameServerAPIKey
	/// </summary>
	/// <param name="serverDevKey">The GameServerAPIKey from Vintex Portal</param>
	public static void SetGameServerAPIKey(string serverDevKey)
	{
		_cachedGameServerAPIKey = serverDevKey;
		VintexLog.Info("VintexClientValidator: GameServerAPIKey configured for server validation");
	}

	/// <summary>
	/// Legacy method name for backwards compatibility.
	/// Use SetGameServerAPIKey() instead.
	/// </summary>
	[Obsolete("Use SetGameServerAPIKey() instead")]
	public static void SetEncryptedToken(string encryptedToken)
	{
		SetGameServerAPIKey(encryptedToken);
	}

	/// <summary>
	/// Set the decryption key for decrypting the GameServerAPIKey.
	/// Must be exactly 32 characters for AES-256.
	/// </summary>
	/// <param name="key">32-character decryption key</param>
	public static void SetDecryptionKey(string key)
	{
		if (string.IsNullOrEmpty(key))
		{
			VintexLog.Error("VintexClientValidator: Decryption key cannot be null or empty");
		}
		else if (key.Length != 32)
		{
			VintexLog.Error("VintexClientValidator: Decryption key must be exactly 32 characters (got {0})", key.Length);
		}
		else
		{
			_cachedDecryptionKey = Encoding.ASCII.GetBytes(key);
			VintexLog.Info("VintexClientValidator: Decryption key configured");
		}
	}

	/// <summary>
	/// Get the configured GameServerAPIKey.
	/// Checks: 1) Runtime cache, 2) Environment variable (VINTEX_GAME_SERVER_API_KEY), 3) Legacy env var
	/// </summary>
	/// <returns>The GameServerAPIKey, or empty string if not configured</returns>
	public static string GetGameServerAPIKey()
	{
		if (!string.IsNullOrEmpty(_cachedGameServerAPIKey))
		{
			return _cachedGameServerAPIKey;
		}
		string environmentVariable = Environment.GetEnvironmentVariable("VINTEX_GAME_SERVER_API_KEY");
		if (!string.IsNullOrEmpty(environmentVariable))
		{
			VintexLog.Info("VintexClientValidator: GameServerAPIKey loaded from environment variable");
			_cachedGameServerAPIKey = environmentVariable;
			return environmentVariable;
		}
		string environmentVariable2 = Environment.GetEnvironmentVariable("VINTEX_ENCRYPTED_TOKEN");
		if (!string.IsNullOrEmpty(environmentVariable2))
		{
			VintexLog.Info("VintexClientValidator: GameServerAPIKey loaded from legacy environment variable (VINTEX_ENCRYPTED_TOKEN)");
			_cachedGameServerAPIKey = environmentVariable2;
			return environmentVariable2;
		}
		return "";
	}

	/// <summary>
	/// Legacy method name for backwards compatibility.
	/// Use GetGameServerAPIKey() instead.
	/// </summary>
	[Obsolete("Use GetGameServerAPIKey() instead")]
	public static string GetEncryptedToken()
	{
		return GetGameServerAPIKey();
	}

	/// <summary>
	/// Check if a GameServerAPIKey is configured.
	/// </summary>
	public static bool HasGameServerAPIKey()
	{
		return !string.IsNullOrEmpty(GetGameServerAPIKey());
	}

	/// <summary>
	/// Legacy method name for backwards compatibility.
	/// Use HasGameServerAPIKey() instead.
	/// </summary>
	[Obsolete("Use HasGameServerAPIKey() instead")]
	public static bool HasEncryptedToken()
	{
		return HasGameServerAPIKey();
	}

	/// <summary>
	/// Enable or disable Vintex server validation globally.
	/// When disabled, all validation requests immediately return Success.
	/// Useful for development/testing or non-Vintex server builds.
	/// </summary>
	public static void SetValidationEnabled(bool enabled)
	{
		_validationEnabled = enabled;
		VintexLog.Info("VintexClientValidator: Server validation {0}", enabled ? "ENABLED" : "DISABLED");
	}

	/// <summary>
	/// Check if Vintex server validation is currently enabled.
	/// </summary>
	public static bool IsValidationEnabled()
	{
		return _validationEnabled;
	}

	/// <summary>
	/// Validate a client's Vintex session token.
	/// </summary>
	/// <param name="playerId">Unique identifier for the player</param>
	/// <param name="bearerToken">Your Vintex API key (optionally AES-256 encrypted).
	/// If null/empty, uses the token configured via SetEncryptedToken() or environment variable.</param>
	/// <param name="tokenProvider">Interface to request token from client</param>
	/// <param name="forcePlatformQuest">If true, empty tokens = failure (bypass attempt)</param>
	/// <param name="timeoutSeconds">Timeout for client response</param>
	/// <param name="cancellationToken">Optional cancellation token for external cancellation</param>
	public async Task ValidateClient(string playerId, string bearerToken, IVintexTokenProvider tokenProvider, bool forcePlatformQuest = false, float timeoutSeconds = 10f, CancellationToken cancellationToken = default(CancellationToken))
	{
		VintexLog.Info("VintexClientValidator: Starting validation for player {0}", playerId);
		if (!_validationEnabled)
		{
			VintexLog.Info("VintexClientValidator: Server validation disabled globally, auto-success");
			SafeInvokeSuccess(playerId, new ValidationResult
			{
				ActionCode = 0,
				Reason = "Validation disabled",
				IsUsingVPN = false
			});
			return;
		}
		string effectiveBearerToken = ((!string.IsNullOrEmpty(bearerToken)) ? bearerToken : GetGameServerAPIKey());
		if (string.IsNullOrEmpty(effectiveBearerToken))
		{
			VintexLog.Warning("VintexClientValidator: No GameServerAPIKey provided or configured");
			SafeInvokeFailure(playerId, "No GameServerAPIKey configured - get yours from Vintex Portal");
			return;
		}
		if (tokenProvider == null)
		{
			VintexLog.Error("VintexClientValidator: No token provider specified");
			SafeInvokeFailure(playerId, "Server configuration error");
			return;
		}
		string decryptedBearerToken = TryDecryptBearerToken(effectiveBearerToken);
		string requestId = Guid.NewGuid().ToString();
		VintexLog.Info("VintexClientValidator: Requesting token from client, RequestId={0}", requestId);
		using CancellationTokenSource timeoutCts = new CancellationTokenSource(TimeSpan.FromSeconds(timeoutSeconds));
		using CancellationTokenSource linkedCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken, timeoutCts.Token);
		string token;
		try
		{
			token = await tokenProvider.RequestTokenFromClient(playerId, requestId, timeoutSeconds);
			linkedCts.Token.ThrowIfCancellationRequested();
		}
		catch (OperationCanceledException)
		{
			if (timeoutCts.IsCancellationRequested)
			{
				VintexLog.Warning("VintexClientValidator: Timeout waiting for client token, RequestId={0}", requestId);
				SafeInvokeFailure(playerId, "Token request timeout - client did not respond");
			}
			else
			{
				VintexLog.Warning("VintexClientValidator: Validation cancelled for player {0}", playerId);
				SafeInvokeFailure(playerId, "Validation cancelled");
			}
			return;
		}
		catch (Exception ex2)
		{
			Exception ex3 = ex2;
			VintexLog.Error("VintexClientValidator: Exception requesting token - {0}", ex3.Message);
			SafeInvokeFailure(playerId, "Token request failed");
			return;
		}
		VintexLog.Info("VintexClientValidator: Token received, HasToken={0}", !string.IsNullOrEmpty(token));
		if (string.IsNullOrEmpty(token))
		{
			if (forcePlatformQuest)
			{
				VintexLog.Warning("VintexClientValidator: Empty token from verified Quest client - potential bypass attempt!");
				SafeInvokeFailure(playerId, "Invalid session token - verification required for Quest platform");
				return;
			}
			VintexLog.Info("VintexClientValidator: Empty token - client is non-Quest platform, auto-success");
			SafeInvokeSuccess(playerId, new ValidationResult
			{
				ActionCode = 0,
				Reason = "Non-Vintex client",
				IsUsingVPN = false
			});
			return;
		}
		VintexLog.Info("VintexClientValidator: Sending validation request to backend");
		ValidationResult result = await SendValidationRequest(decryptedBearerToken, token);
		if (result == null)
		{
			VintexLog.Error("VintexClientValidator: Backend request failed");
			SafeInvokeFailure(playerId, "Validation service unavailable");
			return;
		}
		VintexLog.Info("VintexClientValidator: Result - ActionCode={0}, Reason={1}, VPN={2}", result.ActionCode, result.Reason, result.IsUsingVPN);
		if (result.ActionCode == 0)
		{
			SafeInvokeSuccess(playerId, result);
		}
		else
		{
			SafeInvokeFailure(playerId, result.Reason);
		}
	}

	/// <summary>
	/// Safely invoke success event with exception handling.
	/// </summary>
	private void SafeInvokeSuccess(string playerId, ValidationResult result)
	{
		try
		{
			this.OnValidationSuccess?.Invoke(playerId, result);
		}
		catch (Exception ex)
		{
			VintexLog.Error("VintexClientValidator: Exception in OnValidationSuccess handler - {0}", ex.Message);
		}
	}

	/// <summary>
	/// Safely invoke failure event with exception handling.
	/// </summary>
	private void SafeInvokeFailure(string playerId, string reason)
	{
		try
		{
			this.OnValidationFailure?.Invoke(playerId, reason);
		}
		catch (Exception ex)
		{
			VintexLog.Error("VintexClientValidator: Exception in OnValidationFailure handler - {0}", ex.Message);
		}
	}

	/// <summary>
	/// Send validation request to Vintex backend.
	/// </summary>
	private async Task<ValidationResult> SendValidationRequest(string bearerToken, string sessionNonce)
	{
		try
		{
			string jsonBody = JsonUtility.ToJson((object)new SessionNonceRequest
			{
				sessionNonce = sessionNonce
			});
			UnityWebRequest request = new UnityWebRequest(ValidationEndpoint, "POST");
			try
			{
				byte[] bodyRaw = Encoding.UTF8.GetBytes(jsonBody);
				request.uploadHandler = (UploadHandler)new UploadHandlerRaw(bodyRaw);
				request.downloadHandler = (DownloadHandler)new DownloadHandlerBuffer();
				request.SetRequestHeader("Content-Type", "application/json");
				request.SetRequestHeader("Authorization", "Bearer " + bearerToken);
				UnityWebRequestAsyncOperation operation = request.SendWebRequest();
				while (!((AsyncOperation)operation).isDone)
				{
					await Task.Yield();
				}
				if ((int)request.result != 1)
				{
					VintexLog.Error("VintexClientValidator: HTTP error - {0}", request.error);
					return null;
				}
				if (request.responseCode != 200)
				{
					VintexLog.Warning("VintexClientValidator: HTTP {0} - {1}", request.responseCode, request.downloadHandler.text);
					if (request.responseCode == 401)
					{
						return new ValidationResult
						{
							ActionCode = 1,
							Reason = $"Invalid bearer token (HTTP {request.responseCode})",
							IsUsingVPN = false
						};
					}
					return null;
				}
				string responseText = request.downloadHandler.text;
				VintexLog.Info("VintexClientValidator: Response received");
				VintexValidationResponse response = JsonUtility.FromJson<VintexValidationResponse>(responseText);
				return response.ToResult();
			}
			finally
			{
				((IDisposable)request)?.Dispose();
			}
		}
		catch (Exception ex)
		{
			Exception ex2 = ex;
			VintexLog.Error("VintexClientValidator: Exception - {0}", ex2.Message);
			return null;
		}
	}

	/// <summary>
	/// Try to decrypt a Base64-encoded AES-256 encrypted bearer token.
	/// If decryption fails, assumes the token is already plaintext.
	/// </summary>
	private string TryDecryptBearerToken(string encryptedToken)
	{
		if (string.IsNullOrEmpty(encryptedToken))
		{
			VintexLog.Warning("VintexClientValidator: DecryptBearerToken - Empty input token provided");
			return encryptedToken;
		}
		if (_cachedDecryptionKey == null || _cachedDecryptionKey.Length != 32)
		{
			VintexLog.Info("VintexClientValidator: DecryptBearerToken - No decryption key configured, using token as-is");
			return encryptedToken;
		}
		VintexLog.Info("VintexClientValidator: DecryptBearerToken - Starting decryption, InputLen={0}", encryptedToken.Length);
		try
		{
			byte[] array;
			try
			{
				array = Convert.FromBase64String(encryptedToken);
				VintexLog.Info("VintexClientValidator: DecryptBearerToken - Base64 decoded successfully, ByteCount={0}", array.Length);
			}
			catch (FormatException)
			{
				VintexLog.Warning("VintexClientValidator: DecryptBearerToken - Base64 decode failed, input may not be encrypted");
				return encryptedToken;
			}
			if (array.Length == 0)
			{
				VintexLog.Warning("VintexClientValidator: DecryptBearerToken - Decoded bytes array is empty");
				return encryptedToken;
			}
			if (array.Length % 16 != 0)
			{
				VintexLog.Warning("VintexClientValidator: DecryptBearerToken - Invalid byte length {0} (must be multiple of 16 for AES)", array.Length);
				return encryptedToken;
			}
			VintexLog.Info("VintexClientValidator: DecryptBearerToken - Attempting AES decryption with {0} bytes", array.Length);
			using Aes aes = Aes.Create();
			aes.Key = _cachedDecryptionKey;
			aes.Mode = CipherMode.ECB;
			aes.Padding = PaddingMode.PKCS7;
			using ICryptoTransform cryptoTransform = aes.CreateDecryptor();
			byte[] array2 = cryptoTransform.TransformFinalBlock(array, 0, array.Length);
			if (array2.Length == 0)
			{
				VintexLog.Warning("VintexClientValidator: DecryptBearerToken - Decryption resulted in empty data");
				return encryptedToken;
			}
			string text = Encoding.UTF8.GetString(array2);
			bool flag = true;
			for (int i = 0; i < Math.Min(text.Length, 10); i++)
			{
				char c = text[i];
				if (c < ' ' || c > '~')
				{
					flag = false;
					break;
				}
			}
			if (!flag)
			{
				VintexLog.Warning("VintexClientValidator: DecryptBearerToken - Decrypted data contains non-printable characters, likely wrong key");
				return encryptedToken;
			}
			VintexLog.Info("VintexClientValidator: DecryptBearerToken - SUCCESS, DecryptedLen={0}", text.Length);
			return text;
		}
		catch (CryptographicException ex2)
		{
			VintexLog.Warning("VintexClientValidator: DecryptBearerToken - Cryptographic error (wrong key?): {0}", ex2.Message);
			return encryptedToken;
		}
		catch (Exception ex3)
		{
			VintexLog.Warning("VintexClientValidator: DecryptBearerToken - Unexpected error: {0}", ex3.Message);
			return encryptedToken;
		}
	}
}
}
