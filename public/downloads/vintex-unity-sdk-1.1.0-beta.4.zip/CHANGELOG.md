# Changelog

All notable changes to the Vintex Anticheat SDK are documented here. This
project adheres to [Semantic Versioning](https://semver.org/).

## [1.1.0-beta.4] - 2026-07-22

### Changed
- Removed the remaining pre-Vintex identifiers from source, documentation, filenames, and the Android native library.
- Renamed the server validator to `VintexClientValidator`.
- Renamed SDK scripting defines to `VINTEX_ENABLED`, `VINTEX_SERVER`, `VINTEX_PHOTON`, `VINTEX_LOGGING_ENABLED`, and `VINTEX_VERBOSE_LOGGING`.

## [1.1.0-beta.3] - 2026-07-22

### Fixed
- Added the missing `VintexSplash` runtime controller.
- Added the missing `VintexSplashSetup` editor scene generator.
- Splash setup now creates the first build scene and uses a branded fallback when no MP4 is present.

## [1.1.0-beta.2] - 2026-07-22

### Fixed
- Replaced C# 10 file-scoped namespaces so the SDK compiles under Unity's C# 9 language level.
- Normalized invalid decompiler ref-casts and editor callback assignments.
- Added explicit Unity object/debug aliases and the Newtonsoft editor assembly reference.
- Verified both runtime and editor assemblies with Unity 6000.0.77f1 compiler response files.

## [1.1.0-beta.1] - 2026-07-22

### Changed
- Switched runtime, Photon, build-registration, and dashboard links to
  `vintex.bankruptgames.net`.
- Matched the Unity editor palette to the Vintex blue-gray web dashboard.
- Rebuilt and stripped the Android arm64 native library from the current
  fail-closed native remake.

### Security
- Published as a beta while clean-room native attestation and OBB reconstruction
  remain under active validation.

## [1.0.0] - 2026-07-22

### Added
- Initial UPM package layout (`Runtime/`, `Editor/`, asmdefs, native plugin slot).
- `VintexGamePlugin` runtime with attestation, integrity polling, session-nonce
  lifecycle, and fail-closed `ValidateClientOrTerminateAsync`.
- `VintexClientValidator` server-side validation helper.
- Editor tooling: build dialog, CI/CD, dashboard, APK/OBB zip/hash checker.
- `libVintexCore.so` (arm64-v8a) native plugin.

### Security
- Native `T_CV` and the backend validation pipeline are fail-closed: unverifiable
  outcomes deny rather than allow.
- Runtime integrity detection (root / debugger / hook framework / emulator)
  surfaced in the signed session payload.
