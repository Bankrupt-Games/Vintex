using System;
using System.Text;

namespace Vintex;

/// <summary>
/// Helper class for client-side token retrieval.
/// Call this when you receive a token request from the server.
///
/// Usage on CLIENT when server requests token:
/// <code>
/// void OnServerRequestsToken(string requestId)
/// {
///     // Get token as bytes (recommended - matches Unreal's byte array transfer)
///     byte[] tokenBytes = VintexClientHelper.GetTokenBytesForServer();
///
///     // Or as string if your networking prefers that
///     string token = VintexClientHelper.GetTokenForServer();
///
///     // Send back via your RPC
///     SendTokenResponseToServer(requestId, tokenBytes);
/// }
/// </code>
/// </summary>
public static class VintexClientHelper
{
	/// <summary>
	/// Get the session token as a byte array to send back to server.
	/// RECOMMENDED: Use this for reliable network transfer (matches Unreal's implementation).
	///
	/// Call this on the CLIENT when server requests validation.
	/// Returns UTF-8 encoded bytes, or empty array on non-Quest platforms.
	/// </summary>
	/// <returns>Token as UTF-8 bytes, or empty array if unavailable</returns>
	public static byte[] GetTokenBytesForServer()
	{
		string tokenForServer = GetTokenForServer();
		if (string.IsNullOrEmpty(tokenForServer))
		{
			return Array.Empty<byte>();
		}
		return Encoding.UTF8.GetBytes(tokenForServer);
	}

	/// <summary>
	/// Get the session token as a string to send back to server.
	/// Call this on the CLIENT when server requests validation.
	///
	/// Returns the current session nonce if Vintex is available and completed,
	/// or an empty string on non-Quest platforms.
	/// </summary>
	public static string GetTokenForServer()
	{
		VintexGamePlugin.IsReady();
		return VintexGamePlugin.GetSessionNonceStatic();
	}

	/// <summary>
	/// Check if this client can provide a valid session token.
	/// Use this to determine if you need to request validation from the server.
	/// </summary>
	/// <returns>true if this is a Quest client with Vintex completed</returns>
	public static bool CanProvideToken()
	{
		return VintexGamePlugin.IsReady();
	}
}
