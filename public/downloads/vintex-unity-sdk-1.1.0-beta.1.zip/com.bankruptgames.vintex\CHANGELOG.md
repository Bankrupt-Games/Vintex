# Changelog

All notable changes to the Vintex Anticheat SDK are documented here. This
project adheres to [Semantic Versioning](https://semver.org/).

## [1.1.0-beta.1] - 2026-07-22

### Changed
- Switched runtime, Photon, build-registration, and dashboard links to
  `vintex.bankruptgames.net`.
- Matched the Unity editor palette to the Vintex blue-gray web dashboard.
- Rebuilt and stripped the Android arm64 native library from the current
  fail-closed native remake.

### Security
- Published as a beta while clean-room native attestation and OBB reconstruction
  remain under active validation.

## [1.0.0] - 2026-07-22

### Added
- Initial UPM package layout (`Runtime/`, `Editor/`, asmdefs, native plugin slot).
- `VintexGamePlugin` runtime with attestation, integrity polling, session-nonce
  lifecycle, and fail-closed `ValidateClientOrTerminateAsync`.
- `TH_ValidateClientAsync` server-side validation helper.
- Editor tooling: build dialog, CI/CD, dashboard, APK/OBB zip/hash checker.
- `libVintexCore.so` (arm64-v8a) native plugin.

### Security
- Native `T_CV` and the backend validation pipeline are fail-closed: unverifiable
  outcomes deny rather than allow.
- Runtime integrity detection (root / debugger / hook framework / emulator)
  surfaced in the signed session payload.
