# Vintex Anticheat SDK

Client-side integrity, attestation, and server validation for Meta Quest
(Android) Unity titles. This package ships:

- **`VintexGamePlugin`** — the runtime MonoBehaviour that drives the native
  `VintexCore` library (attestation, integrity, session-nonce lifecycle).
- **`TH_ValidateClientAsync`** — server-side validation helper for dedicated
  Unity servers.
- **Editor tooling** — build dialog, CI/CD hooks, dashboard, and APK/OBB
  zip/hash checker.
- **`libVintexCore.so`** — the arm64-v8a native plugin.

> Requires the Vintex service at `https://vintex.bankruptgames.net` and a
> per-build asset produced by `tools/VintexKeygen`.

> **Beta notice:** the native remake is fail-closed and includes runtime
> integrity checks, but its clean-room attestation and OBB reconstruction is
> still being completed. Test this package on real Quest hardware before using
> it to gate a production release.

## Install

### Downloaded package

1. Download and extract the SDK archive.
2. In Unity, open `Window → Package Manager`.
3. Choose `+ → Add package from disk`.
4. Select the extracted `package.json`.

### Via Unity Package Manager (git URL)

`Window → Package Manager → + → Add package from git URL…`

```text
https://github.com/BankruptGames/vintex-unity-sdk.git
```

Pin a release with `#v1.1.0-beta.1`. For a private repo, configure a PAT or SSH
git credential that Unity can use.

### Via manifest.json

```json
{
  "dependencies": {
    "com.bankruptgames.vintex": "https://github.com/BankruptGames/vintex-unity-sdk.git#v1.1.0-beta.1"
  }
}
```

### Local / embedded

Clone into your project's `Packages/` folder, or reference a local path:

```json
"com.bankruptgames.vintex": "file:../../vintex-unity-sdk"
```

## Quick start (client)

Add `VintexGamePlugin` to a bootstrap GameObject, set your Oculus App ID, then:

```csharp
using Vintex;

void Awake()
{
    VintexGamePlugin.OnVintexReady  += () => Debug.Log("Vintex verified");
    VintexGamePlugin.OnVintexFailed += reason => Debug.LogError($"Vintex failed: {reason}");
}

async void OnLoggedIn()
{
    // Fails closed: kick/ban/error all terminate. Only Valid runs onValid.
    await VintexGamePlugin.ValidateClientOrTerminateAsync(() =>
    {
        // Safe to enter gameplay / connect to server.
    });
}
```

## Quick start (dedicated server)

```csharp
using Vintex;

var validator = new TH_ValidateClientAsync();
validator.OnValidationSuccess += (playerId, result) => Admit(playerId);
validator.OnValidationFailure += (playerId, reason) => Kick(playerId, reason);

TH_ValidateClientAsync.SetGameServerAPIKey(myServerApiKey);
await validator.ValidateClient(playerId, bearerToken: null, tokenProvider: myProvider,
                               forcePlatformQuest: true);
```

## Native plugin

`Runtime/Plugins/Android/libs/arm64-v8a/libVintexCore.so` is loaded by
`DllImport("VintexCore")`. This beta includes a stripped arm64 release build of
the fail-closed native remake targeting the production Vintex service.

## Layout

```text
Runtime/   runtime SDK + native plugin   (asmdef: BankruptGames.Vintex)
Editor/    build/CI/dashboard tooling    (asmdef: BankruptGames.Vintex.Editor)
Samples~/  bootstrap example
```

## Security model

Both the native self-check and backend validation are fail-closed: any
unverifiable outcome denies. The clean-room native implementation remains beta
until its attestation and OBB paths finish hardware validation.

## License

Proprietary — © BankruptGames. See [LICENSE.md](LICENSE.md).
