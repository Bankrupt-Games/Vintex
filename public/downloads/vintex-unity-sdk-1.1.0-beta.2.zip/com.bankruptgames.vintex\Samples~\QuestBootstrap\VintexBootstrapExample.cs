using UnityEngine;
using Vintex;

namespace VintexSamples
{
	/// <summary>
	/// Minimal Quest bootstrap: start Vintex, react to ready/failed, and gate
	/// entry into gameplay behind a fail-closed client validation.
	///
	/// Put this on a GameObject alongside <see cref="VintexGamePlugin"/> in your
	/// first-loaded scene.
	/// </summary>
	public sealed class VintexBootstrapExample : MonoBehaviour
	{
		private void OnEnable()
		{
			VintexGamePlugin.OnVintexReady += HandleReady;
			VintexGamePlugin.OnVintexFailed += HandleFailed;
		}

		private void OnDisable()
		{
			VintexGamePlugin.OnVintexReady -= HandleReady;
			VintexGamePlugin.OnVintexFailed -= HandleFailed;
		}

		private async void HandleReady()
		{
			Debug.Log("[Vintex] verification ready - validating client...");

			// Fails closed: kick/ban/error terminate the app; only Valid runs onValid.
			await VintexGamePlugin.ValidateClientOrTerminateAsync(() =>
			{
				Debug.Log("[Vintex] client valid - entering gameplay.");
				// TODO: load your first gameplay scene / allow multiplayer connect.
			});
		}

		private void HandleFailed(string reason)
		{
			// Proceed into validation anyway so the failure is logged upstream;
			// the backend makes the authoritative call.
			Debug.LogError($"[Vintex] initialization failed: {reason}");
		}
	}
}
