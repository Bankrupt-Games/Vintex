namespace Vintex
{

/// <summary>
/// Conditional logging for Vintex plugin.
/// Controlled by TH_LOGGING_ENABLED define symbol.
///
/// Add TH_VERBOSE_LOGGING for additional sensitive data logging (development only).
/// </summary>
public static class VintexLog
{
	public static void Info(string message)
	{
	}

	public static void Info(string format, params object[] args)
	{
	}

	public static void Info(string className, string message)
	{
	}

	public static void Info(string className, string format, params object[] args)
	{
	}

	public static void Warning(string message)
	{
	}

	public static void Warning(string format, params object[] args)
	{
	}

	public static void Warning(string className, string message)
	{
	}

	public static void Warning(string className, string format, params object[] args)
	{
	}

	public static void Error(string message)
	{
	}

	public static void Error(string format, params object[] args)
	{
	}

	public static void Error(string className, string message)
	{
	}

	public static void Error(string className, string format, params object[] args)
	{
	}

	public static void Verbose(string message)
	{
	}

	public static void Verbose(string format, params object[] args)
	{
	}

	public static void Verbose(string className, string message)
	{
	}

	public static void Verbose(string className, string format, params object[] args)
	{
	}
}
}
