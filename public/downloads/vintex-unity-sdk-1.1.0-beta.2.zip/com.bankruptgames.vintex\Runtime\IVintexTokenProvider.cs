using System.Threading.Tasks;

namespace Vintex
{

/// <summary>
/// Interface for game to implement client-server token exchange.
/// Implement this with your networking solution (Mirror, Netcode, Fish-Net, etc.)
///
/// This interface allows the Vintex SDK to request session tokens from clients
/// without being tied to any specific networking framework.
///
/// RECOMMENDED: Use VintexServerHelper to simplify your implementation.
/// The helper handles request ID tracking, duplicate prevention, and timeout logic.
///
/// Example implementation using VintexServerHelper:
/// <code>
/// public class MyNetworkTokenProvider : IVintexTokenProvider
/// {
///     private Dictionary&lt;string, VintexServerHelper&gt; _helpers = new();
///
///     public async Task&lt;string&gt; RequestTokenFromClient(string playerId, string requestId, float timeout)
///     {
///         var helper = new VintexServerHelper();
///         _helpers[playerId] = helper;
///
///         // SDK generates the requestId - use helper's instead for internal tracking
///         string reqId = helper.PrepareTokenRequest();
///
///         // Send YOUR RPC to client (networking framework specific)
///         MyNetworkManager.SendToClient(playerId, new TokenRequestMessage { RequestId = reqId });
///
///         // Wait for response (SDK handles the waiting logic)
///         return await helper.WaitForTokenAsync(timeout);
///     }
///
///     // Called when client RPC arrives:
///     public void OnClientTokenResponse(string playerId, string requestId, byte[] tokenBytes)
///     {
///         if (_helpers.TryGetValue(playerId, out var helper))
///         {
///             helper.OnTokenReceived(requestId, tokenBytes);
///         }
///     }
/// }
/// </code>
///
/// On the CLIENT side, when you receive the token request RPC:
/// <code>
/// void OnServerRequestsToken(string requestId)
/// {
///     // Get token as bytes (recommended for reliable transfer)
///     byte[] tokenBytes = VintexClientHelper.GetTokenBytesForServer();
///
///     // Send back via your RPC
///     SendTokenToServer(requestId, tokenBytes);
/// }
/// </code>
/// </summary>
public interface IVintexTokenProvider
{
	/// <summary>
	/// Request a session token from a specific client.
	/// Server calls this to initiate token exchange.
	///
	/// Recommended implementation using VintexServerHelper:
	/// 1. Create a VintexServerHelper instance
	/// 2. Call helper.PrepareTokenRequest() to get the requestId
	/// 3. Send an RPC to the client with the requestId
	/// 4. Return await helper.WaitForTokenAsync(timeout)
	/// 5. When client RPC arrives, call helper.OnTokenReceived(requestId, tokenBytes)
	/// </summary>
	/// <param name="playerId">The player to request token from</param>
	/// <param name="requestId">Unique request ID for replay prevention (from SDK)</param>
	/// <param name="timeoutSeconds">How long to wait for response</param>
	/// <returns>The session token, or empty string if unavailable/timeout</returns>
	Task<string> RequestTokenFromClient(string playerId, string requestId, float timeoutSeconds);
}
}
