using System;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Vintex
{

/// <summary>
/// Server-side helper for managing token request/response flow.
/// Mirrors Unreal's TH_ValidationHelper component.
///
/// This class handles all the internal state management so game developers
/// only need to implement the RPC transport layer.
///
/// Usage:
/// 1. Create one instance per player validation
/// 2. Call PrepareTokenRequest() to get requestId
/// 3. Send your RPC to client with the requestId
/// 4. Call WaitForTokenAsync() to wait for response
/// 5. When client RPC arrives, call OnTokenReceived()
///
/// Example:
/// <code>
/// public class MyNetworkTokenProvider : IVintexTokenProvider
/// {
///     private Dictionary&lt;string, VintexServerHelper&gt; _helpers = new();
///
///     public async Task&lt;string&gt; RequestTokenFromClient(string playerId, string requestId, float timeout)
///     {
///         var helper = new VintexServerHelper();
///         _helpers[playerId] = helper;
///
///         // SDK generates the requestId
///         string reqId = helper.PrepareTokenRequest();
///
///         // Send YOUR RPC to client (networking framework specific)
///         MyNetworkManager.SendToClient(playerId, new TokenRequestMessage { RequestId = reqId });
///
///         // Wait for response (SDK handles the waiting logic)
///         return await helper.WaitForTokenAsync(timeout);
///     }
///
///     // Called when client RPC arrives:
///     public void OnClientTokenResponse(string playerId, string requestId, byte[] tokenBytes)
///     {
///         if (_helpers.TryGetValue(playerId, out var helper))
///         {
///             helper.OnTokenReceived(requestId, tokenBytes);
///         }
///     }
/// }
/// </code>
/// </summary>
public class VintexServerHelper
{
	private string _currentRequestId;

	private bool _hasResponded;

	private TaskCompletionSource<string> _tokenTcs;

	private CancellationTokenSource _timeoutCts;

	/// <summary>
	/// Get the current request ID (for debugging/logging).
	/// </summary>
	public string CurrentRequestId => _currentRequestId;

	/// <summary>
	/// Check if this helper has already received a response.
	/// </summary>
	public bool HasResponded => _hasResponded;

	/// <summary>
	/// Prepare a new token request. Call before sending RPC to client.
	/// Returns the requestId to send to the client.
	/// </summary>
	/// <returns>A unique request ID to send to the client</returns>
	public string PrepareTokenRequest()
	{
		_currentRequestId = Guid.NewGuid().ToString();
		_hasResponded = false;
		_tokenTcs = new TaskCompletionSource<string>();
		_timeoutCts?.Dispose();
		_timeoutCts = null;
		VintexLog.Info("VintexServerHelper", "Prepared token request, RequestId={0}", _currentRequestId);
		return _currentRequestId;
	}

	/// <summary>
	/// Wait for token from client. Call after sending your RPC.
	/// </summary>
	/// <param name="timeoutSeconds">Maximum time to wait for client response</param>
	/// <returns>The session token from the client, or empty string if unavailable</returns>
	/// <exception cref="T:System.TimeoutException">Thrown if client does not respond in time</exception>
	public async Task<string> WaitForTokenAsync(float timeoutSeconds)
	{
		if (_tokenTcs == null)
		{
			VintexLog.Error("VintexServerHelper", "WaitForTokenAsync called before PrepareTokenRequest");
			throw new InvalidOperationException("Must call PrepareTokenRequest before WaitForTokenAsync");
		}
		_timeoutCts = new CancellationTokenSource();
		_timeoutCts.CancelAfter(TimeSpan.FromSeconds(timeoutSeconds));
		_timeoutCts.Token.Register(delegate
		{
			VintexLog.Warning("VintexServerHelper", "Timeout waiting for token, RequestId={0}", _currentRequestId);
			_tokenTcs.TrySetException(new TimeoutException("Token request timeout - client did not respond"));
		});
		try
		{
			return await _tokenTcs.Task;
		}
		finally
		{
			_timeoutCts?.Dispose();
			_timeoutCts = null;
		}
	}

	/// <summary>
	/// Call when client sends back token via RPC as a byte array.
	/// Handles requestId validation and byte-to-string conversion (matching Unreal).
	/// </summary>
	/// <param name="requestId">The request ID from the client response</param>
	/// <param name="tokenBytes">The token as UTF-8 encoded bytes</param>
	public void OnTokenReceived(string requestId, byte[] tokenBytes)
	{
		VintexLog.Info("VintexServerHelper", "Token received (bytes), RequestId={0}, ByteLen={1}", requestId, (tokenBytes != null) ? tokenBytes.Length : 0);
		if (requestId != _currentRequestId)
		{
			VintexLog.Warning("VintexServerHelper", "RequestId mismatch - ignoring (expected {0}, got {1})", _currentRequestId, requestId);
			return;
		}
		if (_hasResponded)
		{
			VintexLog.Warning("VintexServerHelper", "Already responded - ignoring duplicate");
			return;
		}
		_hasResponded = true;
		string text = "";
		if (tokenBytes != null && tokenBytes.Length != 0)
		{
			text = Encoding.UTF8.GetString(tokenBytes);
		}
		VintexLog.Info("VintexServerHelper", "Token processed, HasToken={0}", !string.IsNullOrEmpty(text));
		_tokenTcs?.TrySetResult(text);
	}

	/// <summary>
	/// Call when client sends back token via RPC as a string.
	/// Alternative to byte array version for networking frameworks that support strings.
	/// </summary>
	/// <param name="requestId">The request ID from the client response</param>
	/// <param name="token">The session token string</param>
	public void OnTokenReceived(string requestId, string token)
	{
		VintexLog.Info("VintexServerHelper", "Token received (string), RequestId={0}, HasToken={1}", requestId, !string.IsNullOrEmpty(token));
		if (requestId != _currentRequestId)
		{
			VintexLog.Warning("VintexServerHelper", "RequestId mismatch - ignoring (expected {0}, got {1})", _currentRequestId, requestId);
		}
		else if (_hasResponded)
		{
			VintexLog.Warning("VintexServerHelper", "Already responded - ignoring duplicate");
		}
		else
		{
			_hasResponded = true;
			_tokenTcs?.TrySetResult(token ?? "");
		}
	}

	/// <summary>
	/// Cancel any pending token request.
	/// Call this if the player disconnects before validation completes.
	/// </summary>
	public void Cancel()
	{
		if (_tokenTcs != null && !_tokenTcs.Task.IsCompleted)
		{
			VintexLog.Info("VintexServerHelper", "Token request cancelled, RequestId={0}", _currentRequestId);
			_tokenTcs.TrySetCanceled();
		}
		_timeoutCts?.Cancel();
	}
}
}
