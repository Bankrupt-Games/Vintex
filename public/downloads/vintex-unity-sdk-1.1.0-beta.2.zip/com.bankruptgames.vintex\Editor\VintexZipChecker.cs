using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEngine;
using UnityEngine.SceneManagement;
using Debug = UnityEngine.Debug;
using Object = UnityEngine.Object;

namespace VintexEditorPlugin
{

[InitializeOnLoad]
public class VintexZipChecker : IPostprocessBuildWithReport, IOrderedCallback, IPreprocessBuildWithReport
{
	private struct ZipLocalFileHeader
	{
		public uint Signature;

		public ushort VersionNeeded;

		public ushort Flags;

		public ushort CompressionMethod;

		public ushort LastModTime;

		public ushort LastModDate;

		public uint Crc32;

		public uint CompressedSize;

		public uint UncompressedSize;

		public ushort FileNameLength;

		public ushort ExtraFieldLength;
	}

	private class ZipFileEntry
	{
		public string FileName { get; set; }

		public uint Crc32 { get; set; }

		public uint UncompressedSize { get; set; }

		public uint CompressedSize { get; set; }

		public ushort LastModTime { get; set; }

		public ushort LastModDate { get; set; }

		public long CompressedDataOffset { get; set; }
	}

	private class OBBFileDetail
	{
		public string Path { get; set; }

		public uint Crc { get; set; }

		public long Size { get; set; }
	}

	private class ObbHashSetRequest
	{
		[JsonProperty("BuildId")]
		public string BuildVersion { get; set; }

		public List<ObbHashesRequestObject> ObbHashes { get; set; }

		public string BuildType { get; set; } = string.Empty;

		/// <summary>
		/// Indicates whether the game uses OBB expansion files.
		/// When false, an empty ObbHashes list is intentional (not an error).
		/// </summary>
		public bool ObbEnabled { get; set; } = true;
	}

	private class ObbHashesRequestObject
	{
		public string FileName { get; set; }

		public long FileSize { get; set; }

		public string Hash { get; set; }

		public string LastModified { get; set; }

		public string ObbDetails { get; set; }
	}

	private class ApkLibraryInfo
	{
		[JsonProperty("name")]
		public string Name { get; set; }

		[JsonProperty("size")]
		public long Size { get; set; }

		[JsonProperty("crc32")]
		public uint Crc32 { get; set; }

		[JsonProperty("modTime")]
		public ushort ModTime { get; set; }

		[JsonProperty("modDate")]
		public ushort ModDate { get; set; }
	}

	private class ApkDexInfo
	{
		[JsonProperty("name")]
		public string Name { get; set; }

		[JsonProperty("size")]
		public long Size { get; set; }
	}

	private class ApkHashSetRequest
	{
		[JsonProperty("BuildId")]
		public string BuildVersion { get; set; }

		public string BuildType { get; set; }

		public string APKHash { get; set; }

		public long APKFileSize { get; set; }

		public string APKLastModified { get; set; }

		public string SigningCertFingerprint { get; set; }

		public bool IsDebuggable { get; set; }

		public bool IsDebuggableUnknown { get; set; }

		public int TotalEntryCount { get; set; }

		public string APKDetails { get; set; }
	}

	private const string ProdApiUrl = "https://vintex.bankruptgames.net/api/v1/attestation/admin/";

	private const string BaseUrlKey = "VintexBaseUrl";

	private const string ExternalAssetsDirectoryKey = "VintexExternalAssetsDirectory";

	private const string BuildTypeKey = "VintexBuildType";

	private const string ObbEnabledKey = "VintexObbEnabled";

	private const string EnvObbEnabled = "VINTEX_OBB_ENABLED";

	private const string ObbEnabledOverrideKey = "VintexObbEnabledOverride";

	private const string BuildManagementUrl = "https://vintex.bankruptgames.net/dashboard";

	private const string NativeLibPath = "Assets/VintexSDK/Plugins/Android/libs/arm64-v8a/libVintexCore.so";

	private const string AarPath = "Assets/VintexSDK/Plugins/Android/VintexAssets.aar";

	private const string ClientDllPath = "Assets/VintexSDK/Plugins/Managed/Client/VintexGamePlugin.dll";

	private static string DevGameToken;

	public const string DevGameTokenKey = "VintexDevGameToken";

	private static bool _isUploadInProgress;

	private static DateTime _uploadStartTime;

	private const int UploadTimeoutSeconds = 120;

	private const string ServerDllPath = "Assets/VintexSDK/Plugins/Managed/Server/VintexServer.dll";

	private static readonly string[] VintexBuildAssets;

	/// <summary>
	/// The build type for post-build asset scanning.
	/// IMPORTANT: Use 'Dev' for testing to avoid overwriting production data.
	/// Use 'Live' only for production releases.
	/// </summary>
	public static VintexBuildType BuildType
	{
		get
		{
			string environmentVariable = Environment.GetEnvironmentVariable("VINTEX_BUILD_TYPE");
			if (!string.IsNullOrEmpty(environmentVariable))
			{
				if (Enum.TryParse<VintexBuildType>(environmentVariable, ignoreCase: true, out var result))
				{
					return result;
				}
				Debug.LogWarning((object)("[Vintex] Invalid VINTEX_BUILD_TYPE '" + environmentVariable + "'. Falling back to QA."));
				return VintexBuildType.QA;
			}
			if (Enum.TryParse<VintexBuildType>(EditorPrefs.GetString("VintexBuildType", VintexBuildType.QA.ToString()), out var result2))
			{
				return result2;
			}
			return VintexBuildType.QA;
		}
		set
		{
			EditorPrefs.SetString("VintexBuildType", value.ToString());
		}
	}

	/// <summary>
	/// Directory for external asset files (e.g., expansion files) if stored separately from the main build output.
	/// Leave empty to use the default build output path.
	/// </summary>
	public static string ExternalAssetsDirectory
	{
		get
		{
			return EditorPrefs.GetString("VintexExternalAssetsDirectory", "");
		}
		set
		{
			EditorPrefs.SetString("VintexExternalAssetsDirectory", value);
		}
	}

	/// <summary>
	/// Whether this game uses OBB expansion files.
	/// When false, build verification still uploads but with empty OBB list.
	/// This allows games without OBBs to still register builds with Vintex.
	/// </summary>
	public static bool ObbEnabled
	{
		get
		{
			string environmentVariable = Environment.GetEnvironmentVariable("VINTEX_OBB_ENABLED");
			if (!string.IsNullOrEmpty(environmentVariable))
			{
				if (!environmentVariable.Equals("true", StringComparison.OrdinalIgnoreCase))
				{
					return environmentVariable == "1";
				}
				return true;
			}
			if (EditorPrefs.HasKey("VintexObbEnabledOverride"))
			{
				return EditorPrefs.GetBool("VintexObbEnabledOverride");
			}
			return GetUnitySplitApplicationBinarySetting();
		}
		set
		{
			EditorPrefs.SetBool("VintexObbEnabledOverride", value);
			EditorPrefs.SetBool("VintexObbEnabled", value);
		}
	}

	public static bool? ObbEnabledOverride
	{
		get
		{
			if (!EditorPrefs.HasKey("VintexObbEnabledOverride"))
			{
				return null;
			}
			return EditorPrefs.GetBool("VintexObbEnabledOverride");
		}
	}

	public int callbackOrder => 0;

	/// <summary>
	/// Converts the build type enum to the API-expected string format.
	/// </summary>
	private static string GetBuildTypeApiString(VintexBuildType buildType)
	{
		return buildType switch
		{
			VintexBuildType.QA => "QA", 
			VintexBuildType.Live => "Live", 
			_ => "QA", 
		};
	}

	private static string GetApiUrlForBuildType(VintexBuildType buildType)
	{
		string environmentVariable = Environment.GetEnvironmentVariable("VINTEX_API_URL");
		if (!string.IsNullOrEmpty(environmentVariable))
		{
			return environmentVariable;
		}
		return ProdApiUrl;
	}

	public static void ClearObbEnabledOverride()
	{
		if (EditorPrefs.HasKey("VintexObbEnabledOverride"))
		{
			EditorPrefs.DeleteKey("VintexObbEnabledOverride");
		}
	}

	public static bool GetUnitySplitApplicationBinarySetting()
	{
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		try
		{
			Type nestedType = typeof(PlayerSettings).GetNestedType("Android");
			if (nestedType != null)
			{
				PropertyInfo property = nestedType.GetProperty("useAPKExpansionFiles", BindingFlags.Static | BindingFlags.Public);
				if (property != null)
				{
					return (bool)property.GetValue(null);
				}
			}
			Object[] array = AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/ProjectSettings.asset");
			if (array != null && array.Length != 0)
			{
				SerializedProperty val = new SerializedObject(array[0]).FindProperty("AndroidSplitApplicationBinary");
				if (val != null)
				{
					return val.boolValue;
				}
			}
		}
		catch (Exception ex)
		{
			Debug.LogWarning((object)("[Vintex] Could not auto-detect Split Application Binary setting: " + ex.Message));
		}
		return false;
	}

	private static string GetApiEndpointDisplayName(VintexBuildType buildType)
	{
		return buildType switch
		{
			VintexBuildType.QA => "vintex.bankruptgames.net (QA)", 
			VintexBuildType.Live => "vintex.bankruptgames.net (Live)", 
			_ => "vintex.bankruptgames.net (QA)", 
		};
	}

	private static int ShowLiveEnvironmentWarning()
	{
		string bundleVersion = PlayerSettings.bundleVersion;
		return VintexBuildDialog.ShowLiveWarning(BuildType, bundleVersion) switch
		{
			VintexBuildDialog.DialogResult.BuildOnLive => 0, 
			VintexBuildDialog.DialogResult.SwitchToQA => 1, 
			VintexBuildDialog.DialogResult.Cancel => 2, 
			VintexBuildDialog.DialogResult.OpenBuildManagement => 3, 
			_ => 2, 
		};
	}

	static VintexZipChecker()
	{
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Expected O, but got Unknown
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Expected O, but got Unknown
		DevGameToken = "";
		_isUploadInProgress = false;
		VintexBuildAssets = new string[4] { "Assets/VintexSDK/Plugins/Android/libs/arm64-v8a/libVintexCore.so", "Assets/VintexSDK/Plugins/Android/VintexAssets.aar", "Assets/VintexSDK/Plugins/Managed/Client/VintexGamePlugin.dll", "Assets/VintexSDK/Plugins/Managed/Server/VintexServer.dll" };
		EditorApplication.update += OnEditorLaunch;
		EditorApplication.wantsToQuit += OnWantsToQuit;
		LoadDevGameToken();
	}

	private static bool OnWantsToQuit()
	{
		if (!_isUploadInProgress)
		{
			return true;
		}
		TimeSpan timeSpan = DateTime.Now - _uploadStartTime;
		if (timeSpan.TotalSeconds >= 120.0)
		{
			Debug.LogError((object)$"[Vintex] Build verification timed out after {120}s. Allowing exit.");
			_isUploadInProgress = false;
			return true;
		}
		Debug.LogWarning((object)"[Vintex] ════════════════════════════════════════════════════════════");
		Debug.LogWarning((object)$"[Vintex] Build verification upload in progress ({timeSpan.TotalSeconds:F0}s elapsed).");
		Debug.LogWarning((object)"[Vintex] Please wait for upload to complete before closing Unity.");
		Debug.LogWarning((object)$"[Vintex] Will auto-timeout after {120}s if needed.");
		Debug.LogWarning((object)"[Vintex] ════════════════════════════════════════════════════════════");
		return false;
	}

	private static void OnEditorLaunch()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Expected O, but got Unknown
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Expected O, but got Unknown
		EditorApplication.update -= OnEditorLaunch;
		ApplyScriptingDefinesFromEnvironment();
		if (Application.isBatchMode)
		{
			if (string.IsNullOrEmpty(DevGameToken))
			{
				Debug.LogWarning((object)"[Vintex] Running in batch mode but VINTEX_DEV_GAME_TOKEN environment variable is not set!");
			}
		}
		else if (RequiresEnvironmentSetup())
		{
			VintexDashboard.ShowFirstTimeWizard();
		}
	}

	/// <summary>
	/// Checks if the SDK requires first-time environment setup.
	/// Returns true if active SO or AAR files are missing.
	/// </summary>
	public static bool RequiresEnvironmentSetup()
	{
		if (File.Exists("Assets/VintexSDK/Plugins/Android/libs/arm64-v8a/libVintexCore.so"))
		{
			return !File.Exists("Assets/VintexSDK/Plugins/Android/VintexAssets.aar");
		}
		return true;
	}

	private static void ApplyScriptingDefinesFromEnvironment()
	{
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0162: Unknown result type (might be due to invalid IL or missing references)
		if (!Application.isBatchMode)
		{
			return;
		}
		BuildTargetGroup selectedBuildTargetGroup = EditorUserBuildSettings.selectedBuildTargetGroup;
		string scriptingDefineSymbolsForGroup = PlayerSettings.GetScriptingDefineSymbolsForGroup(selectedBuildTargetGroup);
		string[] array = new string[3] { "TH_VINTEX", "TH_SERVER", "TH_PHOTON" };
		string environmentVariable = Environment.GetEnvironmentVariable("VINTEX_SCRIPTING_DEFINES");
		HashSet<string> hashSet = new HashSet<string>();
		string[] array2;
		if (!string.IsNullOrEmpty(environmentVariable))
		{
			array2 = environmentVariable.Split(new char[2] { ';', ',' }, StringSplitOptions.RemoveEmptyEntries);
			for (int i = 0; i < array2.Length; i++)
			{
				string text = array2[i].Trim();
				if (Array.IndexOf(array, text) >= 0)
				{
					hashSet.Add(text);
				}
				else
				{
					Debug.LogWarning((object)("[Vintex] Unknown scripting define '" + text + "' - ignoring. Valid: TH_VINTEX, TH_SERVER, TH_PHOTON"));
				}
			}
		}
		List<string> list = scriptingDefineSymbolsForGroup.Split(new char[1] { ';' }, StringSplitOptions.RemoveEmptyEntries).ToList();
		array2 = array;
		foreach (string item in array2)
		{
			list.Remove(item);
		}
		foreach (string item2 in hashSet)
		{
			if (!list.Contains(item2))
			{
				list.Add(item2);
			}
			Debug.Log((object)("[Vintex] CI/CD: Scripting define '" + item2 + "' enabled"));
		}
		string text2 = string.Join(";", list);
		if (text2 != scriptingDefineSymbolsForGroup)
		{
			PlayerSettings.SetScriptingDefineSymbolsForGroup(selectedBuildTargetGroup, text2);
			Debug.Log((object)("[Vintex] CI/CD: Scripting defines updated to: " + text2));
		}
		if (hashSet.Count == 0)
		{
			Debug.Log((object)"[Vintex] CI/CD: No Vintex scripting defines requested - Vintex will not be included in this build");
		}
	}

	private static void LoadDevGameToken()
	{
		DevGameToken = Environment.GetEnvironmentVariable("VINTEX_DEV_GAME_TOKEN");
		if (string.IsNullOrEmpty(DevGameToken))
		{
			DevGameToken = EditorPrefs.GetString("VintexDevGameToken", "");
		}
		else
		{
			Debug.Log((object)"[Vintex] DevGameToken loaded from environment variable");
		}
	}

	public static void SaveDevGameToken(string key)
	{
		DevGameToken = key;
		EditorPrefs.SetString("VintexDevGameToken", DevGameToken);
	}

	private static bool IsVintexIncludedInBuild()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		if (Application.isBatchMode)
		{
			ApplyScriptingDefinesFromEnvironment();
		}
		return PlayerSettings.GetScriptingDefineSymbolsForGroup(EditorUserBuildSettings.selectedBuildTargetGroup).Contains("TH_VINTEX");
	}

	private static void ExcludeVintexFromBuild()
	{
		string[] vintexBuildAssets = VintexBuildAssets;
		foreach (string text in vintexBuildAssets)
		{
			if (File.Exists(text))
			{
				AssetImporter atPath = AssetImporter.GetAtPath(text);
				PluginImporter val = (PluginImporter)(object)((atPath is PluginImporter) ? atPath : null);
				if (!((Object)(object)val == (Object)null) && val.GetCompatibleWithPlatform((BuildTarget)13))
				{
					val.SetCompatibleWithPlatform((BuildTarget)13, false);
					((AssetImporter)val).SaveAndReimport();
					Debug.Log((object)("[Vintex] Excluded from build: " + text));
				}
			}
		}
	}

	private static void IncludeVintexInBuild()
	{
		string[] vintexBuildAssets = VintexBuildAssets;
		foreach (string text in vintexBuildAssets)
		{
			if (!File.Exists(text))
			{
				continue;
			}
			AssetImporter atPath = AssetImporter.GetAtPath(text);
			PluginImporter val = (PluginImporter)(object)((atPath is PluginImporter) ? atPath : null);
			if (!((Object)(object)val == (Object)null) && !val.GetCompatibleWithPlatform((BuildTarget)13))
			{
				val.SetCompatibleWithPlatform((BuildTarget)13, true);
				if (text.EndsWith(".so"))
				{
					val.SetPlatformData((BuildTarget)13, "CPU", "ARM64");
				}
				((AssetImporter)val).SaveAndReimport();
				Debug.Log((object)("[Vintex] Re-included in build: " + text));
			}
		}
	}

	/// <summary>
	/// Pre-build: Ensures correct native library and warns about Dev builds.
	/// </summary>
	public void OnPreprocessBuild(BuildReport report)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Invalid comparison between Unknown and I4
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0181: Unknown result type (might be due to invalid IL or missing references)
		//IL_018b: Expected O, but got Unknown
		//IL_018b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0195: Expected O, but got Unknown
		//IL_019a: Unknown result type (might be due to invalid IL or missing references)
		BuildSummary summary = report.summary;
		if ((int)summary.platform != 13)
		{
			return;
		}
		if (!IsVintexIncludedInBuild())
		{
			ExcludeVintexFromBuild();
			Debug.Log((object)"[Vintex] TH_VINTEX not defined - Vintex is not included in this build. Skipping pre-build hooks.");
			return;
		}
		IncludeVintexInBuild();
		VintexCICD.LogCIEnvironment();
		if (VintexCICD.IsCIEnvironment)
		{
			string[] array = VintexCICD.ValidateCIConfiguration();
			foreach (string text in array)
			{
				Debug.LogWarning((object)("[Vintex] CI/CD Configuration: " + text));
			}
		}
		LogSceneVintexPlugins();
		VintexBuildType buildType = BuildType;
		if (buildType == VintexBuildType.Live && !Application.isBatchMode && string.IsNullOrEmpty(Environment.GetEnvironmentVariable("VINTEX_SKIP_LIVE_WARNING")))
		{
			int num = ShowLiveEnvironmentWarning();
			switch (num)
			{
			case 1:
			{
				BuildType = VintexBuildType.QA;
				Debug.Log((object)"[Vintex] Switched to QA environment. Restarting build...");
				summary = report.summary;
				BuildOptions buildOptions = summary.options;
				summary = report.summary;
				string buildPath = summary.outputPath;
				summary = report.summary;
				BuildTarget buildTarget = summary.platform;
				_ = EditorUserBuildSettings.selectedBuildTargetGroup;
				string[] scenes = (from s in EditorBuildSettings.scenes
					where s.enabled
					select s.path).ToArray();
				EditorApplication.delayCall += delegate
				{
					//IL_0017: Unknown result type (might be due to invalid IL or missing references)
					//IL_001d: Unknown result type (might be due to invalid IL or missing references)
					Debug.Log((object)"[Vintex] Starting QA build...");
					BuildPipeline.BuildPlayer(scenes, buildPath, buildTarget, buildOptions);
				};
				throw new BuildFailedException("[Vintex] Restarting build in QA environment...");
			}
			case 2:
				throw new BuildFailedException("[Vintex] Build cancelled by user.");
			case 3:
				throw new BuildFailedException("[Vintex] Build cancelled - opening Build Management portal.");
			}
		}
		PerformPreBuildAuthCheck();
		ValidateBuildCredentials();
		ConfigurePluginImportSettings();
		string apiEndpointDisplayName = GetApiEndpointDisplayName(buildType);
		string buildTypeApiString = GetBuildTypeApiString(buildType);
		if (buildType == VintexBuildType.QA)
		{
			Debug.Log((object)"╔══════════════════════════════════════════════════════════════╗");
			Debug.Log((object)"║                                                              ║");
			Debug.Log((object)"║   Vintex Environment: QA (Quality Assurance)               ║");
			Debug.Log((object)$"║   Targets: {apiEndpointDisplayName,-49} ║");
			Debug.Log((object)$"║   BuildType: {buildTypeApiString,-47} ║");
			Debug.Log((object)"║                                                              ║");
			Debug.Log((object)"║                                                              ║");
			Debug.Log((object)"║   This build is for QA/STAGING testing.                      ║");
			Debug.Log((object)"║   Switch to LIVE for production release.                     ║");
			Debug.Log((object)"║                                                              ║");
			Debug.Log((object)"╚══════════════════════════════════════════════════════════════╝");
		}
		else
		{
			Debug.Log((object)"╔══════════════════════════════════════════════════════════════╗");
			Debug.Log((object)"║                                                              ║");
			Debug.Log((object)"║   Vintex Environment: LIVE (Production)                    ║");
			Debug.Log((object)$"║   Targets: {apiEndpointDisplayName,-49} ║");
			Debug.Log((object)$"║   BuildType: {buildTypeApiString,-47} ║");
			Debug.Log((object)"║                                                              ║");
			Debug.Log((object)"║                                                              ║");
			Debug.Log((object)"║   Ready for production release.                              ║");
			Debug.Log((object)"║                                                              ║");
			Debug.Log((object)"╚══════════════════════════════════════════════════════════════╝");
		}
	}

	private void LogSceneVintexPlugins()
	{
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Expected O, but got Unknown
		//IL_0278: Unknown result type (might be due to invalid IL or missing references)
		//IL_027f: Expected O, but got Unknown
		Debug.Log((object)"[Vintex] === PRE-BUILD: Checking VintexGamePlugin values ===");
		Scene activeScene = SceneManager.GetActiveScene();
		GameObject[] rootGameObjects = activeScene.GetRootGameObjects();
		int num = 0;
		GameObject[] array = rootGameObjects;
		for (int i = 0; i < array.Length; i++)
		{
			Transform[] componentsInChildren = array[i].GetComponentsInChildren<Transform>(true);
			foreach (Transform val in componentsInChildren)
			{
				MonoBehaviour[] components = ((Component)val).gameObject.GetComponents<MonoBehaviour>();
				foreach (MonoBehaviour val2 in components)
				{
					if ((Object)(object)val2 == (Object)null)
					{
						continue;
					}
					SerializedObject val3 = new SerializedObject((Object)(object)val2);
					SerializedProperty val4 = val3.FindProperty("oculusAppId");
					if (val4 != null)
					{
						num++;
						SerializedProperty val5 = val3.FindProperty("enableAttestation");
						SerializedProperty val6 = val3.FindProperty("enableOBB");
						val3.FindProperty("maxRetries");
						SerializedProperty val7 = val3.FindProperty("autoStartOnAwake");
						Debug.Log((object)$"[Vintex] Found VintexGamePlugin #{num} on '{((Object)((Component)val).gameObject).name}':");
						Debug.Log((object)("[Vintex]   - Oculus App ID: " + ((val4 != null) ? val4.stringValue : null)));
						Debug.Log((object)$"[Vintex]   - Protect Internal Integrity: {((val5 != null) ? new bool?(val5.boolValue) : ((bool?)null))}");
						Debug.Log((object)$"[Vintex]   - Protect External Integrity: {((val6 != null) ? new bool?(val6.boolValue) : ((bool?)null))}");
						Debug.Log((object)$"[Vintex]   - Auto Start: {((val7 != null) ? new bool?(val7.boolValue) : ((bool?)null))}");
						bool flag = PrefabUtility.IsPartOfPrefabInstance((Object)(object)((Component)val).gameObject);
						Debug.Log((object)$"[Vintex]   - Is Prefab Instance: {flag}");
						if (flag)
						{
							GameObject correspondingObjectFromSource = PrefabUtility.GetCorrespondingObjectFromSource<GameObject>(((Component)val).gameObject);
							Debug.Log((object)("[Vintex]   - Source Prefab: " + ((correspondingObjectFromSource != null) ? ((Object)correspondingObjectFromSource).name : null)));
						}
					}
				}
			}
		}
		if (num == 0)
		{
			Debug.LogWarning((object)"[Vintex] No VintexGamePlugin found in scene!");
		}
		else if (num > 1)
		{
			Debug.LogWarning((object)$"[Vintex] WARNING: Multiple VintexGamePlugin instances found ({num})! Only the first to awake will be used.");
		}
		GameObject val8 = AssetDatabase.LoadAssetAtPath<GameObject>("Assets/VintexSDK/Prefabs/VintexManager.prefab");
		if ((Object)(object)val8 != (Object)null)
		{
			MonoBehaviour[] components = val8.GetComponents<MonoBehaviour>();
			foreach (MonoBehaviour val9 in components)
			{
				if (!((Object)(object)val9 == (Object)null))
				{
					SerializedObject val10 = new SerializedObject((Object)(object)val9);
					SerializedProperty val11 = val10.FindProperty("oculusAppId");
					if (val11 != null)
					{
						SerializedProperty val12 = val10.FindProperty("enableAttestation");
						SerializedProperty val13 = val10.FindProperty("enableOBB");
						val10.FindProperty("maxRetries");
						Debug.Log((object)"[Vintex] Prefab Asset values:");
						Debug.Log((object)("[Vintex]   - Oculus App ID: " + ((val11 != null) ? val11.stringValue : null)));
						Debug.Log((object)$"[Vintex]   - Protect Internal Integrity: {((val12 != null) ? new bool?(val12.boolValue) : ((bool?)null))}");
						Debug.Log((object)$"[Vintex]   - Protect External Integrity: {((val13 != null) ? new bool?(val13.boolValue) : ((bool?)null))}");
					}
				}
			}
		}
		Debug.Log((object)"[Vintex] === END PRE-BUILD CHECK ===");
	}

	private void ValidateBuildCredentials()
	{
		//IL_01f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0204: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a1: Unknown result type (might be due to invalid IL or missing references)
		List<string> list = new List<string>();
		List<string> list2 = new List<string>();
		if (string.IsNullOrWhiteSpace(DevGameToken))
		{
			list.Add("Dev Game Token is not configured.");
		}
		if (string.IsNullOrWhiteSpace(VintexDashboard.LoadGameServerAPIKey()))
		{
			list2.Add("Game Server API Key is not configured (required for server-side validation).");
		}
		if (string.IsNullOrWhiteSpace(GetSceneOculusAppId()))
		{
			list.Add("Oculus App ID is not configured in VintexGamePlugin.");
		}
		if (list.Count == 0 && list2.Count == 0)
		{
			Debug.Log((object)"[Vintex] Credential validation passed.");
			return;
		}
		string text = "";
		if (list.Count > 0)
		{
			text = "ERRORS:\n" + string.Join("\n", list.Select((string e) => "• " + e));
		}
		if (list2.Count > 0)
		{
			if (!string.IsNullOrEmpty(text))
			{
				text += "\n\n";
			}
			text = text + "WARNINGS:\n" + string.Join("\n", list2.Select((string w) => "• " + w));
		}
		if (Application.isBatchMode)
		{
			foreach (string item in list)
			{
				Debug.LogError((object)("[Vintex] Build Validation Error: " + item));
			}
			foreach (string item2 in list2)
			{
				Debug.LogWarning((object)("[Vintex] Build Validation Warning: " + item2));
			}
			if (list.Count > 0)
			{
				throw new BuildFailedException("[Vintex] Build failed due to missing credentials. Set credentials via environment variables or EditorPrefs.");
			}
		}
		else if (list.Count > 0)
		{
			switch (EditorUtility.DisplayDialogComplex("Vintex - Missing Credentials", "The following issues were found:\n\n" + text + "\n\nConfigure credentials before building.", "Open Settings", "Cancel Build", "Build Anyway"))
			{
			case 0:
				VintexDashboard.ShowSettings();
				throw new BuildFailedException("[Vintex] Build cancelled - opening settings to configure credentials.");
			case 1:
				throw new BuildFailedException("[Vintex] Build cancelled due to missing credentials.");
			case 2:
				Debug.LogWarning((object)"[Vintex] Building despite missing credentials. This build may not work correctly.");
				break;
			}
		}
		else if (list2.Count > 0)
		{
			Debug.LogWarning((object)("[Vintex] Build Validation Warnings:\n" + string.Join("\n", list2.Select((string w) => "• " + w))));
		}
	}

	private void PerformPreBuildAuthCheck()
	{
		string environmentVariable = Environment.GetEnvironmentVariable("VINTEX_SKIP_PREBUILD_AUTH");
		if (!string.IsNullOrEmpty(environmentVariable) && (environmentVariable == "1" || environmentVariable.ToLower() == "true"))
		{
			Debug.Log((object)"[Vintex] Pre-build auth check skipped (VINTEX_SKIP_PREBUILD_AUTH set)");
			return;
		}
		if (string.IsNullOrEmpty(DevGameToken))
		{
			Debug.LogWarning((object)"[Vintex] Pre-build auth check skipped - no DevGameToken configured");
			return;
		}
		Debug.Log((object)"[Vintex] Performing pre-build authentication check...");
		string requestUri = GetApiUrlForBuildType(BuildType) + "prebuild-auth";
		try
		{
			using HttpClient httpClient = new HttpClient();
			httpClient.Timeout = TimeSpan.FromSeconds(10.0);
			httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", DevGameToken);
			HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Head, requestUri);
			HttpResponseMessage result = httpClient.SendAsync(request).GetAwaiter().GetResult();
			if (result.IsSuccessStatusCode)
			{
				Debug.Log((object)"[Vintex] Pre-build authentication successful");
				return;
			}
			int statusCode = (int)result.StatusCode;
			string text = statusCode switch
			{
				401 => "Invalid DevGameToken", 
				403 => "IP not whitelisted or account not authorized", 
				402 => "Vintex subscription issue", 
				_ => $"Server returned {statusCode}", 
			};
			Debug.LogWarning((object)("[Vintex] Pre-build auth failed: " + text));
			HandleAuthFailure(text);
		}
		catch (Exception ex)
		{
			Debug.LogWarning((object)("[Vintex] Pre-build auth check failed: " + ex.Message));
			if (Application.isBatchMode)
			{
				Debug.LogWarning((object)"[Vintex] Batch mode - continuing build despite auth check failure");
			}
			else
			{
				HandleAuthFailure("Network error: " + ex.Message);
			}
		}
	}

	private void HandleAuthFailure(string errorDetails)
	{
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		string text = "Vintex is not authenticated to make builds in this environment.\n\nPlease ensure:\n• Your IP address is whitelisted in Vintex Portal\n• Your DevGameToken is properly configured\n• Your Vintex account is in good standing\n\nError: " + errorDetails;
		if (Application.isBatchMode)
		{
			Debug.LogWarning((object)"[Vintex] ════════════════════════════════════════════════════════════");
			Debug.LogWarning((object)"[Vintex] PRE-BUILD AUTHENTICATION FAILED");
			Debug.LogWarning((object)"[Vintex] ════════════════════════════════════════════════════════════");
			Debug.LogWarning((object)("[Vintex] " + text.Replace("\n", "\n[Vintex] ")));
			Debug.LogWarning((object)"[Vintex] ════════════════════════════════════════════════════════════");
			Debug.LogWarning((object)"[Vintex] Batch mode - continuing build. Set VINTEX_SKIP_PREBUILD_AUTH=1 to suppress this warning.");
			return;
		}
		switch (EditorUtility.DisplayDialogComplex("Vintex - Build Authentication Failed", text, "Build Anyway", "Cancel Build", "Open Settings"))
		{
		case 1:
			throw new BuildFailedException("[Vintex] Build cancelled - authentication failed");
		case 2:
			VintexDashboard.ShowSettings();
			throw new BuildFailedException("[Vintex] Build cancelled - opening settings");
		default:
			Debug.LogWarning((object)"[Vintex] Proceeding with build despite authentication failure");
			break;
		}
	}

	private string GetSceneOculusAppId()
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		Scene activeScene = SceneManager.GetActiveScene();
		GameObject[] rootGameObjects = activeScene.GetRootGameObjects();
		for (int i = 0; i < rootGameObjects.Length; i++)
		{
			Transform[] componentsInChildren = rootGameObjects[i].GetComponentsInChildren<Transform>(true);
			for (int j = 0; j < componentsInChildren.Length; j++)
			{
				MonoBehaviour[] components = ((Component)componentsInChildren[j]).gameObject.GetComponents<MonoBehaviour>();
				foreach (MonoBehaviour val in components)
				{
					if (!((Object)(object)val == (Object)null))
					{
						SerializedProperty val2 = new SerializedObject((Object)(object)val).FindProperty("oculusAppId");
						if (val2 != null && !string.IsNullOrEmpty(val2.stringValue))
						{
							return val2.stringValue;
						}
					}
				}
			}
		}
		GameObject val3 = AssetDatabase.LoadAssetAtPath<GameObject>("Assets/VintexSDK/Prefabs/VintexManager.prefab");
		if ((Object)(object)val3 != (Object)null)
		{
			MonoBehaviour[] components = val3.GetComponents<MonoBehaviour>();
			foreach (MonoBehaviour val4 in components)
			{
				if (!((Object)(object)val4 == (Object)null))
				{
					SerializedProperty val5 = new SerializedObject((Object)(object)val4).FindProperty("oculusAppId");
					if (val5 != null && !string.IsNullOrEmpty(val5.stringValue))
					{
						Debug.Log((object)("[Vintex] Oculus App ID loaded from prefab: " + val5.stringValue));
						return val5.stringValue;
					}
				}
			}
		}
		return null;
	}

	public static void ConfigurePluginImportSettings()
	{
		if (File.Exists("Assets/VintexSDK/Plugins/Android/libs/arm64-v8a/libVintexCore.so"))
		{
			ConfigureNativeLibraryImportSettings("Assets/VintexSDK/Plugins/Android/libs/arm64-v8a/libVintexCore.so");
		}
		if (File.Exists("Assets/VintexSDK/Plugins/Android/VintexAssets.aar"))
		{
			ConfigureAarImportSettings("Assets/VintexSDK/Plugins/Android/VintexAssets.aar");
		}
	}

	private static void ConfigureNativeLibraryImportSettings(string absolutePath)
	{
		string text = Application.dataPath.Replace("/Assets", "");
		string text2 = absolutePath.Replace("\\", "/").Replace(text + "/", "");
		AssetImporter atPath = AssetImporter.GetAtPath(text2);
		PluginImporter val = (PluginImporter)(object)((atPath is PluginImporter) ? atPath : null);
		if ((Object)(object)val == (Object)null)
		{
			Debug.LogWarning((object)("[Vintex] Could not get PluginImporter for: " + text2));
			return;
		}
		val.SetCompatibleWithAnyPlatform(false);
		val.SetCompatibleWithEditor(false);
		val.SetCompatibleWithPlatform((BuildTarget)5, false);
		val.SetCompatibleWithPlatform((BuildTarget)19, false);
		val.SetCompatibleWithPlatform((BuildTarget)24, false);
		val.SetCompatibleWithPlatform((BuildTarget)2, false);
		val.SetCompatibleWithPlatform((BuildTarget)13, true);
		val.SetPlatformData((BuildTarget)13, "CPU", "ARM64");
		val.isPreloaded = true;
		((AssetImporter)val).SaveAndReimport();
		Debug.Log((object)"[Vintex] Configured native library: Android ARM64 only");
	}

	private static void ConfigureAarImportSettings(string absolutePath)
	{
		string text = Application.dataPath.Replace("/Assets", "");
		string text2 = absolutePath.Replace("\\", "/").Replace(text + "/", "");
		AssetImporter atPath = AssetImporter.GetAtPath(text2);
		PluginImporter val = (PluginImporter)(object)((atPath is PluginImporter) ? atPath : null);
		if ((Object)(object)val == (Object)null)
		{
			Debug.LogWarning((object)("[Vintex] Could not get PluginImporter for: " + text2));
			return;
		}
		val.SetCompatibleWithAnyPlatform(false);
		val.SetCompatibleWithEditor(false);
		val.SetCompatibleWithPlatform((BuildTarget)5, false);
		val.SetCompatibleWithPlatform((BuildTarget)19, false);
		val.SetCompatibleWithPlatform((BuildTarget)24, false);
		val.SetCompatibleWithPlatform((BuildTarget)2, false);
		val.SetCompatibleWithPlatform((BuildTarget)13, true);
		((AssetImporter)val).SaveAndReimport();
		Debug.Log((object)"[Vintex] Configured AAR: Android only");
	}

	public void OnPostprocessBuild(BuildReport report)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Invalid comparison between Unknown and I4
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0135: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		BuildSummary summary = report.summary;
		if ((int)summary.platform != 13)
		{
			return;
		}
		if (!IsVintexIncludedInBuild())
		{
			Debug.Log((object)"[Vintex] TH_VINTEX not defined - skipping post-build verification.");
			return;
		}
		VintexBuildType buildType = BuildType;
		string apiEndpointDisplayName = GetApiEndpointDisplayName(buildType);
		if (buildType == VintexBuildType.QA)
		{
			Debug.Log((object)"");
			Debug.Log((object)"╔══════════════════════════════════════════════════════════════╗");
			Debug.Log((object)("║     BUILD COMPLETE - QA Environment (" + apiEndpointDisplayName + ")    ║"));
			Debug.Log((object)"╚══════════════════════════════════════════════════════════════╝");
			Debug.Log((object)"");
		}
		else
		{
			Debug.Log((object)"");
			Debug.Log((object)"╔══════════════════════════════════════════════════════════════╗");
			Debug.Log((object)("║     BUILD COMPLETE - LIVE Environment (" + apiEndpointDisplayName + ")   ║"));
			Debug.Log((object)"║     Ready for production release.                            ║");
			Debug.Log((object)"╚══════════════════════════════════════════════════════════════╝");
			Debug.Log((object)"");
		}
		string text;
		if (string.IsNullOrEmpty(ExternalAssetsDirectory))
		{
			summary = report.summary;
			text = Path.GetDirectoryName(summary.outputPath);
		}
		else
		{
			text = ExternalAssetsDirectory;
		}
		string text2 = text;
		Debug.Log((object)("[Vintex] Post-build asset scan starting. Directory: " + text2));
		if (!string.IsNullOrEmpty(ExternalAssetsDirectory))
		{
			Debug.Log((object)("[Vintex] Using custom external assets directory: " + ExternalAssetsDirectory));
		}
		_isUploadInProgress = true;
		_uploadStartTime = DateTime.Now;
		try
		{
			ProcessBuildAssetsAsync(text2).GetAwaiter().GetResult();
			summary = report.summary;
			string outputPath = summary.outputPath;
			if (!string.IsNullOrEmpty(outputPath) && File.Exists(outputPath) && outputPath.EndsWith(".apk"))
			{
				ProcessAPKRegistrationAsync(outputPath).GetAwaiter().GetResult();
				return;
			}
			Debug.LogWarning((object)("[Vintex] APK not found at build output path: " + outputPath));
			Debug.LogWarning((object)"[Vintex] Skipping APK registration. This is expected for AAB builds.");
		}
		catch (Exception ex)
		{
			Debug.LogError((object)("[Vintex] Build verification failed: " + ex.Message));
		}
		finally
		{
			_isUploadInProgress = false;
		}
	}

	public static void SetBuildTypeQA()
	{
		BuildType = VintexBuildType.QA;
		Debug.Log((object)"[Vintex] Environment set to: QA");
	}

	public static void SetBuildTypeLive()
	{
		BuildType = VintexBuildType.Live;
		Debug.Log((object)"[Vintex] Environment set to: Live");
	}

	private static string NormalizePath(string path)
	{
		List<string> values = (from p in path.Replace('\\', '/').Split('/')
			where !string.IsNullOrEmpty(p) && p != "." && p != ".."
			select p).ToList();
		return string.Join("/", values);
	}

	private static List<ZipFileEntry> ParseZipEntries(string zipPath, bool includeMeta = false)
	{
		List<ZipFileEntry> list = new List<ZipFileEntry>();
		using (FileStream fileStream = new FileStream(zipPath, FileMode.Open, FileAccess.Read))
		{
			using BinaryReader binaryReader = new BinaryReader(fileStream);
			long num = -1L;
			long num2 = Math.Max(0L, fileStream.Length - 65557);
			for (long num3 = fileStream.Length - 22; num3 >= num2; num3--)
			{
				fileStream.Seek(num3, SeekOrigin.Begin);
				if (binaryReader.ReadUInt32() == 101010256)
				{
					num = num3;
					break;
				}
			}
			if (num < 0)
			{
				Debug.LogWarning((object)"[Vintex] Failed to find ZIP End of Central Directory");
				return list;
			}
			fileStream.Seek(num + 10, SeekOrigin.Begin);
			ushort num4 = binaryReader.ReadUInt16();
			binaryReader.ReadUInt32();
			uint num5 = binaryReader.ReadUInt32();
			fileStream.Seek(num5, SeekOrigin.Begin);
			for (int i = 0; i < num4; i++)
			{
				try
				{
					if (binaryReader.ReadUInt32() != 33639248)
					{
						break;
					}
					binaryReader.ReadUInt16();
					binaryReader.ReadUInt16();
					binaryReader.ReadUInt16();
					binaryReader.ReadUInt16();
					ushort lastModTime = binaryReader.ReadUInt16();
					ushort lastModDate = binaryReader.ReadUInt16();
					uint crc = binaryReader.ReadUInt32();
					uint compressedSize = binaryReader.ReadUInt32();
					uint uncompressedSize = binaryReader.ReadUInt32();
					ushort num6 = binaryReader.ReadUInt16();
					ushort num7 = binaryReader.ReadUInt16();
					ushort num8 = binaryReader.ReadUInt16();
					binaryReader.ReadUInt16();
					binaryReader.ReadUInt16();
					binaryReader.ReadUInt32();
					uint num9 = binaryReader.ReadUInt32();
					byte[] bytes = binaryReader.ReadBytes(num6);
					string text = Encoding.UTF8.GetString(bytes);
					long compressedDataOffset = num9 + 30 + num6;
					if (num7 + num8 > 0)
					{
						fileStream.Seek(num7 + num8, SeekOrigin.Current);
					}
					if (!string.IsNullOrEmpty(text) && !text.EndsWith("/") && (includeMeta || !text.StartsWith("META-INF/")))
					{
						list.Add(new ZipFileEntry
						{
							FileName = text,
							Crc32 = crc,
							UncompressedSize = uncompressedSize,
							CompressedSize = compressedSize,
							LastModTime = lastModTime,
							LastModDate = lastModDate,
							CompressedDataOffset = compressedDataOffset
						});
					}
					continue;
				}
				catch (EndOfStreamException)
				{
				}
				break;
			}
		}
		return list;
	}

	private static string CalculateOBBHash(string obbPath)
	{
		try
		{
			SortedDictionary<string, uint> sortedDictionary = new SortedDictionary<string, uint>(StringComparer.Ordinal);
			foreach (ZipFileEntry item in ParseZipEntries(obbPath))
			{
				string text = NormalizePath(item.FileName);
				sortedDictionary[text] = item.Crc32;
				Debug.Log((object)$"OBB Entry: {item.FileName} -> {text} (CRC: {item.Crc32:X8})");
			}
			Debug.Log((object)("=== Calculating MD5 for OBB: " + obbPath + " ==="));
			Debug.Log((object)$"Total entries to hash: {sortedDictionary.Count}");
			using MD5 mD = MD5.Create();
			int num = 0;
			foreach (KeyValuePair<string, uint> item2 in sortedDictionary)
			{
				Debug.Log((object)$"[{num}] Hashing: '{item2.Key}' CRC32: 0x{item2.Value:X8}");
				byte[] bytes = Encoding.UTF8.GetBytes(item2.Key);
				mD.TransformBlock(bytes, 0, bytes.Length, null, 0);
				byte[] bytes2 = BitConverter.GetBytes(item2.Value);
				Debug.Log((object)$"    Path bytes: {bytes.Length}, CRC bytes: {BitConverter.ToString(bytes2)}");
				mD.TransformBlock(bytes2, 0, bytes2.Length, null, 0);
				num++;
			}
			mD.TransformFinalBlock(new byte[0], 0, 0);
			string text2 = BitConverter.ToString(mD.Hash).Replace("-", "").ToLowerInvariant();
			Debug.Log((object)("=== Final MD5: " + text2 + " ==="));
			return text2;
		}
		catch (Exception ex)
		{
			Debug.LogError((object)("Error calculating OBB hash: " + ex.Message));
			throw;
		}
	}

	private static List<OBBFileDetail> CollectOBBFileDetails(string obbPath)
	{
		List<OBBFileDetail> list = new List<OBBFileDetail>();
		try
		{
			foreach (ZipFileEntry item in ParseZipEntries(obbPath))
			{
				string path = NormalizePath(item.FileName);
				list.Add(new OBBFileDetail
				{
					Path = path,
					Crc = item.Crc32,
					Size = item.UncompressedSize
				});
			}
		}
		catch (Exception ex)
		{
			Debug.LogError((object)("Error collecting OBB file details: " + ex.Message));
		}
		return list;
	}

	private static string EncodeFileDetails(List<OBBFileDetail> details)
	{
		try
		{
			string s = JsonConvert.SerializeObject((object)details.Select((OBBFileDetail d) => new
			{
				path = d.Path,
				crc = d.Crc,
				size = d.Size
			}).ToArray());
			byte[] bytes = Encoding.UTF8.GetBytes(s);
			using MemoryStream memoryStream = new MemoryStream();
			using (GZipStream gZipStream = new GZipStream(memoryStream, CompressionMode.Compress))
			{
				gZipStream.Write(bytes, 0, bytes.Length);
			}
			return Convert.ToBase64String(memoryStream.ToArray());
		}
		catch (Exception ex)
		{
			Debug.LogError((object)("Error encoding file details: " + ex.Message));
			return "";
		}
	}

	private static async Task ProcessBuildAssetsAsync(string buildPath)
	{
		string buildVersion = PlayerSettings.bundleVersion;
		Debug.Log((object)"[Vintex] Post-build asset verification starting");
		Debug.Log((object)("[Vintex] Build Version: '" + buildVersion + "'"));
		if (string.IsNullOrEmpty(buildVersion))
		{
			Debug.LogError((object)"[Vintex] Build version is empty! Please set a version in Player Settings.");
			return;
		}
		if (!Directory.Exists(buildPath))
		{
			Debug.LogError((object)("[Vintex] Build directory does not exist: " + buildPath));
			return;
		}
		bool obbEnabled = ObbEnabled;
		Debug.Log((object)$"[Vintex] OBB Files Enabled (Advanced setting): {obbEnabled}");
		List<ObbHashesRequestObject> assetData = new List<ObbHashesRequestObject>();
		if (!obbEnabled)
		{
			Debug.Log((object)"[Vintex] OBB files disabled - skipping OBB scan.");
			Debug.Log((object)"[Vintex] Proceeding with build registration (no OBB data).");
		}
		else
		{
			Debug.Log((object)("[Vintex] Scanning for .obb files in: " + buildPath));
			string[] files = Directory.GetFiles(buildPath, "*.obb", SearchOption.AllDirectories);
			Debug.Log((object)$"[Vintex] Found {files.Length} .obb file(s)");
			if (files.Length == 0)
			{
				Debug.LogWarning((object)"[Vintex] ════════════════════════════════════════════════════════════");
				Debug.LogWarning((object)"[Vintex] OBB mode ENABLED but no .obb files found!");
				Debug.LogWarning((object)"[Vintex] ════════════════════════════════════════════════════════════");
				Debug.LogWarning((object)"[Vintex] Proceeding with build registration WITHOUT OBB data.");
				Debug.LogWarning((object)"[Vintex] If this is unexpected, check:");
				Debug.LogWarning((object)"[Vintex]   - Player Settings > Publishing Settings > Split Application Binary");
				Debug.LogWarning((object)"[Vintex]   - Or disable OBB in Tools > Vintex > Settings > Advanced");
				Debug.LogWarning((object)"[Vintex] ════════════════════════════════════════════════════════════");
			}
			Debug.Log((object)$"[Vintex] Found {files.Length} asset file(s) to process");
			string[] array = files;
			foreach (string text in array)
			{
				try
				{
					FileInfo fileInfo = new FileInfo(text);
					string hash = CalculateOBBHash(text);
					string obbDetails = EncodeFileDetails(CollectOBBFileDetails(text));
					assetData.Add(new ObbHashesRequestObject
					{
						FileName = fileInfo.Name,
						FileSize = fileInfo.Length,
						Hash = hash,
						LastModified = fileInfo.LastWriteTime.ToString("o"),
						ObbDetails = obbDetails
					});
					Debug.Log((object)$"[Vintex] Processed: {fileInfo.Name} ({fileInfo.Length} bytes)");
				}
				catch (Exception ex)
				{
					Debug.LogError((object)("[Vintex] Error processing asset file " + text + ": " + ex.Message));
				}
			}
			if (files.Length != 0 && assetData.Count == 0)
			{
				Debug.LogError((object)"[Vintex] Found OBB files but failed to process any of them.");
				return;
			}
		}
		VintexBuildType currentBuildType = BuildType;
		string buildTypeApiString = GetBuildTypeApiString(currentBuildType);
		string apiUrlForBuildType = GetApiUrlForBuildType(currentBuildType);
		string apiEndpointDisplayName = GetApiEndpointDisplayName(currentBuildType);
		ObbHashSetRequest obbHashSetRequest = new ObbHashSetRequest
		{
			BuildVersion = buildVersion,
			ObbHashes = assetData,
			BuildType = buildTypeApiString,
			ObbEnabled = obbEnabled
		};
		Debug.Log((object)"[Vintex] ════════════════════════════════════════════════════════════");
		Debug.Log((object)"[Vintex] Starting Vintex OBB Build Verification");
		Debug.Log((object)"[Vintex] ════════════════════════════════════════════════════════════");
		Debug.Log((object)("[Vintex] Build ID: " + buildVersion));
		Debug.Log((object)$"[Vintex] Build Type: {currentBuildType} (API: {buildTypeApiString})");
		Debug.Log((object)("[Vintex] API Endpoint: " + apiEndpointDisplayName));
		Debug.Log((object)$"[Vintex] OBB Enabled: {obbEnabled}");
		Debug.Log((object)$"[Vintex] OBB Files: {assetData.Count}");
		if (assetData.Count > 0)
		{
			foreach (ObbHashesRequestObject item in assetData)
			{
				Debug.Log((object)$"[Vintex]   - {item.FileName} ({item.FileSize} bytes, Hash: {item.Hash})");
			}
		}
		Debug.Log((object)"[Vintex] ────────────────────────────────────────────────────────────");
		using HttpClient client = new HttpClient();
		string text2 = apiUrlForBuildType + "obb-hash-set";
		try
		{
			client.Timeout = TimeSpan.FromSeconds(60.0);
			client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", DevGameToken);
			string content = JsonConvert.SerializeObject((object)obbHashSetRequest);
			Debug.Log((object)("[Vintex] Sending request to: " + text2));
			StringContent content2 = new StringContent(content, Encoding.UTF8, "application/json");
			HttpResponseMessage response = await client.PostAsync(text2, content2).ConfigureAwait(continueOnCapturedContext: false);
			string text3 = await response.Content.ReadAsStringAsync().ConfigureAwait(continueOnCapturedContext: false);
			if (response.IsSuccessStatusCode)
			{
				Debug.Log((object)"[Vintex] ════════════════════════════════════════════════════════════");
				Debug.Log((object)"[Vintex] BUILD VERIFICATION SUCCESSFUL");
				Debug.Log((object)"[Vintex] ════════════════════════════════════════════════════════════");
				Debug.Log((object)("[Vintex] Build ID: " + buildVersion));
				Debug.Log((object)$"[Vintex] Environment: {currentBuildType}");
				Debug.Log((object)("[Vintex] BuildType sent: " + buildTypeApiString));
				Debug.Log((object)$"[Vintex] OBB Files registered: {assetData.Count}");
				Debug.Log((object)$"[Vintex] Server response: {(int)response.StatusCode} OK");
				Debug.Log((object)"[Vintex] ════════════════════════════════════════════════════════════");
			}
			else
			{
				Debug.LogError((object)"[Vintex] ════════════════════════════════════════════════════════════");
				Debug.LogError((object)"[Vintex] BUILD VERIFICATION FAILED");
				Debug.LogError((object)"[Vintex] ════════════════════════════════════════════════════════════");
				Debug.LogError((object)$"[Vintex] Server returned error code: {(int)response.StatusCode}");
				Debug.LogError((object)("[Vintex] Response: " + text3));
				Debug.LogError((object)"[Vintex] ════════════════════════════════════════════════════════════");
			}
		}
		catch (HttpRequestException ex2)
		{
			Debug.LogError((object)"[Vintex] ════════════════════════════════════════════════════════════");
			Debug.LogError((object)"[Vintex] BUILD VERIFICATION FAILED - HTTP ERROR");
			Debug.LogError((object)"[Vintex] ════════════════════════════════════════════════════════════");
			Debug.LogError((object)("[Vintex] HTTP Request Error: " + ex2.Message));
			if (ex2.InnerException != null)
			{
				Debug.LogError((object)("[Vintex] Inner Exception: " + ex2.InnerException.Message));
			}
			Debug.LogError((object)"[Vintex] ════════════════════════════════════════════════════════════");
		}
		catch (Exception ex3)
		{
			Debug.LogError((object)"[Vintex] ════════════════════════════════════════════════════════════");
			Debug.LogError((object)"[Vintex] BUILD VERIFICATION FAILED - UNEXPECTED ERROR");
			Debug.LogError((object)"[Vintex] ════════════════════════════════════════════════════════════");
			Debug.LogError((object)("[Vintex] Error: " + ex3.GetType().Name + " - " + ex3.Message));
			Debug.LogError((object)("[Vintex] Stack Trace: " + ex3.StackTrace));
			Debug.LogError((object)"[Vintex] ════════════════════════════════════════════════════════════");
		}
	}

	private static string ComputeFileSHA256(string filePath)
	{
		using SHA256 sHA = SHA256.Create();
		using FileStream inputStream = new FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.Read, 65536);
		return BitConverter.ToString(sHA.ComputeHash(inputStream)).Replace("-", "").ToLowerInvariant();
	}

	private static string ExtractSigningCertFingerprint(string apkPath)
	{
		try
		{
			string text = EditorPrefs.GetString("AndroidSdkRoot", "");
			if (string.IsNullOrEmpty(text))
			{
				text = Environment.GetEnvironmentVariable("ANDROID_HOME") ?? "";
			}
			if (string.IsNullOrEmpty(text))
			{
				text = Environment.GetEnvironmentVariable("ANDROID_SDK_ROOT") ?? "";
			}
			if (string.IsNullOrEmpty(text) || !Directory.Exists(Path.Combine(text, "build-tools")))
			{
				string directoryName = Path.GetDirectoryName(EditorApplication.applicationPath);
				string text2 = Path.Combine(directoryName, "Data", "PlaybackEngines", "AndroidPlayer", "SDK");
				if (Directory.Exists(Path.Combine(text2, "build-tools")))
				{
					text = text2;
					Debug.Log((object)("[Vintex] Using Unity bundled Android SDK: " + text));
				}
			}
			if (string.IsNullOrEmpty(text))
			{
				Debug.LogWarning((object)"[Vintex] Android SDK path not found - cannot extract signing cert");
				return "";
			}
			string text3 = Path.Combine(text, "build-tools");
			if (!Directory.Exists(text3))
			{
				Debug.LogWarning((object)("[Vintex] build-tools directory not found at: " + text3));
				return "";
			}
			string[] array = (from d in Directory.GetDirectories(text3)
				orderby Path.GetFileName(d) descending
				select d).ToArray();
			string text4 = null;
			string[] array2 = array;
			foreach (string path in array2)
			{
				string text5 = Path.Combine(path, "apksigner.bat");
				if (!File.Exists(text5))
				{
					text5 = Path.Combine(path, "apksigner");
				}
				if (File.Exists(text5))
				{
					text4 = text5;
					break;
				}
			}
			if (text4 == null)
			{
				Debug.LogWarning((object)"[Vintex] apksigner not found in Android SDK build-tools");
				return "";
			}
			Process process = new Process();
			process.StartInfo.FileName = text4;
			process.StartInfo.Arguments = "verify --print-certs \"" + apkPath + "\"";
			process.StartInfo.UseShellExecute = false;
			process.StartInfo.RedirectStandardOutput = true;
			process.StartInfo.RedirectStandardError = true;
			process.StartInfo.CreateNoWindow = true;
			process.Start();
			string text6 = process.StandardOutput.ReadToEnd();
			string arg = process.StandardError.ReadToEnd();
			process.WaitForExit(30000);
			if (process.ExitCode != 0)
			{
				Debug.LogWarning((object)$"[Vintex] apksigner verify failed (exit {process.ExitCode}): {arg}");
				return "";
			}
			array2 = text6.Split('\n');
			foreach (string text7 in array2)
			{
				if (text7.Contains("SHA-256 digest:"))
				{
					string text8 = text7.Split(':').Last().Trim()
						.ToLowerInvariant();
					Debug.Log((object)("[Vintex] Signing cert fingerprint (apksigner): " + text8));
					return text8;
				}
			}
			Debug.LogWarning((object)"[Vintex] Could not parse SHA-256 digest from apksigner output");
			return "";
		}
		catch (Exception ex)
		{
			Debug.LogWarning((object)("[Vintex] Failed to extract signing cert fingerprint: " + ex.Message));
			return "";
		}
	}

	private static (bool isDebuggable, bool wasDetected) DetectDebuggableFromAPK(string apkPath, List<ZipFileEntry> entries)
	{
		try
		{
			ZipFileEntry zipFileEntry = entries.FirstOrDefault((ZipFileEntry e) => e.FileName == "AndroidManifest.xml");
			if (zipFileEntry == null || zipFileEntry.CompressedSize == 0)
			{
				Debug.LogWarning((object)"[Vintex] AndroidManifest.xml not found in APK");
				return (isDebuggable: false, wasDetected: false);
			}
			byte[] array;
			using (FileStream fileStream = new FileStream(apkPath, FileMode.Open, FileAccess.Read))
			{
				fileStream.Seek(zipFileEntry.CompressedDataOffset, SeekOrigin.Begin);
				array = new byte[zipFileEntry.CompressedSize];
				fileStream.Read(array, 0, array.Length);
			}
			byte[] array2;
			if (zipFileEntry.CompressedSize == zipFileEntry.UncompressedSize)
			{
				array2 = array;
			}
			else
			{
				using MemoryStream stream = new MemoryStream(array);
				using DeflateStream deflateStream = new DeflateStream(stream, CompressionMode.Decompress);
				using MemoryStream memoryStream = new MemoryStream();
				deflateStream.CopyTo(memoryStream);
				array2 = memoryStream.ToArray();
			}
			byte[] array3 = new byte[4] { 15, 0, 1, 1 };
			for (int num = 0; num <= array2.Length - 12; num++)
			{
				if (array2[num] == array3[0] && array2[num + 1] == array3[1] && array2[num + 2] == array3[2] && array2[num + 3] == array3[3] && num + 12 <= array2.Length)
				{
					int num2 = num + 4 + 4;
					if (num2 + 4 <= array2.Length)
					{
						bool flag = BitConverter.ToUInt32(array2, num2 + 4) != 0;
						Debug.Log((object)$"[Vintex] Detected android:debuggable={flag} from binary manifest");
						return (isDebuggable: flag, wasDetected: true);
					}
				}
			}
			Debug.Log((object)"[Vintex] android:debuggable attribute not found in manifest (defaults to false)");
			return (isDebuggable: false, wasDetected: true);
		}
		catch (Exception ex)
		{
			Debug.LogWarning((object)("[Vintex] Failed to parse AndroidManifest.xml for debuggable: " + ex.Message));
			return (isDebuggable: false, wasDetected: false);
		}
	}

	private static string EncodeAPKDetails(List<ApkLibraryInfo> libraries, List<ApkDexInfo> dexFiles)
	{
		try
		{
			string s = JsonConvert.SerializeObject((object)new { libraries, dexFiles });
			byte[] bytes = Encoding.UTF8.GetBytes(s);
			using MemoryStream memoryStream = new MemoryStream();
			using (GZipStream gZipStream = new GZipStream(memoryStream, CompressionMode.Compress))
			{
				gZipStream.Write(bytes, 0, bytes.Length);
			}
			return Convert.ToBase64String(memoryStream.ToArray());
		}
		catch (Exception ex)
		{
			Debug.LogError((object)("[Vintex] Error encoding APK details: " + ex.Message));
			return "";
		}
	}

	private static async Task ProcessAPKRegistrationAsync(string apkPath)
	{
		Debug.Log((object)"[Vintex] ════════════════════════════════════════════════════════════");
		Debug.Log((object)"[Vintex] Starting APK Build-Time Registration");
		Debug.Log((object)"[Vintex] ════════════════════════════════════════════════════════════");
		Debug.Log((object)("[Vintex] APK Path: " + apkPath));
		try
		{
			FileInfo fileInfo = new FileInfo(apkPath);
			string text = ComputeFileSHA256(apkPath);
			Debug.Log((object)("[Vintex] APK SHA256: " + text));
			Debug.Log((object)$"[Vintex] APK Size: {fileInfo.Length} bytes");
			List<ZipFileEntry> list = ParseZipEntries(apkPath, includeMeta: true);
			Debug.Log((object)$"[Vintex] Total ZIP entries: {list.Count}");
			List<ApkLibraryInfo> list2 = new List<ApkLibraryInfo>();
			List<ApkDexInfo> list3 = new List<ApkDexInfo>();
			foreach (ZipFileEntry item in list)
			{
				if (item.FileName.EndsWith(".so"))
				{
					list2.Add(new ApkLibraryInfo
					{
						Name = item.FileName,
						Size = item.UncompressedSize,
						Crc32 = item.Crc32,
						ModTime = item.LastModTime,
						ModDate = item.LastModDate
					});
				}
				else if (item.FileName.StartsWith("classes") && item.FileName.EndsWith(".dex"))
				{
					list3.Add(new ApkDexInfo
					{
						Name = item.FileName,
						Size = item.UncompressedSize
					});
				}
			}
			Debug.Log((object)$"[Vintex] Libraries: {list2.Count}, DEX files: {list3.Count}");
			string text2 = ExtractSigningCertFingerprint(apkPath);
			var (flag, flag2) = DetectDebuggableFromAPK(apkPath, list);
			if (flag)
			{
				Debug.LogWarning((object)"[Vintex] APK has android:debuggable=true - this should not be shipped!");
			}
			string aPKDetails = EncodeAPKDetails(list2, list3);
			string buildVersion = PlayerSettings.bundleVersion;
			VintexBuildType buildType = BuildType;
			string buildTypeApiString = GetBuildTypeApiString(buildType);
			string apiUrlForBuildType = GetApiUrlForBuildType(buildType);
			ApkHashSetRequest apkHashSetRequest = new ApkHashSetRequest
			{
				BuildVersion = buildVersion,
				BuildType = buildTypeApiString,
				APKHash = text,
				APKFileSize = fileInfo.Length,
				APKLastModified = fileInfo.LastWriteTimeUtc.ToString("o"),
				SigningCertFingerprint = text2,
				IsDebuggable = flag,
				IsDebuggableUnknown = !flag2,
				TotalEntryCount = list.Count,
				APKDetails = aPKDetails
			};
			Debug.Log((object)"[Vintex] ────────────────────────────────────────────────────────────");
			Debug.Log((object)("[Vintex] Build ID: " + buildVersion));
			Debug.Log((object)$"[Vintex] Build Type: {buildType} (API: {buildTypeApiString})");
			Debug.Log((object)("[Vintex] APK Hash: " + text));
			Debug.Log((object)$"[Vintex] APK Size: {fileInfo.Length} bytes");
			Debug.Log((object)("[Vintex] Cert Fingerprint: " + text2));
			Debug.Log((object)$"[Vintex] Debuggable: {flag} (detected: {flag2})");
			Debug.Log((object)$"[Vintex] Libraries: {list2.Count}");
			foreach (ApkLibraryInfo item2 in list2)
			{
				Debug.Log((object)$"[Vintex]   - {item2.Name} ({item2.Size} bytes, CRC: {item2.Crc32:X8})");
			}
			Debug.Log((object)"[Vintex] ────────────────────────────────────────────────────────────");
			using HttpClient client = new HttpClient();
			string text3 = apiUrlForBuildType + "apk-hash-set";
			client.Timeout = TimeSpan.FromSeconds(60.0);
			client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", DevGameToken);
			string content = JsonConvert.SerializeObject((object)apkHashSetRequest);
			Debug.Log((object)("[Vintex] Sending APK registration to: " + text3));
			StringContent content2 = new StringContent(content, Encoding.UTF8, "application/json");
			HttpResponseMessage response = await client.PostAsync(text3, content2).ConfigureAwait(continueOnCapturedContext: false);
			string text4 = await response.Content.ReadAsStringAsync().ConfigureAwait(continueOnCapturedContext: false);
			if (response.IsSuccessStatusCode)
			{
				Debug.Log((object)"[Vintex] ════════════════════════════════════════════════════════════");
				Debug.Log((object)"[Vintex] APK REGISTRATION SUCCESSFUL");
				Debug.Log((object)"[Vintex] ════════════════════════════════════════════════════════════");
				Debug.Log((object)("[Vintex] Build ID: " + buildVersion));
				Debug.Log((object)$"[Vintex] Server response: {(int)response.StatusCode} OK");
				Debug.Log((object)"[Vintex] ════════════════════════════════════════════════════════════");
			}
			else
			{
				Debug.LogError((object)"[Vintex] ════════════════════════════════════════════════════════════");
				Debug.LogError((object)"[Vintex] APK REGISTRATION FAILED");
				Debug.LogError((object)"[Vintex] ════════════════════════════════════════════════════════════");
				Debug.LogError((object)$"[Vintex] Server returned error code: {(int)response.StatusCode}");
				Debug.LogError((object)("[Vintex] Response: " + text4));
				Debug.LogError((object)"[Vintex] ════════════════════════════════════════════════════════════");
			}
		}
		catch (HttpRequestException ex)
		{
			Debug.LogError((object)"[Vintex] ════════════════════════════════════════════════════════════");
			Debug.LogError((object)"[Vintex] APK REGISTRATION FAILED - HTTP ERROR");
			Debug.LogError((object)"[Vintex] ════════════════════════════════════════════════════════════");
			Debug.LogError((object)("[Vintex] HTTP Request Error: " + ex.Message));
			if (ex.InnerException != null)
			{
				Debug.LogError((object)("[Vintex] Inner Exception: " + ex.InnerException.Message));
			}
			Debug.LogError((object)"[Vintex] ════════════════════════════════════════════════════════════");
		}
		catch (Exception ex2)
		{
			Debug.LogError((object)"[Vintex] ════════════════════════════════════════════════════════════");
			Debug.LogError((object)"[Vintex] APK REGISTRATION FAILED - UNEXPECTED ERROR");
			Debug.LogError((object)"[Vintex] ════════════════════════════════════════════════════════════");
			Debug.LogError((object)("[Vintex] Error: " + ex2.GetType().Name + " - " + ex2.Message));
			Debug.LogError((object)"[Vintex] ════════════════════════════════════════════════════════════");
		}
	}
}
}
