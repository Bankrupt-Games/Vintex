namespace VintexEditorPlugin
{

/// <summary>
/// Build type determines which asset verification database is updated.
/// Dev: For development/testing builds - won't affect production validation
/// Live: For production builds - updates the live validation database
/// </summary>
public enum VintexBuildType
{
	QA,
	Live
}
}
