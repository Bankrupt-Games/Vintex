using System;
using UnityEditor;
using UnityEngine;
using Object = UnityEngine.Object;

namespace VintexEditorPlugin
{

public class VintexBuildDialog : EditorWindow
{
	public enum DialogResult
	{
		None,
		BuildOnLive,
		SwitchToQA,
		Cancel,
		OpenBuildManagement
	}

	private static DialogResult _result;

	private static bool _isOpen;

	private Texture2D _bgTexture;

	private VintexBuildType _currentEnv;

	private string _buildVersion;

	private string _currentLiveBuild;

	private int _outdatedDays = 3;

	private const string BuildManagementUrl = "https://vintex.bankruptgames.net/dashboard";

	public static DialogResult ShowLiveWarning(VintexBuildType currentEnv, string buildVersion)
	{
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Expected O, but got Unknown
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		if (_isOpen)
		{
			return DialogResult.Cancel;
		}
		_result = DialogResult.None;
		_isOpen = true;
		VintexBuildDialog vintexBuildDialog = ScriptableObject.CreateInstance<VintexBuildDialog>();
		vintexBuildDialog._currentEnv = currentEnv;
		vintexBuildDialog._buildVersion = buildVersion;
		((EditorWindow)vintexBuildDialog).titleContent = new GUIContent("Vintex Build");
		((EditorWindow)vintexBuildDialog).minSize = new Vector2(480f, 400f);
		((EditorWindow)vintexBuildDialog).maxSize = new Vector2(480f, 400f);
		Rect position = ((EditorWindow)vintexBuildDialog).position;
		Resolution currentResolution = Screen.currentResolution;
		position.x = (currentResolution.width - 480) / 2;
		currentResolution = Screen.currentResolution;
		position.y = (currentResolution.height - 400) / 2;
		((EditorWindow)vintexBuildDialog).position = position;
		((EditorWindow)vintexBuildDialog).ShowModalUtility();
		_isOpen = false;
		return _result;
	}

	private void OnEnable()
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		_bgTexture = MakeTex(VintexStyles.Dark);
	}

	private void OnDestroy()
	{
		if ((Object)(object)_bgTexture != (Object)null)
		{
			Object.DestroyImmediate((Object)(object)_bgTexture);
		}
		if (_result == DialogResult.None)
		{
			_result = DialogResult.Cancel;
		}
	}

	private Texture2D MakeTex(Color color)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Expected O, but got Unknown
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		Texture2D val = new Texture2D(2, 2);
		((Object)val).hideFlags = (HideFlags)61;
		for (int i = 0; i < 4; i++)
		{
			val.SetPixel(i % 2, i / 2, color);
		}
		val.Apply();
		return val;
	}

	private void OnGUI()
	{
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)_bgTexture == (Object)null)
		{
			_bgTexture = MakeTex(VintexStyles.Dark);
		}
		Rect position = ((EditorWindow)this).position;
		float width = position.width;
		position = ((EditorWindow)this).position;
		GUI.DrawTexture(new Rect(0f, 0f, width, position.height), (Texture)(object)_bgTexture);
		GUILayout.BeginVertical(Array.Empty<GUILayoutOption>());
		GUILayout.Space(20f);
		DrawHeader();
		GUILayout.Space(16f);
		DrawEnvironmentBadge();
		GUILayout.Space(16f);
		DrawWarningContent();
		GUILayout.FlexibleSpace();
		DrawButtons();
		GUILayout.Space(16f);
		GUILayout.EndVertical();
	}

	private void DrawHeader()
	{
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Expected O, but got Unknown
		GUILayout.BeginHorizontal(Array.Empty<GUILayoutOption>());
		GUILayout.FlexibleSpace();
		GUIStyle val = new GUIStyle(GUI.skin.label)
		{
			fontSize = 18,
			fontStyle = (FontStyle)1,
			alignment = (TextAnchor)4
		};
		val.normal.textColor = VintexStyles.Warning;
		GUIStyle val2 = val;
		GUILayout.Label("⚠  Live Environment Warning", val2, Array.Empty<GUILayoutOption>());
		GUILayout.FlexibleSpace();
		GUILayout.EndHorizontal();
	}

	private void DrawEnvironmentBadge()
	{
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Expected O, but got Unknown
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Expected O, but got Unknown
		GUILayout.BeginHorizontal(Array.Empty<GUILayoutOption>());
		GUILayout.FlexibleSpace();
		Rect rect = GUILayoutUtility.GetRect(200f, 50f);
		Color val = ((_currentEnv == VintexBuildType.Live) ? VintexStyles.LiveGreen : VintexStyles.QAOrange);
		EditorGUI.DrawRect(rect, new Color(val.r, val.g, val.b, 0.15f));
		DrawBorder(rect, val, 2f);
		string text = ((_currentEnv == VintexBuildType.Live) ? "LIVE" : "QA");
		GUIStyle val2 = new GUIStyle(GUI.skin.label)
		{
			fontSize = 16,
			fontStyle = (FontStyle)1,
			alignment = (TextAnchor)4
		};
		val2.normal.textColor = val;
		GUIStyle val3 = val2;
		GUI.Label(rect, text, val3);
		GUILayout.FlexibleSpace();
		GUILayout.EndHorizontal();
		GUILayout.Space(8f);
		GUIStyle val4 = new GUIStyle(GUI.skin.label)
		{
			fontSize = 11,
			alignment = (TextAnchor)4
		};
		val4.normal.textColor = VintexStyles.TextSecondary;
		GUIStyle val5 = val4;
		GUILayout.Label("Building version: " + _buildVersion, val5, Array.Empty<GUILayoutOption>());
	}

	private void DrawWarningContent()
	{
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Expected O, but got Unknown
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Expected O, but got Unknown
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0100: Unknown result type (might be due to invalid IL or missing references)
		//IL_010c: Expected O, but got Unknown
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0161: Unknown result type (might be due to invalid IL or missing references)
		//IL_0198: Unknown result type (might be due to invalid IL or missing references)
		//IL_01df: Unknown result type (might be due to invalid IL or missing references)
		//IL_0204: Unknown result type (might be due to invalid IL or missing references)
		//IL_0209: Unknown result type (might be due to invalid IL or missing references)
		//IL_0211: Unknown result type (might be due to invalid IL or missing references)
		//IL_0218: Unknown result type (might be due to invalid IL or missing references)
		//IL_021e: Unknown result type (might be due to invalid IL or missing references)
		//IL_022a: Expected O, but got Unknown
		GUILayout.BeginHorizontal(Array.Empty<GUILayoutOption>());
		GUILayout.Space(24f);
		GUILayout.BeginVertical(Array.Empty<GUILayoutOption>());
		GUIStyle val = new GUIStyle(GUI.skin.label)
		{
			fontSize = 11,
			wordWrap = true
		};
		val.normal.textColor = VintexStyles.TextPrimary;
		GUIStyle val2 = val;
		GUILayout.Label("This build will replace your current production version.", val2, Array.Empty<GUILayoutOption>());
		GUILayout.Space(12f);
		Rect position = ((EditorWindow)this).position;
		Rect rect = GUILayoutUtility.GetRect(position.width - 48f, 90f);
		EditorGUI.DrawRect(rect, VintexStyles.Card);
		DrawBorder(rect, VintexStyles.Border, 1f);
		float num = 12f;
		float num2 = rect.y + num;
		GUIStyle val3 = new GUIStyle(GUI.skin.label)
		{
			fontSize = 10
		};
		val3.normal.textColor = VintexStyles.TextSecondary;
		GUIStyle val4 = val3;
		GUIStyle val5 = new GUIStyle(GUI.skin.label)
		{
			fontSize = 10,
			fontStyle = (FontStyle)1
		};
		val5.normal.textColor = VintexStyles.Info;
		GUIStyle val6 = val5;
		GUI.Label(new Rect(rect.x + num, num2, rect.width - num * 2f, 16f), "Coming Soon:", val6);
		num2 += 18f;
		GUI.Label(new Rect(rect.x + num, num2, rect.width - num * 2f, 14f), "• Build version tracking (see which build you're replacing)", val4);
		num2 += 16f;
		GUI.Label(new Rect(rect.x + num, num2, rect.width - num * 2f, 14f), $"• Outdated build protection (default: {_outdatedDays} days grace period)", val4);
		num2 += 16f;
		GUI.Label(new Rect(rect.x + num, num2, rect.width - num * 2f, 14f), "• Automatic client blocking for outdated builds", val4);
		GUILayout.Space(12f);
		GUIStyle val7 = new GUIStyle(GUI.skin.label)
		{
			fontSize = 10,
			wordWrap = true
		};
		val7.normal.textColor = VintexStyles.Warning;
		GUIStyle val8 = val7;
		GUILayout.Label("Please ensure builds not intended for production are built in QA.", val8, Array.Empty<GUILayoutOption>());
		GUILayout.EndVertical();
		GUILayout.Space(24f);
		GUILayout.EndHorizontal();
	}

	private void DrawButtons()
	{
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_013d: Unknown result type (might be due to invalid IL or missing references)
		GUILayout.BeginHorizontal(Array.Empty<GUILayoutOption>());
		GUILayout.Space(24f);
		GUILayout.BeginVertical(Array.Empty<GUILayoutOption>());
		GUILayout.BeginHorizontal(Array.Empty<GUILayoutOption>());
		GUI.backgroundColor = VintexStyles.LiveGreen;
		if (GUILayout.Button("Build on Live", (GUILayoutOption[])(object)new GUILayoutOption[1] { GUILayout.Height(36f) }))
		{
			_result = DialogResult.BuildOnLive;
			((EditorWindow)this).Close();
		}
		GUILayout.Space(8f);
		GUI.backgroundColor = VintexStyles.QAOrange;
		if (GUILayout.Button("Switch to QA & Build", (GUILayoutOption[])(object)new GUILayoutOption[1] { GUILayout.Height(36f) }))
		{
			_result = DialogResult.SwitchToQA;
			((EditorWindow)this).Close();
		}
		GUI.backgroundColor = Color.white;
		GUILayout.EndHorizontal();
		GUILayout.Space(8f);
		GUILayout.BeginHorizontal(Array.Empty<GUILayoutOption>());
		GUI.backgroundColor = VintexStyles.Gray700;
		if (GUILayout.Button("Cancel Build", (GUILayoutOption[])(object)new GUILayoutOption[1] { GUILayout.Height(30f) }))
		{
			_result = DialogResult.Cancel;
			((EditorWindow)this).Close();
		}
		GUILayout.Space(8f);
		GUI.backgroundColor = VintexStyles.Purple;
		if (GUILayout.Button("Open Build Management ↗", (GUILayoutOption[])(object)new GUILayoutOption[1] { GUILayout.Height(30f) }))
		{
			_result = DialogResult.OpenBuildManagement;
			Application.OpenURL(BuildManagementUrl);
			((EditorWindow)this).Close();
		}
		GUI.backgroundColor = Color.white;
		GUILayout.EndHorizontal();
		GUILayout.EndVertical();
		GUILayout.Space(24f);
		GUILayout.EndHorizontal();
	}

	private void DrawBorder(Rect rect, Color color, float thickness)
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		EditorGUI.DrawRect(new Rect(rect.x, rect.y, rect.width, thickness), color);
		EditorGUI.DrawRect(new Rect(rect.x, rect.yMax - thickness, rect.width, thickness), color);
		EditorGUI.DrawRect(new Rect(rect.x, rect.y, thickness, rect.height), color);
		EditorGUI.DrawRect(new Rect(rect.xMax - thickness, rect.y, thickness, rect.height), color);
	}
}
}
