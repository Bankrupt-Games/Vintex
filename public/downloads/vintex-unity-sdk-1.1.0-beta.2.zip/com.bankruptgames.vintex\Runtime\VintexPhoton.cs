using System;
using System.Threading.Tasks;

namespace Vintex
{

public static class VintexPhoton
{
	public enum InjectionResult
	{
		Success,
		NotConfigured,
		Failed,
		Error
	}

	public struct InjectionResponse
	{
		public InjectionResult Result;

		public string Message;

		public bool CanConnect;
	}

	private const string DIAGNOSTIC_PREFIX = "COM_";

	private const string PARAM_TOKEN = "vintex_token";

	private const string PARAM_ERROR = "vintex_error";

	private const string PARAM_REASON = "vintex_reason";

	public static async Task<InjectionResponse> InjectTokenAsync()
	{
		return await Task.FromResult(new InjectionResponse
		{
			Result = InjectionResult.Error,
			Message = "TH_PHOTON not defined",
			CanConnect = false
		});
	}

	public static bool IsAvailable()
	{
		return false;
	}

	public static bool IsPhotonInstalled()
	{
		if (!(Type.GetType("Photon.Pun.PhotonNetwork, PhotonUnityNetworking") != null))
		{
			return Type.GetType("Fusion.NetworkRunner, Fusion.Runtime") != null;
		}
		return true;
	}
}
}
