# Native plugin: libVintexCore.so (arm64-v8a)

Unity auto-imports `.so` files under `Plugins/Android/libs/<abi>/` as Android
native libraries for that ABI. `VintexGamePlugin` loads this via
`[DllImport("VintexCore")]`.

## Beta native build

The included `libVintexCore.so` is a stripped arm64 release build from
`VintexNativeRemake`. It is fail-closed, contains runtime-integrity checks, and
targets `https://vintex.bankruptgames.net`.

The clean-room native remake still documents unfinished attestation and OBB
reconstruction. Treat this as a beta and validate it on real Quest hardware
before gating a production release.

In the Unity Inspector, confirm the importer has **Android / CPU: ARM64** ticked.
Unity infers this from the folder, but verify it after the first import.

Binaries are tracked via Git LFS in the source package.
