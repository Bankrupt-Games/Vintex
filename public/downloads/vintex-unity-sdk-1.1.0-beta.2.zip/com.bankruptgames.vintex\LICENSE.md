# Proprietary License

Copyright © 2026 BankruptGames. All rights reserved.

This software and associated files (the "SDK") are the confidential and
proprietary property of BankruptGames. The SDK is licensed, not sold.

Subject to a valid written agreement or subscription with BankruptGames, licensees
are granted a non-exclusive, non-transferable right to integrate the SDK into
their own applications. Absent such an agreement, no rights are granted.

You may not, except to the extent permitted by your agreement or by applicable
law:

- copy, distribute, sublicense, resell, or make the SDK available to third parties;
- reverse engineer, decompile, or disassemble the native components;
- remove or alter any proprietary notices.

THE SDK IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE, AND NONINFRINGEMENT. IN NO EVENT SHALL BANKRUPTGAMES BE
LIABLE FOR ANY CLAIM, DAMAGES, OR OTHER LIABILITY ARISING FROM THE USE OF THE
SDK.

For licensing inquiries, contact BankruptGames.
