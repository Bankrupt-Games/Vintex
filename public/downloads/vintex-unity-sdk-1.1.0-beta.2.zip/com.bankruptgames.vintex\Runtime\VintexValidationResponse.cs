using System;

namespace Vintex
{

/// <summary>
/// JSON response structure from Vintex backend.
/// Used for deserialization.
/// </summary>
[Serializable]
internal class VintexValidationResponse
{
	public int actionCode;

	public string reason;

	public bool usingVpn;

	public ValidationResult ToResult()
	{
		return new ValidationResult
		{
			ActionCode = actionCode,
			Reason = (reason ?? string.Empty),
			IsUsingVPN = usingVpn
		};
	}
}
}
