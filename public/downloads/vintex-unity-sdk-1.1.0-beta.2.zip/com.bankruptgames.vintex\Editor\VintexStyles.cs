using System.Collections.Generic;
using UnityEngine;

namespace VintexEditorPlugin
{

/// <summary>
/// Shared color palette and styles matching Vintex web portal design.
/// </summary>
public static class VintexStyles
{
	// Keep the legacy field names for binary/source compatibility with the editor UI.
	// Values mirror the current Vintex web palette (#5b8fb3 / #77aed3).
	public static readonly Color Purple = new Color(0.357f, 0.561f, 0.702f);

	public static readonly Color PurpleLight = new Color(0.467f, 0.682f, 0.827f);

	public static readonly Color PurpleGlow = new Color(0.357f, 0.561f, 0.702f, 0.2f);

	public static readonly Color PurpleBorder = new Color(0.357f, 0.561f, 0.702f, 0.3f);

	public static readonly Color Dark = new Color(0.071f, 0.071f, 0.078f);

	public static readonly Color Card = new Color(0.110f, 0.110f, 0.122f);

	public static readonly Color CardHover = new Color(0.137f, 0.137f, 0.153f);

	public static readonly Color Border = new Color(0.165f, 0.165f, 0.180f);

	public static readonly Color BorderLight = new Color(0.204f, 0.204f, 0.227f);

	public static readonly Color TextPrimary = new Color(0.894f, 0.894f, 0.906f);

	public static readonly Color TextSecondary = new Color(0.659f, 0.659f, 0.682f);

	public static readonly Color TextMuted = new Color(0.541f, 0.541f, 0.565f);

	public static readonly Color Success = new Color(0.294f, 0.71f, 0.263f);

	public static readonly Color Error = new Color(0.898f, 0f, 0f);

	public static readonly Color Warning = new Color(0.961f, 0.62f, 0.043f);

	public static readonly Color Info = new Color(0.231f, 0.388f, 0.918f);

	public static readonly Color DevRed = new Color(0.937f, 0.267f, 0.267f);

	public static readonly Color QAOrange = new Color(0.961f, 0.62f, 0.043f);

	public static readonly Color LiveGreen = new Color(0.294f, 0.71f, 0.263f);

	public static readonly Color Gray200 = new Color(0.898f, 0.906f, 0.922f);

	public static readonly Color Gray400 = new Color(0.612f, 0.639f, 0.686f);

	public static readonly Color Gray500 = new Color(0.42f, 0.447f, 0.502f);

	public static readonly Color Gray700 = new Color(0.216f, 0.255f, 0.318f);

	public static readonly Color Gray800 = new Color(0.122f, 0.161f, 0.216f);

	public static readonly Color Gray900 = new Color(0.067f, 0.094f, 0.153f);

	private static Dictionary<Color, Texture2D> _textureCache = new Dictionary<Color, Texture2D>();

	/// <summary>
	/// Creates a solid color texture.
	/// </summary>
	public static Texture2D MakeTexture(Color color)
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Expected O, but got Unknown
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		if (_textureCache.TryGetValue(color, out var value) && (Object)(object)value != (Object)null)
		{
			return value;
		}
		Texture2D val = new Texture2D(2, 2);
		((Object)val).hideFlags = (HideFlags)61;
		Color[] array = (Color[])(object)new Color[4];
		for (int i = 0; i < 4; i++)
		{
			array[i] = color;
		}
		val.SetPixels(array);
		val.Apply();
		_textureCache[color] = val;
		return val;
	}

	public static void ClearTextureCache()
	{
		foreach (Texture2D value in _textureCache.Values)
		{
			if ((Object)(object)value != (Object)null)
			{
				Object.DestroyImmediate((Object)(object)value);
			}
		}
		_textureCache.Clear();
	}

	/// <summary>
	/// Creates a GUIStyle for labels that won't change color on hover.
	/// </summary>
	public static GUIStyle CreateLabelStyle(int fontSize, Color textColor, TextAnchor alignment = (TextAnchor)3, FontStyle fontStyle = (FontStyle)0)
	{
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Expected O, but got Unknown
		GUIStyle val = new GUIStyle(GUI.skin.label)
		{
			fontSize = fontSize,
			fontStyle = fontStyle,
			alignment = alignment,
			wordWrap = true
		};
		val.normal.textColor = textColor;
		val.hover.textColor = textColor;
		val.active.textColor = textColor;
		val.focused.textColor = textColor;
		return val;
	}

	/// <summary>
	/// Draws the VINTEX header text centered.
	/// </summary>
	public static void DrawHeader()
	{
	}

	/// <summary>
	/// Draws a subtitle centered.
	/// </summary>
	public static void DrawSubtitle(string text)
	{
	}
}
}
